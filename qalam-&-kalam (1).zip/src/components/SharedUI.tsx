import React, { useState } from 'react';
import { Volume2, BookOpen, Loader2 } from 'lucide-react';
import {
  getArabicVoiceAvailability,
  speakArabic,
  type ArabicRegister,
} from '../utils/arabicSpeech';
import { fetchAndPlayGeminiTts, unlockAudioPlayback } from '../utils/wavPlayer';

interface AudioButtonProps {
  text: string;
  register: ArabicRegister;
  rate?: number;
  label?: string;
  compact?: boolean;
}

export const AudioButton: React.FC<AudioButtonProps> = ({
  text,
  register,
  rate = 0.95,
  label = 'Dengarkan',
  compact = false,
}) => {
  const [status, setStatus] = useState<'idle' | 'loading' | 'playing'>('idle');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handlePlay = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setErrorMsg(null);
    unlockAudioPlayback();
    setStatus('loading');

    try {
      await fetchAndPlayGeminiTts(
        text,
        register,
        rate,
        () => setStatus('playing'),
        () => setStatus('idle')
      );
    } catch (err) {
      const avail = getArabicVoiceAvailability();
      if (avail.supported && avail.hasArabicVoice) {
        const started = speakArabic(
          text,
          register,
          rate,
          () => setStatus('playing'),
          () => setStatus('idle')
        );
        if (started) return;
      }
      setStatus('idle');
      setErrorMsg(err instanceof Error ? err.message : 'Suara gagal diputar.');
    }
  };

  const isActive = status !== 'idle';
  const accentClasses =
    register === 'fusha'
      ? isActive
        ? 'bg-blue-700 text-white border-blue-700'
        : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-50'
      : isActive
        ? 'bg-emerald-700 text-white border-emerald-700'
        : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50';

  return (
    <div className="inline-flex flex-col items-end gap-1">
      <button
        type="button"
        onClick={handlePlay}
        aria-label={`${label} (${register === 'fusha' ? 'Fushah' : 'Ammiyah'})`}
        className={`inline-flex items-center justify-center gap-1.5 border rounded-lg font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 ${accentClasses} ${
          compact ? 'px-2.5 py-1.5 text-xs min-h-[34px]' : 'px-3 py-1.5 text-xs min-h-[38px]'
        }`}
      >
        {status === 'loading' ? (
          <Loader2 className="w-3.5 h-3.5 shrink-0 animate-spin" />
        ) : (
          <Volume2 className="w-3.5 h-3.5 shrink-0" />
        )}
        <span>
          {status === 'loading' ? 'Memuat...' : status === 'playing' ? 'Memutar...' : label}
        </span>
      </button>
      {errorMsg && (
        <span className="text-[11px] text-red-700 max-w-[220px] text-right leading-tight">
          {errorMsg}
        </span>
      )}
    </div>
  );
};

interface ResilientImageProps {
  src: string;
  alt: string;
  title: string;
  className?: string;
}

export const ResilientImage: React.FC<ResilientImageProps> = ({
  src,
  alt,
  title,
  className = '',
}) => {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 text-slate-600 p-6 text-center ${className}`}
      >
        <BookOpen className="w-8 h-8 mb-2 text-slate-500" />
        <span className="text-sm font-medium text-slate-700">{title}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};
