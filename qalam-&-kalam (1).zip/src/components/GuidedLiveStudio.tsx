import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Loader2,
  MessageSquare,
  Mic,
  MicOff,
  RotateCcw,
  Square,
  Volume2,
  AlertCircle,
} from 'lucide-react';
import { postJson } from '../utils/apiClient';
import { formatArabicDisplay, stopArabicSpeech, type ArabicRegister } from '../utils/arabicSpeech';
import {
  cacheTtsAudio,
  fetchAndPlayGeminiTts,
  playBase64Wav,
  stopWavPlayback,
  unlockAudioPlayback,
} from '../utils/wavPlayer';
import { AudioButton } from './SharedUI';

export interface LiveChoice {
  id: string;
  arabicWithHarakat: string;
  arabicPlain: string;
  transliteration: string;
  indonesian: string;
  nuance: string;
}

export interface LiveMessage {
  id: string;
  role: 'user' | 'partner';
  speakerLabel: string;
  arabicWithHarakat: string;
  arabicPlain: string;
  transliteration: string;
  indonesian: string;
  culturalNote?: string;
  spokenTranscript?: string | null;
  audioBase64?: string | null;
}

interface TurnResponse {
  sceneTitle: string;
  partnerRole: string;
  stagePrompt: string;
  choices: LiveChoice[];
}

interface RespondResponse {
  reply: {
    partnerRole: string;
    arabicWithHarakat: string;
    arabicPlain: string;
    transliteration: string;
    indonesian: string;
    culturalNote: string;
  };
  audioBase64: string | null;
  mimeType: string;
  ttsError?: string | null;
  spokenTranscript?: string | null;
}

interface StepSnapshot {
  stepIndex: number;
  stagePrompt: string;
  choices: LiveChoice[];
  messagesLengthBeforeChoice: number;
}

interface GuidedLiveStudioProps {
  showHarakat: boolean;
  onToggleHarakat: () => void;
  showTranslit: boolean;
  onToggleTranslit: () => void;
  speechRate: number;
  onChangeSpeechRate: (rate: number) => void;
}

const SUGGESTED_THEMES = [
  'Belanja di toko buah',
  'Pesan kopi dan kurma di kafe Riyadh',
  'Check-in hotel di Makkah',
  'Bertanya arah ke masjid terdekat',
];

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : result);
    };
    reader.onerror = () => reject(new Error('Gagal membaca rekaman suara.'));
    reader.readAsDataURL(blob);
  });
}

function pickSupportedRecorderMime(): string {
  if (typeof MediaRecorder === 'undefined') return '';
  const candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'];
  for (const mime of candidates) {
    if (MediaRecorder.isTypeSupported(mime)) return mime;
  }
  return '';
}

export const GuidedLiveStudio: React.FC<GuidedLiveStudioProps> = ({
  showHarakat,
  onToggleHarakat,
  showTranslit,
  onToggleTranslit,
  speechRate,
  onChangeSpeechRate,
}) => {
  const [register, setRegister] = useState<ArabicRegister>('ammiyah');
  const [themeInput, setThemeInput] = useState<string>('Belanja di toko buah');
  const [activeTheme, setActiveTheme] = useState<string>('Belanja di toko buah');
  const [sceneTitle, setSceneTitle] = useState<string>('Belanja di Toko Buah');
  const [partnerRole, setPartnerRole] = useState<string>('Penjual Buah');
  const [stagePrompt, setStagePrompt] = useState<string>('');
  const [stepIndex, setStepIndex] = useState<number>(0);

  const [messages, setMessages] = useState<LiveMessage[]>([]);
  const [currentChoices, setCurrentChoices] = useState<LiveChoice[]>([]);
  const [snapshots, setSnapshots] = useState<StepSnapshot[]>([]);
  const [stage, setStage] = useState<
    'idle' | 'choosing' | 'modeling' | 'listening' | 'responded'
  >('idle');
  const [pendingChoice, setPendingChoice] = useState<LiveChoice | null>(null);

  const [loadingPhase, setLoadingPhase] = useState<'none' | 'choices' | 'reply'>('none');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [ttsWarning, setTtsWarning] = useState<string | null>(null);
  const [micError, setMicError] = useState<string | null>(null);
  const [micLevel, setMicLevel] = useState<number>(0);
  const [playingMsgId, setPlayingMsgId] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement | null>(null);
  const requestCounterRef = useRef<number>(0);
  const autoStartedRef = useRef<boolean>(false);

  // Mic & recording refs
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const meterAudioCtxRef = useRef<AudioContext | null>(null);
  const meterRafRef = useRef<number | null>(null);
  const maxRecordTimerRef = useRef<number | null>(null);
  const skipSubmissionRef = useRef<boolean>(false);
  const pendingChoiceRef = useRef<LiveChoice | null>(null);

  const cleanupMicResources = () => {
    if (meterRafRef.current !== null) {
      window.cancelAnimationFrame(meterRafRef.current);
      meterRafRef.current = null;
    }
    if (maxRecordTimerRef.current !== null) {
      window.clearTimeout(maxRecordTimerRef.current);
      maxRecordTimerRef.current = null;
    }
    if (meterAudioCtxRef.current) {
      meterAudioCtxRef.current.close().catch(() => {
        // Ignore close errors
      });
      meterAudioCtxRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    mediaRecorderRef.current = null;
    setMicLevel(0);
  };

  useEffect(() => {
    return () => {
      skipSubmissionRef.current = true;
      cleanupMicResources();
      stopWavPlayback();
      stopArabicSpeech();
    };
  }, []);

  const toHistoryPayload = (list: LiveMessage[]) =>
    list.map((m) => ({
      role: m.role,
      arabicWithHarakat: m.arabicWithHarakat,
      transliteration: m.transliteration,
      indonesian: m.indonesian,
    }));

  const scrollToInteraction = () => {
    window.setTimeout(() => {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }, 80);
  };

  const fetchChoices = async (
    targetTheme: string,
    targetRegister: ArabicRegister,
    nextStepIndex: number,
    historyMsgs: LiveMessage[]
  ) => {
    const reqId = ++requestCounterRef.current;
    setLoadingPhase('choices');
    setErrorMsg(null);
    setTtsWarning(null);
    setMicError(null);

    try {
      const data = await postJson<TurnResponse>('/api/dialogue/turn', {
        theme: targetTheme,
        register: targetRegister,
        stepIndex: nextStepIndex,
        history: toHistoryPayload(historyMsgs),
      });

      if (requestCounterRef.current !== reqId) return;

      setSceneTitle(data.sceneTitle || targetTheme);
      setPartnerRole(data.partnerRole || 'Lawan Bicara');
      setStagePrompt(data.stagePrompt || 'Pilih salah satu kalimat yang umum digunakan:');
      setCurrentChoices(Array.isArray(data.choices) ? data.choices : []);
      setStepIndex(nextStepIndex);
      setStage('choosing');
      if (nextStepIndex > 0) {
        scrollToInteraction();
      }
    } catch (err) {
      if (requestCounterRef.current !== reqId) return;
      setErrorMsg(err instanceof Error ? err.message : 'Gagal menyiapkan pilihan dialog.');
    } finally {
      if (requestCounterRef.current === reqId) {
        setLoadingPhase('none');
      }
    }
  };

  useEffect(() => {
    if (autoStartedRef.current) return;
    autoStartedRef.current = true;
    void fetchChoices('Belanja di toko buah', 'ammiyah', 0, []);
  }, []);

  const handleStartTheme = async (customTheme?: string, customRegister?: ArabicRegister) => {
    const chosenTheme = (customTheme ?? themeInput).trim();
    const chosenRegister = customRegister ?? register;
    if (!chosenTheme) {
      setErrorMsg('Silakan ketik tema percakapan terlebih dahulu.');
      return;
    }

    skipSubmissionRef.current = true;
    cleanupMicResources();
    unlockAudioPlayback();
    stopWavPlayback();
    stopArabicSpeech();

    setPendingChoice(null);
    pendingChoiceRef.current = null;
    setThemeInput(chosenTheme);
    setActiveTheme(chosenTheme);
    setSceneTitle(chosenTheme);
    setMessages([]);
    setSnapshots([]);
    setCurrentChoices([]);
    setStepIndex(0);
    setStage('idle');

    await fetchChoices(chosenTheme, chosenRegister, 0, []);
  };

  const handleSwitchRegister = (nextRegister: ArabicRegister) => {
    if (nextRegister === register) return;
    setRegister(nextRegister);
    const themeToUse = activeTheme || themeInput.trim() || 'Belanja di toko buah';
    void handleStartTheme(themeToUse, nextRegister);
  };

  const submitChoiceAndGetReply = async (
    choice: LiveChoice,
    userAudioBase64?: string,
    userAudioMimeType?: string
  ) => {
    const targetTheme = activeTheme || themeInput.trim();
    if (!targetTheme) return;

    const snapshot: StepSnapshot = {
      stepIndex,
      stagePrompt,
      choices: currentChoices,
      messagesLengthBeforeChoice: messages.length,
    };

    const userMsg: LiveMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      speakerLabel: 'Anda',
      arabicWithHarakat: choice.arabicWithHarakat,
      arabicPlain: choice.arabicPlain,
      transliteration: choice.transliteration,
      indonesian: choice.indonesian,
    };

    const updatedWithUser = [...messages, userMsg];
    setMessages(updatedWithUser);
    setSnapshots((prev) => [...prev, snapshot]);
    setPendingChoice(null);
    pendingChoiceRef.current = null;
    setLoadingPhase('reply');
    setErrorMsg(null);
    setTtsWarning(null);
    setMicError(null);
    scrollToInteraction();

    const reqId = ++requestCounterRef.current;

    try {
      const data = await postJson<RespondResponse>('/api/dialogue/respond', {
        theme: targetTheme,
        register,
        selectedChoice: {
          arabicWithHarakat: choice.arabicWithHarakat,
          transliteration: choice.transliteration,
          indonesian: choice.indonesian,
        },
        history: toHistoryPayload(messages),
        userAudioBase64,
        userAudioMimeType,
      });

      if (requestCounterRef.current !== reqId) return;

      const enrichedUserMsg: LiveMessage = data.spokenTranscript
        ? { ...userMsg, spokenTranscript: data.spokenTranscript }
        : userMsg;

      const partnerMsgId = `partner-${Date.now()}`;
      const partnerMsg: LiveMessage = {
        id: partnerMsgId,
        role: 'partner',
        speakerLabel: data.reply.partnerRole || partnerRole,
        arabicWithHarakat: data.reply.arabicWithHarakat,
        arabicPlain: data.reply.arabicPlain,
        transliteration: data.reply.transliteration,
        indonesian: data.reply.indonesian,
        culturalNote: data.reply.culturalNote,
        audioBase64: data.audioBase64,
      };

      setPartnerRole(partnerMsg.speakerLabel);
      setMessages([...messages, enrichedUserMsg, partnerMsg]);
      setStage('responded');
      scrollToInteraction();

      if (data.ttsError) {
        setTtsWarning(`Balasan teks berhasil, namun suara gagal dibuat: ${data.ttsError}`);
      } else if (data.audioBase64) {
        cacheTtsAudio(partnerMsg.arabicWithHarakat, register, data.audioBase64);
        playBase64Wav(
          data.audioBase64,
          speechRate,
          () => setPlayingMsgId(partnerMsgId),
          () => setPlayingMsgId((curr) => (curr === partnerMsgId ? null : curr))
        ).catch((playErr) => {
          setPlayingMsgId(null);
          setTtsWarning(
            playErr instanceof Error
              ? `Klik "Putar Ulang Suara" untuk mendengar audio (${playErr.message}).`
              : 'Klik "Putar Ulang Suara" untuk mendengar audio.'
          );
        });
      }
    } catch (err) {
      if (requestCounterRef.current !== reqId) return;
      setMessages(messages);
      setSnapshots((prev) => prev.slice(0, -1));
      setStage('choosing');
      setErrorMsg(err instanceof Error ? err.message : 'Gagal mendapatkan balasan lawan bicara.');
    } finally {
      if (requestCounterRef.current === reqId) {
        setLoadingPhase('none');
      }
    }
  };

  const stopRecordingAndSend = (shouldSend: boolean) => {
    skipSubmissionRef.current = !shouldSend;
    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      recorder.stop();
    } else {
      cleanupMicResources();
      if (shouldSend && pendingChoiceRef.current) {
        void submitChoiceAndGetReply(pendingChoiceRef.current);
      }
    }
  };

  const startMicrophoneCapture = async (choice: LiveChoice) => {
    cleanupMicResources();
    stopWavPlayback();
    stopArabicSpeech();

    pendingChoiceRef.current = choice;
    setPendingChoice(choice);
    setStage('listening');
    setMicError(null);
    setErrorMsg(null);
    skipSubmissionRef.current = false;
    scrollToInteraction();

    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices ||
      !navigator.mediaDevices.getUserMedia
    ) {
      setMicError('Browser atau perangkat ini belum mendukung akses mikrofon langsung.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      mediaStreamRef.current = stream;

      const mimeType = pickSupportedRecorderMime();
      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);
      recordedChunksRef.current = [];
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        const shouldSend = !skipSubmissionRef.current;
        const activeChoice = pendingChoiceRef.current;
        const chunks = [...recordedChunksRef.current];
        const finalMime = recorder.mimeType || mimeType || 'audio/webm';
        cleanupMicResources();

        if (!shouldSend || !activeChoice) {
          return;
        }

        if (chunks.length === 0) {
          await submitChoiceAndGetReply(activeChoice);
          return;
        }

        try {
          const blob = new Blob(chunks, { type: finalMime });
          const base64Audio = await blobToBase64(blob);
          await submitChoiceAndGetReply(activeChoice, base64Audio, finalMime);
        } catch {
          await submitChoiceAndGetReply(activeChoice);
        }
      };

      // Live audio level meter + natural pause detection
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (Ctx) {
        const ctx = new Ctx();
        meterAudioCtxRef.current = ctx;
        const src = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;
        src.connect(analyser);

        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        let speechDetectedAt: number | null = null;
        let lastVoiceAt = Date.now();
        const startedAt = Date.now();

        const tick = () => {
          if (!mediaStreamRef.current) return;
          analyser.getByteFrequencyData(dataArray);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            sum += dataArray[i];
          }
          const avg = sum / dataArray.length;
          const normalized = Math.min(100, Math.round((avg / 65) * 100));
          setMicLevel(normalized);

          const now = Date.now();
          if (avg > 14) {
            if (!speechDetectedAt) {
              speechDetectedAt = now;
            }
            lastVoiceAt = now;
          } else if (
            speechDetectedAt &&
            now - speechDetectedAt > 700 &&
            now - lastVoiceAt > 1900 &&
            now - startedAt > 1400
          ) {
            stopRecordingAndSend(true);
            return;
          }

          meterRafRef.current = window.requestAnimationFrame(tick);
        };
        meterRafRef.current = window.requestAnimationFrame(tick);
      }

      recorder.start(250);
      maxRecordTimerRef.current = window.setTimeout(() => {
        stopRecordingAndSend(true);
      }, 10000);
    } catch (err) {
      cleanupMicResources();
      const msg = err instanceof Error ? err.message : '';
      if (msg.toLowerCase().includes('denied') || msg.toLowerCase().includes('notallowed')) {
        setMicError(
          'Izin mikrofon ditolak oleh browser/perangkat. Izinkan mikrofon lalu ketuk "Aktifkan Mic", atau lanjutkan tanpa mic.'
        );
      } else {
        setMicError(
          'Mikrofon tidak dapat diakses saat ini. Anda bisa mencoba lagi atau langsung lanjut melihat balasan.'
        );
      }
    }
  };

  const playExampleThenActivateMic = async (choice: LiveChoice) => {
    const reqId = ++requestCounterRef.current;
    skipSubmissionRef.current = true;
    cleanupMicResources();
    unlockAudioPlayback();
    stopWavPlayback();
    stopArabicSpeech();

    pendingChoiceRef.current = choice;
    setPendingChoice(choice);
    setStage('modeling');
    setErrorMsg(null);
    setTtsWarning(null);
    setMicError(null);
    scrollToInteraction();

    try {
      await fetchAndPlayGeminiTts(
        choice.arabicWithHarakat,
        register,
        speechRate,
        undefined,
        () => {
          if (requestCounterRef.current !== reqId) return;
          void startMicrophoneCapture(choice);
        }
      );
    } catch (err) {
      if (requestCounterRef.current !== reqId) return;
      setTtsWarning(
        err instanceof Error
          ? `Contoh suara gagal diputar (${err.message}). Silakan langsung ucapkan kalimat di atas.`
          : 'Contoh suara gagal diputar. Silakan langsung ucapkan kalimat di atas.'
      );
      void startMicrophoneCapture(choice);
    }
  };

  const handleSelectChoice = (choice: LiveChoice) => {
    if (loadingPhase !== 'none') return;
    void playExampleThenActivateMic(choice);
  };

  const handleCancelPracticeBackToChoices = () => {
    requestCounterRef.current++;
    skipSubmissionRef.current = true;
    cleanupMicResources();
    stopWavPlayback();
    stopArabicSpeech();
    setPendingChoice(null);
    pendingChoiceRef.current = null;
    setMicError(null);
    setTtsWarning(null);
    setStage('choosing');
  };

  const handlePlayMessageAudio = async (msg: LiveMessage) => {
    unlockAudioPlayback();
    setTtsWarning(null);
    try {
      if (msg.audioBase64) {
        await playBase64Wav(
          msg.audioBase64,
          speechRate,
          () => setPlayingMsgId(msg.id),
          () => setPlayingMsgId((curr) => (curr === msg.id ? null : curr))
        );
      } else {
        await fetchAndPlayGeminiTts(
          msg.arabicWithHarakat,
          register,
          speechRate,
          () => setPlayingMsgId(msg.id),
          () => setPlayingMsgId((curr) => (curr === msg.id ? null : curr))
        );
      }
    } catch (err) {
      setPlayingMsgId(null);
      setTtsWarning(err instanceof Error ? err.message : 'Gagal memutar audio suara.');
    }
  };

  const handleGoBack = () => {
    if (snapshots.length === 0 || loadingPhase !== 'none') return;
    skipSubmissionRef.current = true;
    cleanupMicResources();
    stopWavPlayback();
    stopArabicSpeech();
    setPlayingMsgId(null);
    setPendingChoice(null);
    pendingChoiceRef.current = null;
    setErrorMsg(null);
    setTtsWarning(null);
    setMicError(null);

    const lastSnap = snapshots[snapshots.length - 1];
    setSnapshots((prev) => prev.slice(0, -1));
    setMessages((prev) => prev.slice(0, lastSnap.messagesLengthBeforeChoice));
    setStepIndex(lastSnap.stepIndex);
    setStagePrompt(lastSnap.stagePrompt);
    setCurrentChoices(lastSnap.choices);
    setStage('choosing');
  };

  const handleContinue = () => {
    if (loadingPhase !== 'none' || !activeTheme) return;
    unlockAudioPlayback();
    stopWavPlayback();
    stopArabicSpeech();
    setPlayingMsgId(null);
    void fetchChoices(activeTheme, register, stepIndex + 1, messages);
  };

  const handleResetToSetup = () => {
    requestCounterRef.current++;
    skipSubmissionRef.current = true;
    cleanupMicResources();
    stopWavPlayback();
    stopArabicSpeech();
    setPlayingMsgId(null);
    setPendingChoice(null);
    pendingChoiceRef.current = null;
    setThemeInput('');
    setActiveTheme('');
    setMessages([]);
    setSnapshots([]);
    setCurrentChoices([]);
    setStage('idle');
    setLoadingPhase('none');
    setErrorMsg(null);
    setTtsWarning(null);
    setMicError(null);
  };

  return (
    <div className="space-y-6">
      {/* Setup & Mode Card */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 lg:p-8 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-5">
          <div className="space-y-1.5 max-w-2xl">
            <p className="text-xs font-medium text-slate-500 tracking-wide">
              Dialog Live Terpandu · Suara Contoh, Latihan Mic, &amp; Balasan Alami
            </p>
            <h1 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900 leading-[1.2] [text-wrap:balance]">
              Latihan Percakapan Bahasa Arab dengan Panduan &amp; Suara
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed">
              Pilih kalimat yang ingin diucapkan, dengarkan contoh pelafalannya, tirukan lewat
              mikrofon, lalu dengarkan balasan lawan bicara.
            </p>
          </div>

          {/* Register Mode Selector Button */}
          <div className="shrink-0 space-y-1.5">
            <span className="block text-xs font-medium text-slate-600">Mode Bahasa Arab</span>
            <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => handleSwitchRegister('fusha')}
                className={`px-3.5 sm:px-4 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px] ${
                  register === 'fusha'
                    ? 'bg-blue-700 text-white shadow-sm'
                    : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                Fushah (Baku)
              </button>
              <button
                type="button"
                onClick={() => handleSwitchRegister('ammiyah')}
                className={`px-3.5 sm:px-4 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px] ${
                  register === 'ammiyah'
                    ? 'bg-emerald-700 text-white shadow-sm'
                    : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                Ammiyah (Arab Saudi)
              </button>
            </div>
          </div>
        </div>

        {/* Theme Input Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void handleStartTheme();
          }}
          className="space-y-3 pt-4 border-t border-slate-100"
        >
          <label htmlFor="live-theme-input" className="block text-xs font-medium text-slate-700">
            Ketik Tema Percakapan
          </label>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              id="live-theme-input"
              type="text"
              value={themeInput}
              onChange={(e) => setThemeInput(e.target.value)}
              placeholder="Contoh: Belanja di toko buah"
              className="flex-1 min-h-[46px] px-4 py-2.5 text-sm text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900 focus:bg-white"
            />
            <button
              type="submit"
              disabled={loadingPhase !== 'none' || !themeInput.trim()}
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[46px]"
            >
              {loadingPhase === 'choices' ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <MessageSquare className="w-4 h-4" />
              )}
              <span>Mulai Dialog</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2 pt-0.5">
            <span className="text-xs text-slate-500">Contoh cepat:</span>
            {SUGGESTED_THEMES.map((sample) => (
              <button
                key={sample}
                type="button"
                onClick={() => void handleStartTheme(sample)}
                disabled={loadingPhase !== 'none'}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 hover:border-slate-300 transition-colors cursor-pointer disabled:opacity-50"
              >
                {sample}
              </button>
            ))}
          </div>
        </form>

        {/* Reading & Audio Speed Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onToggleHarakat}
              aria-pressed={showHarakat}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
                showHarakat
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              Harakat: {showHarakat ? 'Aktif' : 'Gundul'}
            </button>

            <button
              type="button"
              onClick={onToggleTranslit}
              aria-pressed={showTranslit}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
                showTranslit
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              Transliterasi: {showTranslit ? 'Aktif' : 'Sembunyi'}
            </button>
          </div>

          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {[
              { rate: 0.78, label: '0.75x Pelan' },
              { rate: 1.0, label: '1.0x Normal' },
            ].map((spd) => (
              <button
                key={spd.rate}
                type="button"
                onClick={() => onChangeSpeechRate(spd.rate)}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer font-mono-nums ${
                  Math.abs(speechRate - spd.rate) < 0.08
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {spd.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Active Conversation Stage */}
      {(activeTheme || loadingPhase !== 'none' || errorMsg) && (
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          {/* Scene Context Header */}
          <div className="px-5 sm:px-6 lg:px-8 py-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <span
                  className={`font-semibold ${
                    register === 'fusha' ? 'text-blue-700' : 'text-emerald-700'
                  }`}
                >
                  {register === 'fusha' ? 'Mode Fushah (Baku)' : 'Mode Ammiyah (Arab Saudi)'}
                </span>
                <span aria-hidden="true">·</span>
                <span>Lawan Bicara: {partnerRole}</span>
                {messages.length > 0 && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-nums">{Math.ceil(messages.length / 2)} putaran</span>
                  </>
                )}
              </div>
              <h2 className="font-display text-lg sm:text-xl font-semibold text-slate-900">
                {sceneTitle || activeTheme}
              </h2>
            </div>

            {activeTheme && (
              <button
                type="button"
                onClick={handleResetToSetup}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px]"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Ganti Tema</span>
              </button>
            )}
          </div>

          {/* Conversation Timeline */}
          {messages.length > 0 && (
            <div className="divide-y divide-slate-200">
              {messages.map((msg) => {
                const isPartner = msg.role === 'partner';
                const isPlaying = playingMsgId === msg.id;

                return (
                  <div
                    key={msg.id}
                    className={`p-5 sm:p-6 lg:px-8 space-y-3 ${
                      isPartner ? 'bg-slate-50/50' : 'bg-white'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <span
                        className={`text-xs font-semibold tracking-wide ${
                          isPartner
                            ? register === 'fusha'
                              ? 'text-blue-800'
                              : 'text-emerald-800'
                            : 'text-slate-700'
                        }`}
                      >
                        {isPartner ? `${msg.speakerLabel} (Balasan)` : 'Pilihan Anda'}
                      </span>

                      <button
                        type="button"
                        onClick={() => void handlePlayMessageAudio(msg)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
                          isPlaying
                            ? register === 'fusha'
                              ? 'bg-blue-700 text-white border-blue-700'
                              : 'bg-emerald-700 text-white border-emerald-700'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>{isPlaying ? 'Sedang Memutar...' : 'Putar Ulang Suara'}</span>
                      </button>
                    </div>

                    <p
                      dir="rtl"
                      className="font-arabic text-2xl sm:text-[28px] text-slate-900 font-medium text-right leading-[1.75]"
                    >
                      {formatArabicDisplay(msg.arabicWithHarakat, showHarakat)}
                    </p>

                    <div className="space-y-1">
                      {showTranslit && (
                        <p className="text-sm text-slate-600 italic">{msg.transliteration}</p>
                      )}
                      <p className="text-sm sm:text-base font-medium text-slate-900">
                        “{msg.indonesian}”
                      </p>
                    </div>

                    {msg.spokenTranscript && (
                      <p
                        dir="rtl"
                        className="text-xs sm:text-sm text-emerald-900 bg-emerald-50 border border-emerald-200 rounded-lg px-3.5 py-2 text-right"
                      >
                        <span dir="ltr" className="font-medium not-italic mr-2">
                          Ucapan Anda terdengar:
                        </span>
                        <span className="font-arabic text-base">{msg.spokenTranscript}</span>
                      </p>
                    )}

                    {msg.culturalNote && (
                      <p className="text-xs text-slate-600 bg-white border border-slate-200 rounded-lg px-3.5 py-2.5 leading-relaxed">
                        <strong className="font-semibold text-slate-800">Catatan:</strong>{' '}
                        {msg.culturalNote}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Current Interactive Control Zone */}
          <div ref={bottomRef} className="p-5 sm:p-6 lg:p-8 bg-white border-t border-slate-200 space-y-5">
            {errorMsg && (
              <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-sm text-red-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0 text-red-700" />
                  <span>{errorMsg}</span>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    void fetchChoices(
                      activeTheme || themeInput.trim() || 'Belanja di toko buah',
                      register,
                      stepIndex,
                      messages
                    )
                  }
                  className="px-3.5 py-2 text-xs font-medium text-white bg-red-700 rounded-lg hover:bg-red-800 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Coba Lagi
                </button>
              </div>
            )}

            {ttsWarning && (
              <div className="p-3.5 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-950">
                {ttsWarning}
              </div>
            )}

            {loadingPhase === 'choices' && (
              <div className="py-8 flex flex-col items-center justify-center gap-3 text-center text-slate-600">
                <Loader2 className="w-6 h-6 animate-spin text-slate-900" />
                <p className="text-sm font-medium text-slate-800">
                  Menyiapkan pilihan kalimat Arab yang umum diucapkan...
                </p>
              </div>
            )}

            {loadingPhase === 'reply' && (
              <div className="py-8 flex flex-col items-center justify-center gap-3 text-center text-slate-600">
                <Loader2 className="w-6 h-6 animate-spin text-slate-900" />
                <p className="text-sm font-medium text-slate-800">
                  Menyiapkan balasan &amp; suara lawan bicara...
                </p>
              </div>
            )}

            {/* Stage 1: Guided Choices */}
            {loadingPhase === 'none' && stage === 'choosing' && currentChoices.length > 0 && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <p className="text-sm font-semibold text-slate-900">{stagePrompt}</p>
                  <p className="text-xs text-slate-500">
                    Ketuk salah satu kalimat di bawah: aplikasi akan membacakan contohnya, lalu
                    mengaktifkan mikrofon agar Anda menirukannya.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentChoices.map((choice, idx) => (
                    <div
                      key={choice.id || idx}
                      role="button"
                      tabIndex={0}
                      onClick={() => handleSelectChoice(choice)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          handleSelectChoice(choice);
                        }
                      }}
                      className={`group p-5 rounded-xl border border-slate-200 bg-slate-50/40 hover:bg-white transition-all duration-150 cursor-pointer flex flex-col justify-between gap-4 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 ${
                        register === 'fusha'
                          ? 'hover:border-blue-600'
                          : 'hover:border-emerald-600'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-slate-500 font-medium">
                          {choice.nuance || `Pilihan ${idx + 1}`}
                        </span>
                        <AudioButton
                          text={choice.arabicWithHarakat}
                          register={register}
                          rate={speechRate}
                          label="Dengar"
                          compact
                        />
                      </div>

                      <p
                        dir="rtl"
                        className="font-arabic text-2xl text-slate-900 font-medium text-right leading-[1.7]"
                      >
                        {formatArabicDisplay(choice.arabicWithHarakat, showHarakat)}
                      </p>

                      <div className="space-y-1 pt-2 border-t border-slate-200/70">
                        {showTranslit && (
                          <p className="text-xs sm:text-sm text-slate-600 italic">
                            {choice.transliteration}
                          </p>
                        )}
                        <p className="text-sm font-medium text-slate-900">“{choice.indonesian}”</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Stage 2 & 3: Listen to Example Pronunciation -> Microphone Active to Imitate */}
            {loadingPhase === 'none' &&
              (stage === 'modeling' || stage === 'listening') &&
              pendingChoice && (
                <div className="p-5 sm:p-6 rounded-xl border border-slate-200 bg-slate-50/70 space-y-5">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 text-sm font-semibold text-slate-900">
                      {stage === 'modeling' ? (
                        <>
                          <Volume2 className="w-4 h-4 text-blue-700 shrink-0" />
                          <span>Dengarkan Contoh Pengucapan...</span>
                        </>
                      ) : micError ? (
                        <>
                          <MicOff className="w-4 h-4 text-amber-700 shrink-0" />
                          <span>Mikrofon Belum Aktif</span>
                        </>
                      ) : (
                        <>
                          <Mic className="w-4 h-4 text-emerald-700 shrink-0" />
                          <span>Mikrofon Aktif — Silakan Tirukan Kalimat Ini</span>
                        </>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={handleCancelPracticeBackToChoices}
                      className="text-xs font-medium text-slate-600 hover:text-slate-900 underline underline-offset-4 cursor-pointer"
                    >
                      Pilih kalimat lain
                    </button>
                  </div>

                  {/* Target sentence to read while imitating */}
                  <div className="p-4 sm:p-5 rounded-xl bg-white border border-slate-200 space-y-2">
                    <p
                      dir="rtl"
                      className="font-arabic text-2xl sm:text-[28px] text-slate-900 font-medium text-right leading-[1.75]"
                    >
                      {formatArabicDisplay(pendingChoice.arabicWithHarakat, showHarakat)}
                    </p>
                    {showTranslit && (
                      <p className="text-sm text-slate-600 italic">
                        {pendingChoice.transliteration}
                      </p>
                    )}
                    <p className="text-sm font-medium text-slate-900">
                      “{pendingChoice.indonesian}”
                    </p>
                  </div>

                  {/* Live Mic Meter or Error */}
                  {stage === 'listening' && !micError && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs text-slate-600">
                        <span>Merekam suara Anda (otomatis lanjut setelah jeda bicara)</span>
                        <span className="font-mono-nums">{micLevel}%</span>
                      </div>
                      <div
                        aria-label={`Level suara mikrofon ${micLevel}%`}
                        className="grid grid-cols-10 gap-1.5 h-2.5"
                      >
                        {[10, 20, 30, 40, 50, 60, 70, 80, 90, 100].map((threshold) => (
                          <div
                            key={threshold}
                            className={`rounded-sm transition-colors duration-75 ${
                              micLevel >= threshold ? 'bg-emerald-600' : 'bg-slate-200'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {micError && (
                    <div className="p-3.5 rounded-lg bg-amber-50 border border-amber-200 text-xs sm:text-sm text-amber-950">
                      {micError}
                    </div>
                  )}

                  {/* Practice Controls */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => void playExampleThenActivateMic(pendingChoice)}
                        className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs sm:text-sm font-medium text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap cursor-pointer min-h-[42px]"
                      >
                        <Volume2 className="w-4 h-4" />
                        <span>Putar Ulang Contoh</span>
                      </button>

                      {stage === 'modeling' && (
                        <button
                          type="button"
                          onClick={() => void startMicrophoneCapture(pendingChoice)}
                          className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs sm:text-sm font-medium text-emerald-900 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors whitespace-nowrap cursor-pointer min-h-[42px]"
                        >
                          <Mic className="w-4 h-4" />
                          <span>Aktifkan Mic Sekarang</span>
                        </button>
                      )}

                      {stage === 'listening' && micError && (
                        <button
                          type="button"
                          onClick={() => void startMicrophoneCapture(pendingChoice)}
                          className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs sm:text-sm font-medium text-emerald-900 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors whitespace-nowrap cursor-pointer min-h-[42px]"
                        >
                          <Mic className="w-4 h-4" />
                          <span>Coba Aktifkan Mic</span>
                        </button>
                      )}
                    </div>

                    {stage === 'listening' && !micError ? (
                      <button
                        type="button"
                        onClick={() => stopRecordingAndSend(true)}
                        className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap cursor-pointer min-h-[42px]"
                      >
                        <Square className="w-3.5 h-3.5" />
                        <span>Selesai Mengucapkan</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          skipSubmissionRef.current = true;
                          cleanupMicResources();
                          stopWavPlayback();
                          void submitChoiceAndGetReply(pendingChoice);
                        }}
                        className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap cursor-pointer min-h-[42px]"
                      >
                        <span>Lanjut Dengar Balasan</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              )}

            {/* Stage 4: Responded -> Kembali / Lanjutkan */}
            {loadingPhase === 'none' && stage === 'responded' && (
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-1">
                <button
                  type="button"
                  onClick={handleGoBack}
                  disabled={snapshots.length === 0}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-medium text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-40 transition-colors whitespace-nowrap cursor-pointer min-h-[46px]"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Kembali</span>
                </button>

                <button
                  type="button"
                  onClick={handleContinue}
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap cursor-pointer min-h-[46px]"
                >
                  <span>Lanjutkan</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
};
