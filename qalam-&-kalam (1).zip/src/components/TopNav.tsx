import React from 'react';

export type AppSection = 'live' | 'dialog' | 'compare' | 'practice' | 'vocabulary';

interface TopNavProps {
  activeSection: AppSection;
  onSelectSection: (section: AppSection) => void;
  onPrimaryAction: () => void;
}

const NAV_ITEMS: { id: AppSection; label: string }[] = [
  { id: 'live', label: 'Dialog Live' },
  { id: 'dialog', label: 'Modul Dialog' },
  { id: 'compare', label: 'Lab Bandingkan' },
  { id: 'practice', label: 'Latihan' },
  { id: 'vocabulary', label: 'Kosakata' },
];

export const TopNav: React.FC<TopNavProps> = ({
  activeSection,
  onSelectSection,
  onPrimaryAction,
}) => {
  return (
    <header className="bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-6 lg:px-10 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand mark with Kalami logo */}
        <button
          type="button"
          onClick={() => onSelectSection('live')}
          className="inline-flex items-center gap-2.5 font-display text-xl font-semibold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-slate-900"
        >
          <img
            src="/assets/aistudio/AddText_11-21-05.41.20_4f6e52b4.png"
            alt="Logo Kalami"
            referrerPolicy="no-referrer"
            className="w-8 h-8 rounded-lg object-cover shrink-0 border border-slate-200"
          />
          <span>Kalami</span>
        </button>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav
          aria-label="Navigasi utama"
          className="hidden md:flex items-center gap-6"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectSection(item.id)}
                className={`py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-slate-900 ${
                  isActive
                    ? 'text-slate-900 border-slate-900'
                    : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="shrink-0">
          <button
            type="button"
            onClick={onPrimaryAction}
            className="px-4 py-2 text-xs sm:text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
          >
            Dialog Live
          </button>
        </div>
      </div>

      {/* Compact mobile navigation row */}
      <nav
        aria-label="Navigasi seluler"
        className="flex md:hidden items-center gap-4 px-6 py-2.5 border-t border-slate-100 overflow-x-auto"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectSection(item.id)}
              className={`text-xs font-medium whitespace-nowrap shrink-0 py-1 border-b-2 cursor-pointer ${
                isActive
                  ? 'text-slate-900 border-slate-900'
                  : 'text-slate-600 border-transparent'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
