const ENV_API_BASE = (import.meta.env.VITE_API_BASE_URL || '').trim().replace(/\/+$/, '');

export function getApiUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  if (ENV_API_BASE) {
    return `${ENV_API_BASE}${normalizedPath}`;
  }
  return normalizedPath;
}

export async function postJson<TResponse>(
  path: string,
  payload: unknown,
  timeoutMs = 40000
): Promise<TResponse> {
  const url = getApiUrl(path);
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);

  let res: Response;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
  } catch (err) {
    window.clearTimeout(timer);
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error(
        'Permintaan ke server memakan waktu terlalu lama. Silakan ketuk "Coba Lagi".'
      );
    }
    throw new Error(
      'Tidak dapat terhubung ke server Kalami. Pastikan koneksi internet aktif dan server berjalan.'
    );
  } finally {
    window.clearTimeout(timer);
  }

  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    if (res.status === 404) {
      throw new Error(
        'Layanan AI server tidak ditemukan di lingkungan lokal aplikasi ini. Gunakan versi web Kalami atau hubungkan VITE_API_BASE_URL saat build APK.'
      );
    }
    throw new Error(`Server mengembalikan respons tidak terduga (HTTP ${res.status}).`);
  }

  const data = (await res.json()) as TResponse & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || `Permintaan gagal (HTTP ${res.status}).`);
  }
  return data;
}
