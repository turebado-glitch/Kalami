import React, { useState } from 'react';
import { Volume2, BookOpen } from 'lucide-react';
import { speakArabic, type ArabicRegister } from '../utils/arabicSpeech';

interface AudioButtonProps {
  text: string;
  register: ArabicRegister;
  rate?: number;
  label?: string;
  compact?: boolean;
}

export const AudioButton: React.FC<AudioButtonProps> = ({
  text,
  register,
  rate = 0.92,
  label = 'Dengarkan',
  compact = false,
}) => {
  const [playing, setPlaying] = useState(false);

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    speakArabic(
      text,
      register,
      rate,
      () => setPlaying(true),
      () => setPlaying(false)
    );
  };

  const accentClasses =
    register === 'fusha'
      ? playing
        ? 'bg-blue-700 text-white border-blue-700'
        : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-50'
      : playing
        ? 'bg-emerald-700 text-white border-emerald-700'
        : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50';

  return (
    <button
      type="button"
      onClick={handlePlay}
      aria-label={`${label} (${register === 'fusha' ? 'Fushah' : 'Ammiyah'})`}
      className={`inline-flex items-center justify-center gap-1.5 border rounded-lg font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 ${accentClasses} ${
        compact ? 'px-2.5 py-1.5 text-xs min-h-[34px]' : 'px-3 py-1.5 text-xs min-h-[38px]'
      }`}
    >
      <Volume2 className="w-3.5 h-3.5 shrink-0" />
      <span>{playing ? 'Memutar...' : label}</span>
    </button>
  );
};

interface ResilientImageProps {
  src: string;
  alt: string;
  title: string;
  className?: string;
}

export const ResilientImage: React.FC<ResilientImageProps> = ({
  src,
  alt,
  title,
  className = '',
}) => {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 text-slate-600 p-6 text-center ${className}`}
      >
        <BookOpen className="w-8 h-8 mb-2 text-slate-500" />
        <span className="text-sm font-medium text-slate-700">{title}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};
