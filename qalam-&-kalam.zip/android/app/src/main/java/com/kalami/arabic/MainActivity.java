package com.kalami.arabic;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;
import java.util.Locale;

public class MainActivity extends BridgeActivity {
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int res = tts.setLanguage(Locale.forLanguageTag("ar-SA"));
                ttsReady = res != TextToSpeech.LANG_MISSING_DATA
                        && res != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });

        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().addJavascriptInterface(new TtsBridge(), "AndroidTTS");
        }
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    private class TtsBridge {
        @JavascriptInterface
        public boolean isAvailable() {
            return ttsReady;
        }

        @JavascriptInterface
        public void speak(String text, String lang, float rate) {
            if (tts == null || !ttsReady || text == null || text.isEmpty()) {
                return;
            }
            runOnUiThread(() -> {
                Locale target = Locale.forLanguageTag(lang != null ? lang : "ar-SA");
                int result = tts.setLanguage(target);
                if (result == TextToSpeech.LANG_MISSING_DATA
                        || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.forLanguageTag("ar"));
                }
                tts.setSpeechRate(Math.max(0.5f, Math.min(1.5f, rate)));
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kalami_tts");
            });
        }

        @JavascriptInterface
        public void stop() {
            if (tts != null) {
                runOnUiThread(() -> tts.stop());
            }
        }
    }
}
