# Kalami

Aplikasi pembelajaran otodidak percakapan bahasa Arab **Fushah (Baku)** dan **Ammiyah Arab Saudi (Sehari-hari)** yang dikemas sebagai aplikasi web sekaligus aplikasi Android Release (Capacitor).

## Fitur Utama

- **Modul Dialog Dwiragam**: 6 skenario percakapan nyata (perkenalan, kafe, pasar, arah jalan, pekerjaan, dan apotek) dengan tampilan berdampingan Fushah vs Ammiyah Arab Saudi, toggle Harakat/Gundul, Transliterasi, kecepatan audio, serta bedah tata bahasa.
- **Lab Bandingkan Struktur**: Analisis pergeseran struktur kalimat utuh dan tabel padanan kata tanya, negasi, kata kerja harian, ungkapan sopan khas Saudi, dan penanda waktu.
- **Latihan Interaktif**: Simulasi roleplay percakapan, susun kalimat (RTL), dan kuis padanan Fushah ↔ Ammiyah dengan dukungan audio (`ar-SA`).
- **Kosakata & Kartu Hafalan**: Flashcard interaktif dan daftar kosakata dengan pelacakan status hafalan.

## Build Android Release Otomatis di GitHub

Repositori ini sudah dilengkapi workflow `.github/workflows/build.yml` untuk mengompilasi **Release APK** dan **Release AAB** secara otomatis di GitHub Actions tanpa memerlukan konfigurasi *Secrets*:

1. Push repositori ini ke branch `main` atau `master` di GitHub.
2. Buka tab **Actions** → pilih workflow **Build Kalami Android Release**.
3. Setelah selesai, unduh artefak **`Kalami-Release-APK`** (`app-release.apk`) untuk langsung diinstal di perangkat Android.

## Pengembangan Lokal

```bash
npm install
npm run dev
```

Untuk menyinkronkan perubahan web ke proyek Android:

```bash
npm run android:sync
```
