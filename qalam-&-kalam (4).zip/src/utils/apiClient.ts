const ENV_API_BASE = (import.meta.env.VITE_API_BASE_URL || '').trim().replace(/\/+$/, '');
const STORAGE_SERVER_URL_KEY = 'kalami_api_base_url_v1';

export type BackendUnavailableReason = 'apk_unconfigured' | 'iframe_auth' | 'static_host';

export class ApiBackendUnavailableError extends Error {
  readonly reason: BackendUnavailableReason;
  readonly diagnostic: string;

  constructor(message: string, reason: BackendUnavailableReason, diagnostic = '') {
    super(message);
    this.name = 'ApiBackendUnavailableError';
    this.reason = reason;
    this.diagnostic = diagnostic;
  }
}

export function isCapacitorNativeRuntime(): boolean {
  if (typeof window === 'undefined') return false;
  const origin = window.location.origin;
  return (
    origin === 'https://localhost' ||
    (origin === 'http://localhost' &&
      Boolean((window as unknown as { Capacitor?: unknown }).Capacitor)) ||
    origin.startsWith('capacitor://') ||
    Boolean(window.AndroidTTS)
  );
}

export function getConfiguredApiBaseUrl(): string {
  if (ENV_API_BASE) return ENV_API_BASE;
  if (typeof window === 'undefined') return '';
  try {
    return (localStorage.getItem(STORAGE_SERVER_URL_KEY) || '').trim().replace(/\/+$/, '');
  } catch {
    return '';
  }
}

export function setConfiguredApiBaseUrl(url: string): string {
  const normalized = url.trim().replace(/\/+$/, '');
  if (typeof window !== 'undefined') {
    try {
      if (normalized) {
        localStorage.setItem(STORAGE_SERVER_URL_KEY, normalized);
      } else {
        localStorage.removeItem(STORAGE_SERVER_URL_KEY);
      }
    } catch {
      // Ignore storage errors
    }
  }
  return normalized;
}

export function getApiUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const base = getConfiguredApiBaseUrl();
  if (base) {
    return `${base}${normalizedPath}`;
  }
  return normalizedPath;
}

export async function testServerHealth(baseUrl: string): Promise<boolean> {
  const clean = baseUrl.trim().replace(/\/+$/, '');
  if (!clean.startsWith('http://') && !clean.startsWith('https://')) {
    throw new Error('URL server harus diawali dengan https:// atau http://');
  }
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 10000);
  try {
    const res = await fetch(`${clean}/api/health`, { signal: controller.signal });
    const ct = res.headers.get('content-type') || '';
    if (!res.ok || !ct.includes('application/json')) {
      throw new Error('Alamat tersebut tidak mengembalikan layanan server Kalami yang aktif.');
    }
    const data = (await res.json()) as { ok?: boolean };
    if (!data.ok) {
      throw new Error('Server Kalami tidak merespons dengan status siap.');
    }
    return true;
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error('Waktu koneksi habis saat menghubungi server tersebut.');
    }
    throw err instanceof Error
      ? err
      : new Error('Gagal terhubung ke alamat server tersebut.');
  } finally {
    window.clearTimeout(timer);
  }
}

export async function postJson<TResponse>(
  path: string,
  payload: unknown,
  timeoutMs = 40000
): Promise<TResponse> {
  const base = getConfiguredApiBaseUrl();
  const url = getApiUrl(path);
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);

  let res: Response;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: base ? 'omit' : 'include',
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
  } catch (err) {
    window.clearTimeout(timer);
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new Error(
        'Permintaan ke server memakan waktu terlalu lama. Silakan ketuk "Coba Lagi".'
      );
    }
    if (isCapacitorNativeRuntime() && !base) {
      throw new ApiBackendUnavailableError(
        'Aplikasi Android (APK) belum terhubung ke server Kalami. Hubungkan URL server Kalami atau gunakan menu Modul Dialog offline.',
        'apk_unconfigured'
      );
    }
    throw new Error(
      'Tidak dapat terhubung ke server Kalami. Pastikan koneksi internet aktif dan server berjalan.'
    );
  } finally {
    window.clearTimeout(timer);
  }

  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    let snippet = '';
    try {
      snippet = (await res.text()).slice(0, 400);
    } catch {
      snippet = '';
    }

    const isIframeAuthRedirect =
      res.redirected ||
      res.url.includes('__cookie_check') ||
      res.url.includes('accounts.google.com') ||
      snippet.includes('_aistudio-iframe.js') ||
      snippet.includes('__cookie_check');

    if (isIframeAuthRedirect) {
      throw new ApiBackendUnavailableError(
        'Preview di dalam iframe browser memblokir cookie sesi menuju server AI. Ketuk "Buka Preview di Tab Penuh" agar sesi berjalan normal beserta suara dan mikrofon.',
        'iframe_auth',
        `HTTP ${res.status}`
      );
    }

    if (isCapacitorNativeRuntime() && !base) {
      throw new ApiBackendUnavailableError(
        'Aplikasi Android (APK) belum terhubung ke server Kalami, sehingga Dialog Live dan Suara AI belum aktif di dalam APK ini.',
        'apk_unconfigured',
        `HTTP ${res.status}`
      );
    }

    if (res.status === 404 || contentType.includes('text/html')) {
      throw new ApiBackendUnavailableError(
        'Layanan server AI Kalami tidak aktif pada hosting statis ini. Buka aplikasi dari server aktif atau hubungkan URL server Kalami.',
        'static_host',
        `HTTP ${res.status}`
      );
    }

    throw new Error(`Server mengembalikan respons tidak terduga (HTTP ${res.status}).`);
  }

  const data = (await res.json()) as TResponse & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || `Permintaan gagal (HTTP ${res.status}).`);
  }
  return data;
}
