export type ArabicRegister = 'fusha' | 'ammiyah';

const HARAKAT_REGEX = /[\u064B-\u065F\u0670\u06D6-\u06ED]/g;

export function stripHarakat(text: string): string {
  return text.replace(HARAKAT_REGEX, '');
}

export function formatArabicDisplay(text: string, showHarakat: boolean): string {
  return showHarakat ? text : stripHarakat(text);
}

export type AndroidTtsStatus = 'ready' | 'missing_data' | 'not_supported' | 'no_engine';

declare global {
  interface Window {
    AndroidTTS?: {
      speak: (text: string, lang: string, rate: number) => string | void;
      stop: () => void;
      isAvailable: () => boolean;
      getStatus?: () => AndroidTtsStatus;
      installVoiceData?: () => void;
      openTtsSettings?: () => void;
    };
    __kalamiAndroidTtsEvent?: (event: string, utteranceId: string) => void;
  }
}

export interface VoiceAvailability {
  supported: boolean;
  hasArabicVoice: boolean;
  voiceName: string | null;
  isAndroidApp: boolean;
  androidStatus?: AndroidTtsStatus;
}

let activeNativeEndCb: (() => void) | undefined;
let activeNativeErrorCb: ((reason: 'missing_data' | 'error') => void) | undefined;
let activeNativeTimer: number | null = null;

function clearNativeTtsCallbacks(): void {
  if (activeNativeTimer !== null) {
    window.clearTimeout(activeNativeTimer);
    activeNativeTimer = null;
  }
  activeNativeEndCb = undefined;
  activeNativeErrorCb = undefined;
}

if (typeof window !== 'undefined') {
  window.__kalamiAndroidTtsEvent = (event: string) => {
    if (event === 'done') {
      const cb = activeNativeEndCb;
      clearNativeTtsCallbacks();
      cb?.();
    } else if (event === 'error') {
      const errCb = activeNativeErrorCb;
      const endCb = activeNativeEndCb;
      clearNativeTtsCallbacks();
      if (errCb) {
        errCb('error');
      } else {
        endCb?.();
      }
    }
  };
}

export function isAndroidNativeApp(): boolean {
  return typeof window !== 'undefined' && Boolean(window.AndroidTTS);
}

export function openAndroidTtsSettings(): boolean {
  if (typeof window !== 'undefined' && window.AndroidTTS?.openTtsSettings) {
    window.AndroidTTS.openTtsSettings();
    return true;
  }
  return false;
}

export function installAndroidArabicVoiceData(): boolean {
  if (typeof window !== 'undefined' && window.AndroidTTS?.installVoiceData) {
    window.AndroidTTS.installVoiceData();
    return true;
  }
  return openAndroidTtsSettings();
}

export function getArabicVoiceAvailability(): VoiceAvailability {
  if (typeof window !== 'undefined' && window.AndroidTTS) {
    const rawStatus: AndroidTtsStatus = window.AndroidTTS.getStatus
      ? window.AndroidTTS.getStatus()
      : window.AndroidTTS.isAvailable()
        ? 'ready'
        : 'not_supported';

    return {
      supported: rawStatus !== 'no_engine',
      hasArabicVoice: rawStatus === 'ready',
      voiceName: 'Google / Android Text-to-Speech',
      isAndroidApp: true,
      androidStatus: rawStatus,
    };
  }

  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return { supported: false, hasArabicVoice: false, voiceName: null, isAndroidApp: false };
  }

  const voices = window.speechSynthesis.getVoices();
  const arVoice =
    voices.find((v) => v.lang.toLowerCase().startsWith('ar-sa')) ||
    voices.find((v) => v.lang.toLowerCase().startsWith('ar-xa')) ||
    voices.find((v) => v.lang.toLowerCase().startsWith('ar-ae')) ||
    voices.find((v) => v.lang.toLowerCase().startsWith('ar'));

  return {
    supported: true,
    hasArabicVoice: Boolean(arVoice),
    voiceName: arVoice ? `${arVoice.name} (${arVoice.lang})` : null,
    isAndroidApp: false,
  };
}

export function stopArabicSpeech(): void {
  clearNativeTtsCallbacks();
  if (typeof window !== 'undefined' && window.AndroidTTS) {
    try {
      window.AndroidTTS.stop();
    } catch {
      // ignore
    }
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function speakArabic(
  text: string,
  register: ArabicRegister,
  rate = 0.92,
  onStart?: () => void,
  onEnd?: () => void,
  onError?: (reason: 'missing_data' | 'no_engine' | 'error') => void
): boolean {
  if (typeof window !== 'undefined' && window.AndroidTTS) {
    try {
      clearNativeTtsCallbacks();
      const status = window.AndroidTTS.getStatus
        ? window.AndroidTTS.getStatus()
        : window.AndroidTTS.isAvailable()
          ? 'ready'
          : 'no_engine';

      if (status === 'no_engine') {
        onError?.('no_engine');
        onEnd?.();
        return false;
      }

      const lang = 'ar-SA';
      activeNativeEndCb = onEnd;
      activeNativeErrorCb = (reason) => {
        onError?.(status === 'missing_data' ? 'missing_data' : reason);
      };

      onStart?.();
      const result = window.AndroidTTS.speak(text, lang, rate);
      if (result === 'no_engine') {
        clearNativeTtsCallbacks();
        onError?.('no_engine');
        onEnd?.();
        return false;
      }

      const fallbackMs = Math.max(2200, Math.min(8000, text.length * 130));
      activeNativeTimer = window.setTimeout(() => {
        const cb = activeNativeEndCb;
        clearNativeTtsCallbacks();
        cb?.();
      }, fallbackMs);
      return true;
    } catch {
      clearNativeTtsCallbacks();
      // fall through to Web Speech API
    }
  }

  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onError?.('no_engine');
    onEnd?.();
    return false;
  }

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();

    const targetLangs =
      register === 'ammiyah'
        ? ['ar-SA', 'ar-XA', 'ar-AE', 'ar-KW', 'ar']
        : ['ar-SA', 'ar-XA', 'ar-AE', 'ar'];

    let chosenVoice: SpeechSynthesisVoice | undefined;
    for (const lang of targetLangs) {
      chosenVoice = voices.find((v) =>
        v.lang.toLowerCase().startsWith(lang.toLowerCase())
      );
      if (chosenVoice) break;
    }

    if (chosenVoice) {
      utterance.voice = chosenVoice;
      utterance.lang = chosenVoice.lang;
    } else {
      utterance.lang = 'ar-SA';
    }

    utterance.rate = rate;
    utterance.pitch = 1.0;

    let finished = false;
    const finishOnce = () => {
      if (finished) return;
      finished = true;
      onEnd?.();
    };

    utterance.onstart = () => {
      onStart?.();
    };
    utterance.onend = () => {
      finishOnce();
    };
    utterance.onerror = () => {
      if (!finished) {
        finished = true;
        onError?.('error');
        onEnd?.();
      }
    };

    onStart?.();
    window.speechSynthesis.speak(utterance);
    return true;
  } catch {
    onError?.('error');
    onEnd?.();
    return false;
  }
}
