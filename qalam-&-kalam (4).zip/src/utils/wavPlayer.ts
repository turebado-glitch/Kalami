import { postJson } from './apiClient';
import type { ArabicRegister } from './arabicSpeech';

let sharedAudioCtx: AudioContext | null = null;
let activeSource: AudioBufferSourceNode | null = null;
let activeHtmlAudio: HTMLAudioElement | null = null;

const clientTtsCache = new Map<string, string>();
const MAX_CLIENT_TTS_CACHE = 80;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  if (!sharedAudioCtx) {
    sharedAudioCtx = new Ctx();
  }
  return sharedAudioCtx;
}

/**
 * Call synchronously inside user click/tap handlers so mobile Chrome and WebView
 * allow subsequent async WAV playback right after API calls return.
 */
export function unlockAudioPlayback(): void {
  const ctx = getAudioContext();
  if (ctx && ctx.state === 'suspended') {
    ctx.resume().catch(() => {
      // Ignore unlock failure
    });
  }
}

export function stopWavPlayback(): void {
  if (activeSource) {
    try {
      activeSource.onended = null;
      activeSource.stop();
    } catch {
      // Ignore already stopped source
    }
    activeSource = null;
  }
  if (activeHtmlAudio) {
    try {
      activeHtmlAudio.onended = null;
      activeHtmlAudio.pause();
      activeHtmlAudio.currentTime = 0;
    } catch {
      // Ignore
    }
    activeHtmlAudio = null;
  }
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = window.atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

export async function playBase64Wav(
  base64Audio: string,
  rate = 0.95,
  onStart?: () => void,
  onEnd?: () => void
): Promise<void> {
  stopWavPlayback();

  const ctx = getAudioContext();
  if (ctx) {
    try {
      if (ctx.state === 'suspended') {
        await ctx.resume();
      }
      const buffer = base64ToArrayBuffer(base64Audio);
      const audioBuffer = await ctx.decodeAudioData(buffer);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.playbackRate.value = Math.max(0.65, Math.min(1.25, rate));
      source.connect(ctx.destination);
      activeSource = source;
      onStart?.();
      source.onended = () => {
        if (activeSource === source) {
          activeSource = null;
        }
        onEnd?.();
      };
      source.start(0);
      return;
    } catch {
      // Fall back to HTMLAudioElement below
    }
  }

  return new Promise((resolve, reject) => {
    try {
      const audio = new Audio(`data:audio/wav;base64,${base64Audio}`);
      audio.playbackRate = Math.max(0.65, Math.min(1.25, rate));
      activeHtmlAudio = audio;
      onStart?.();
      audio.onended = () => {
        if (activeHtmlAudio === audio) {
          activeHtmlAudio = null;
        }
        onEnd?.();
        resolve();
      };
      audio.onerror = () => {
        if (activeHtmlAudio === audio) {
          activeHtmlAudio = null;
        }
        onEnd?.();
        reject(new Error('Gagal memutar audio WAV di browser ini.'));
      };
      audio.play().catch((err) => {
        onEnd?.();
        reject(err instanceof Error ? err : new Error('Gagal memutar audio.'));
      });
    } catch (err) {
      onEnd?.();
      reject(err instanceof Error ? err : new Error('Gagal memulai pemutar audio.'));
    }
  });
}

export function cacheTtsAudio(text: string, register: ArabicRegister, base64Audio: string): void {
  const key = `${register}:${text.trim()}`;
  if (clientTtsCache.size >= MAX_CLIENT_TTS_CACHE) {
    const firstKey = clientTtsCache.keys().next().value;
    if (firstKey) clientTtsCache.delete(firstKey);
  }
  clientTtsCache.set(key, base64Audio);
}

export async function fetchAndPlayGeminiTts(
  text: string,
  register: ArabicRegister,
  rate = 0.95,
  onStart?: () => void,
  onEnd?: () => void
): Promise<void> {
  unlockAudioPlayback();
  const key = `${register}:${text.trim()}`;
  let audioBase64 = clientTtsCache.get(key);

  if (!audioBase64) {
    const res = await postJson<{ audioBase64: string; mimeType: string }>('/api/dialogue/tts', {
      text,
      register,
    });
    audioBase64 = res.audioBase64;
    cacheTtsAudio(text, register, audioBase64);
  }

  await playBase64Wav(audioBase64, rate, onStart, onEnd);
}
