import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

if (import.meta.env.DEV && typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
  navigator.serviceWorker
    .getRegistrations()
    .then((registrations) => {
      registrations.forEach((reg) => {
        void reg.unregister();
      });
    })
    .catch(() => {
      // Ignore cleanup errors
    });
}

createRoot(document.getElementById('root')!).render(<App />);
