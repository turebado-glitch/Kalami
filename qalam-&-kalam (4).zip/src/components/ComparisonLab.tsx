import React, { useState } from 'react';
import { ArrowLeftRight } from 'lucide-react';
import {
  COMPARISON_GROUPS,
  SENTENCE_MORPHS,
  type SentenceMorphExample,
} from '../data/arabicCurriculum';
import { formatArabicDisplay } from '../utils/arabicSpeech';
import { AudioButton } from './SharedUI';

interface ComparisonLabProps {
  showHarakat: boolean;
  onToggleHarakat: () => void;
  showTranslit: boolean;
  onToggleTranslit: () => void;
  speechRate: number;
}

export const ComparisonLab: React.FC<ComparisonLabProps> = ({
  showHarakat,
  onToggleHarakat,
  showTranslit,
  onToggleTranslit,
  speechRate,
}) => {
  const [selectedMorphId, setSelectedMorphId] = useState<string>(SENTENCE_MORPHS[0].id);
  const [activeSlotIdx, setActiveSlotIdx] = useState<number>(0);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>(
    COMPARISON_GROUPS[0].id
  );

  const activeMorph: SentenceMorphExample =
    SENTENCE_MORPHS.find((m) => m.id === selectedMorphId) || SENTENCE_MORPHS[0];

  const activeCategory =
    COMPARISON_GROUPS.find((c) => c.id === selectedCategoryId) || COMPARISON_GROUPS[0];

  const handleSelectMorph = (id: string) => {
    setSelectedMorphId(id);
    setActiveSlotIdx(0);
  };

  return (
    <div className="space-y-10">
      {/* Page Header & Global Reading Toggles */}
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200">
        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-medium text-slate-500 tracking-wide">
            Laboratorium Struktur Dwiragam
          </p>
          <h1 className="font-display text-3xl font-semibold tracking-tight text-slate-900 [text-wrap:balance]">
            Pola Transformasi Fushah ke Ammiyah
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Ammiyah bukanlah bahasa yang terpisah sama sekali dari Fushah—ia memiliki pola
            penyederhanaan yang konsisten pada kata tanya, negasi, awalan kata kerja, dan kosakata
            harian.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onToggleHarakat}
            aria-pressed={showHarakat}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
              showHarakat
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Harakat: {showHarakat ? 'Aktif' : 'Gundul'}
          </button>
          <button
            type="button"
            onClick={onToggleTranslit}
            aria-pressed={showTranslit}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
              showTranslit
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Transliterasi: {showTranslit ? 'Aktif' : 'Sembunyi'}
          </button>
        </div>
      </section>

      {/* Interactive Sentence Morph Explorer */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 lg:p-8 space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display text-xl font-semibold text-slate-900">
              Bedah Pergeseran Kalimat Utuh
            </h2>
            <p className="text-sm text-slate-600">
              Pilih contoh kalimat lalu klik tiap komponen kata untuk melihat perubahan tata bahasanya.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {SENTENCE_MORPHS.map((morph, idx) => (
              <button
                key={morph.id}
                type="button"
                onClick={() => handleSelectMorph(morph.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  morph.id === activeMorph.id
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Contoh {idx + 1}
              </button>
            ))}
          </div>
        </div>

        {/* Indonesian Target */}
        <div className="pb-4 border-b border-slate-100">
          <p className="text-xs text-slate-500 mb-1">{activeMorph.context}</p>
          <p className="text-lg font-semibold text-slate-900">“{activeMorph.indonesian}”</p>
        </div>

        {/* Full Sentence Dual Comparison */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="p-5 rounded-xl bg-blue-50/40 border border-blue-200 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-blue-800">Fushah · Bahasa Baku</span>
              <AudioButton
                text={activeMorph.fushaFull}
                register="fusha"
                rate={speechRate}
                compact
              />
            </div>
            <p className="font-arabic text-2xl text-slate-900 font-medium text-right">
              {formatArabicDisplay(activeMorph.fushaFull, showHarakat)}
            </p>
            {showTranslit && (
              <p className="text-sm text-blue-950/80 italic">{activeMorph.fushaTranslit}</p>
            )}
          </div>

          <div className="p-5 rounded-xl bg-emerald-50/40 border border-emerald-200 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-emerald-800">
                Ammiyah · Percakapan Arab Saudi
              </span>
              <AudioButton
                text={activeMorph.ammiyahFull}
                register="ammiyah"
                rate={speechRate}
                compact
              />
            </div>
            <p className="font-arabic text-2xl text-slate-900 font-medium text-right">
              {formatArabicDisplay(activeMorph.ammiyahFull, showHarakat)}
            </p>
            {showTranslit && (
              <p className="text-sm text-emerald-950/80 italic">{activeMorph.ammiyahTranslit}</p>
            )}
          </div>
        </div>

        {/* Interactive Word-Slot Transformation Grid */}
        <div className="space-y-3 pt-2">
          <p className="text-xs font-medium text-slate-500">
            Klik segmen kata di bawah untuk melihat detail transformasinya:
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {activeMorph.slots.map((slot, idx) => {
              const selected = idx === activeSlotIdx;
              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setActiveSlotIdx(idx)}
                  className={`text-left p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                    selected
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-slate-50 text-slate-900 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <span
                    className={`text-xs font-medium ${
                      selected ? 'text-slate-300' : 'text-slate-500'
                    }`}
                  >
                    {slot.roleLabel}
                  </span>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={`text-[11px] font-medium ${
                          selected ? 'text-blue-300' : 'text-blue-700'
                        }`}
                      >
                        Fushah
                      </span>
                      <span className="font-arabic text-lg">
                        {formatArabicDisplay(slot.fushaWord, showHarakat)}
                      </span>
                    </div>

                    <div
                      className={`flex justify-center ${
                        selected ? 'text-slate-400' : 'text-slate-400'
                      }`}
                    >
                      <ArrowLeftRight className="w-3.5 h-3.5" />
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={`text-[11px] font-medium ${
                          selected ? 'text-emerald-300' : 'text-emerald-700'
                        }`}
                      >
                        Ammiyah
                      </span>
                      <span className="font-arabic text-lg">
                        {formatArabicDisplay(slot.ammiyahWord, showHarakat)}
                      </span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Slot Note */}
          {activeMorph.slots[activeSlotIdx] && (
            <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="text-xs font-semibold text-slate-900">
                  Analisis Segmen: {activeMorph.slots[activeSlotIdx].roleLabel}
                </p>
                <p className="text-sm text-slate-700">{activeMorph.slots[activeSlotIdx].note}</p>
              </div>
              {showTranslit && (
                <div className="text-xs text-slate-600 shrink-0 font-mono-nums">
                  <span>{activeMorph.slots[activeSlotIdx].fushaTranslit}</span>
                  <span className="mx-2 text-slate-400">→</span>
                  <span>{activeMorph.slots[activeSlotIdx].ammiyahTranslit}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* 5-Category Grammar & Lexicon Comparison Table */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="p-6 lg:p-8 border-b border-slate-200 space-y-4">
          <div className="space-y-1">
            <h2 className="font-display text-xl font-semibold text-slate-900">
              Tabel Padanan Pola Harian
            </h2>
            <p className="text-sm text-slate-600">{activeCategory.description}</p>
          </div>

          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit max-w-full overflow-x-auto">
            {COMPARISON_GROUPS.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategoryId(cat.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  cat.id === activeCategory.id
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat.title.split(' (')[0]}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                <th className="py-3.5 px-6 font-semibold">Makna Indonesia</th>
                <th className="py-3.5 px-6 font-semibold text-blue-800">Fushah (Baku)</th>
                <th className="py-3.5 px-6 font-semibold text-emerald-800">Ammiyah (Arab Saudi)</th>
                <th className="py-3.5 px-6 font-semibold">Catatan Pola</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-sm">
              {activeCategory.entries.map((entry) => (
                <tr key={entry.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-4 px-6 font-medium text-slate-900 align-top">
                    {entry.meaning}
                  </td>

                  <td className="py-4 px-6 align-top">
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <p className="font-arabic text-xl text-slate-900">
                          {formatArabicDisplay(entry.fusha, showHarakat)}
                        </p>
                        {showTranslit && (
                          <p className="text-xs text-blue-900/75 italic">{entry.fushaTranslit}</p>
                        )}
                      </div>
                      <AudioButton
                        text={entry.fusha}
                        register="fusha"
                        rate={speechRate}
                        label="Suara"
                        compact
                      />
                    </div>
                  </td>

                  <td className="py-4 px-6 align-top">
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <p className="font-arabic text-xl text-slate-900">
                          {formatArabicDisplay(entry.ammiyah, showHarakat)}
                        </p>
                        {showTranslit && (
                          <p className="text-xs text-emerald-900/75 italic">
                            {entry.ammiyahTranslit}
                          </p>
                        )}
                        {entry.regionalNote && (
                          <p className="text-xs text-slate-500">{entry.regionalNote}</p>
                        )}
                      </div>
                      <AudioButton
                        text={entry.ammiyah}
                        register="ammiyah"
                        rate={speechRate}
                        label="Suara"
                        compact
                      />
                    </div>
                  </td>

                  <td className="py-4 px-6 text-xs text-slate-600 leading-relaxed align-top max-w-xs">
                    {entry.ruleTip}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
