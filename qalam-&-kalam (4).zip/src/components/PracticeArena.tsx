import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  XCircle,
  RotateCcw,
  Lightbulb,
  Mic,
  ArrowRight,
} from 'lucide-react';
import {
  ROLEPLAY_MISSIONS,
  SENTENCE_BUILDERS,
  REGISTER_QUIZZES,
  type RoleplayOption,
} from '../data/arabicCurriculum';
import { formatArabicDisplay, speakArabic, type ArabicRegister } from '../utils/arabicSpeech';
import { AudioButton } from './SharedUI';

type PracticeTab = 'roleplay' | 'builder' | 'quiz';

interface PracticeArenaProps {
  showHarakat: boolean;
  onToggleHarakat: () => void;
  showTranslit: boolean;
  onToggleTranslit: () => void;
  speechRate: number;
  completedExercises: number;
  onIncrementExerciseScore: () => void;
}

function shuffleWithSeed<T>(items: T[], seedStr: string): T[] {
  const arr = [...items];
  let seed = 0;
  for (let i = 0; i < seedStr.length; i += 1) {
    seed = (seed * 31 + seedStr.charCodeAt(i)) % 100000;
  }
  for (let i = arr.length - 1; i > 0; i -= 1) {
    seed = (seed * 16807) % 2147483647;
    const j = seed % (i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  // Ensure scrambled order differs from original when length > 2
  if (arr.length > 2 && arr.every((val, idx) => val === items[idx])) {
    [arr[0], arr[arr.length - 1]] = [arr[arr.length - 1], arr[0]];
  }
  return arr;
}

export const PracticeArena: React.FC<PracticeArenaProps> = ({
  showHarakat,
  onToggleHarakat,
  showTranslit,
  onToggleTranslit,
  speechRate,
  completedExercises,
  onIncrementExerciseScore,
}) => {
  const [activeTab, setActiveTab] = useState<PracticeTab>('roleplay');

  // --- Roleplay State ---
  const [missionId, setMissionId] = useState<string>(ROLEPLAY_MISSIONS[0].id);
  const [stepIdx, setStepIdx] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<RoleplayOption | null>(null);
  const [rpOptimalCount, setRpOptimalCount] = useState<number>(0);
  const [rpFinished, setRpFinished] = useState<boolean>(false);

  // --- Sentence Builder State ---
  const [builderFilter, setBuilderFilter] = useState<'all' | ArabicRegister>('all');
  const [builderIdx, setBuilderIdx] = useState<number>(0);
  const [selectedTileIndices, setSelectedTileIndices] = useState<number[]>([]);
  const [showBuilderHint, setShowBuilderHint] = useState<boolean>(false);
  const [builderChecked, setBuilderChecked] = useState<'idle' | 'correct' | 'wrong'>('idle');

  // --- Quiz & Speaking State ---
  const [quizIdx, setQuizIdx] = useState<number>(0);
  const [quizChoiceId, setQuizChoiceId] = useState<string | null>(null);
  const [quizCorrectCount, setQuizCorrectCount] = useState<number>(0);
  const [micStatus, setMicStatus] = useState<string | null>(null);
  const [isListeningMic, setIsListeningMic] = useState<boolean>(false);

  // Derived Roleplay
  const activeMission =
    ROLEPLAY_MISSIONS.find((m) => m.id === missionId) || ROLEPLAY_MISSIONS[0];
  const activeStep = activeMission.steps[stepIdx];

  const handleSelectMission = (id: string) => {
    setMissionId(id);
    setStepIdx(0);
    setSelectedOption(null);
    setRpOptimalCount(0);
    setRpFinished(false);
  };

  const handleChooseRoleplayOption = (opt: RoleplayOption) => {
    if (selectedOption) return;
    setSelectedOption(opt);
    speakArabic(opt.arabic, opt.register, speechRate);
    if (opt.quality === 'optimal') {
      setRpOptimalCount((c) => c + 1);
      onIncrementExerciseScore();
    }
  };

  const handleNextRoleplayStep = () => {
    if (stepIdx + 1 < activeMission.steps.length) {
      setStepIdx((i) => i + 1);
      setSelectedOption(null);
    } else {
      setRpFinished(true);
    }
  };

  // Derived Sentence Builder
  const filteredBuilders = useMemo(() => {
    if (builderFilter === 'all') return SENTENCE_BUILDERS;
    return SENTENCE_BUILDERS.filter((b) => b.register === builderFilter);
  }, [builderFilter]);

  const currentBuilder =
    filteredBuilders[builderIdx % filteredBuilders.length] || SENTENCE_BUILDERS[0];

  const scrambledTiles = useMemo(() => {
    return shuffleWithSeed(
      currentBuilder.tokens.map((word, originalIdx) => ({ word, originalIdx })),
      currentBuilder.id
    );
  }, [currentBuilder]);

  const handlePickTile = (scrambledIdx: number) => {
    if (builderChecked === 'correct') return;
    if (selectedTileIndices.includes(scrambledIdx)) return;
    setBuilderChecked('idle');
    const next = [...selectedTileIndices, scrambledIdx];
    setSelectedTileIndices(next);
    const word = scrambledTiles[scrambledIdx].word;
    speakArabic(word, currentBuilder.register, speechRate);
  };

  const handleRemoveTile = (posInAnswer: number) => {
    if (builderChecked === 'correct') return;
    setBuilderChecked('idle');
    setSelectedTileIndices((prev) => prev.filter((_, idx) => idx !== posInAnswer));
  };

  const handleCheckBuilder = () => {
    const builtSentence = selectedTileIndices
      .map((sIdx) => scrambledTiles[sIdx].word)
      .join(' ');
    const targetSentence = currentBuilder.tokens.join(' ');
    if (builtSentence === targetSentence) {
      setBuilderChecked('correct');
      onIncrementExerciseScore();
      speakArabic(targetSentence, currentBuilder.register, speechRate);
    } else {
      setBuilderChecked('wrong');
    }
  };

  const handleNextBuilder = () => {
    setBuilderIdx((i) => (i + 1) % filteredBuilders.length);
    setSelectedTileIndices([]);
    setShowBuilderHint(false);
    setBuilderChecked('idle');
  };

  // Derived Quiz
  const currentQuiz = REGISTER_QUIZZES[quizIdx % REGISTER_QUIZZES.length];
  const chosenQuizOption = currentQuiz.options.find((o) => o.id === quizChoiceId);

  const handleSelectQuizOption = (optId: string) => {
    if (quizChoiceId) return;
    setQuizChoiceId(optId);
    setMicStatus(null);
    const opt = currentQuiz.options.find((o) => o.id === optId);
    if (opt?.isCorrect) {
      setQuizCorrectCount((c) => c + 1);
      onIncrementExerciseScore();
    }
  };

  const handleNextQuiz = () => {
    setQuizIdx((i) => (i + 1) % REGISTER_QUIZZES.length);
    setQuizChoiceId(null);
    setMicStatus(null);
  };

  const handleSpeechPractice = (targetText: string, register: ArabicRegister) => {
    type SpeechRecCtor = new () => {
      lang: string;
      interimResults: boolean;
      maxAlternatives: number;
      onresult: (ev: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
      onerror: () => void;
      onend: () => void;
      start: () => void;
    };

    const win = window as unknown as {
      SpeechRecognition?: SpeechRecCtor;
      webkitSpeechRecognition?: SpeechRecCtor;
    };

    const Rec = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!Rec) {
      setMicStatus(
        'Pengenalan suara mikrofon belum didukung di browser ini. Putar audio contoh lalu tirukan secara lisan.'
      );
      return;
    }

    try {
      const recognition = new Rec();
      recognition.lang = 'ar-SA';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      setIsListeningMic(true);
      setMicStatus('Mendengarkan suara Anda... Silakan ucapkan kalimat Arab tersebut.');

      recognition.onresult = (event) => {
        const transcript = event.results?.[0]?.[0]?.transcript || '';
        setMicStatus(
          transcript
            ? `Terdeteksi: "${transcript}" — Bandingkan dengan teks target: "${targetText}".`
            : 'Suara kurang jelas terdengar, coba ulangi lebih dekat ke mikrofon.'
        );
      };
      recognition.onerror = () => {
        setMicStatus(
          'Izin mikrofon ditolak atau tidak tersedia. Gunakan tombol Dengarkan untuk latihan mandiri.'
        );
      };
      recognition.onend = () => {
        setIsListeningMic(false);
      };
      recognition.start();
    } catch {
      setIsListeningMic(false);
      setMicStatus('Mikrofon tidak dapat diaktifkan saat ini.');
    }
  };

  return (
    <div className="space-y-8">
      {/* Header & Mode Tabs */}
      <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-6 border-b border-slate-200">
        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-medium text-slate-500 tracking-wide">
            Arena Latihan Mandiri ·{' '}
            <span className="font-mono-nums text-slate-800">
              {completedExercises} Poin Latihan Selesai
            </span>
          </p>
          <h1 className="font-display text-3xl font-semibold tracking-tight text-slate-900 [text-wrap:balance]">
            Latihan Interaktif Fushah &amp; Ammiyah
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Uji kepekaan ragam bahasa lewat simulasi roleplay, susun kalimat dari potongan kata,
            dan kuis konversi Fushah ↔ Ammiyah.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onToggleHarakat}
            aria-pressed={showHarakat}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
              showHarakat
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Harakat: {showHarakat ? 'Aktif' : 'Gundul'}
          </button>
          <button
            type="button"
            onClick={onToggleTranslit}
            aria-pressed={showTranslit}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
              showTranslit
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Transliterasi: {showTranslit ? 'Aktif' : 'Sembunyi'}
          </button>
        </div>
      </section>

      {/* Practice Mode Segmented Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit">
        {(
          [
            { id: 'roleplay', label: '1. Simulasi Roleplay' },
            { id: 'builder', label: '2. Susun Kalimat' },
            { id: 'quiz', label: '3. Kuis Padanan & Ucap' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === tab.id
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* MODE 1: ROLEPLAY SIMULATION */}
      {activeTab === 'roleplay' && (
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Mission Selector Sidebar */}
          <div className="lg:col-span-4 space-y-3">
            <h2 className="text-sm font-semibold text-slate-900">Pilih Misi Percakapan</h2>
            <div className="space-y-3">
              {ROLEPLAY_MISSIONS.map((mission) => {
                const active = mission.id === activeMission.id;
                const isFusha = mission.targetRegister === 'fusha';
                return (
                  <button
                    key={mission.id}
                    type="button"
                    onClick={() => handleSelectMission(mission.id)}
                    className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer space-y-1.5 ${
                      active
                        ? 'bg-white border-slate-900 shadow-sm'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <p
                      className={`text-xs font-semibold ${
                        isFusha ? 'text-blue-700' : 'text-emerald-700'
                      }`}
                    >
                      Target Ragam: {isFusha ? 'Fushah (Baku)' : 'Ammiyah (Arab Saudi)'}
                    </p>
                    <h3 className="text-base font-semibold text-slate-900">{mission.title}</h3>
                    <p className="text-xs text-slate-600 leading-relaxed">{mission.situation}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Roleplay Interactive Stage */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl p-6 lg:p-8 space-y-6">
            {!rpFinished ? (
              <>
                <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
                  <div className="text-xs text-slate-500 font-mono-nums">
                    Langkah {stepIdx + 1} dari {activeMission.steps.length} · Skor Optimal:{' '}
                    <strong className="text-slate-900">{rpOptimalCount}</strong>
                  </div>
                  <span
                    className={`text-xs font-semibold ${
                      activeMission.targetRegister === 'fusha'
                        ? 'text-blue-700'
                        : 'text-emerald-700'
                    }`}
                  >
                    Gunakan {activeMission.targetRegister === 'fusha' ? 'Fushah' : 'Ammiyah'}
                  </span>
                </div>

                {/* Partner Prompt */}
                <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-slate-700">
                      {activeStep.partnerName} berkata:
                    </span>
                    <AudioButton
                      text={activeStep.partnerArabic}
                      register={activeMission.targetRegister}
                      rate={speechRate}
                      compact
                    />
                  </div>
                  <p className="font-arabic text-2xl text-slate-900 font-medium text-right">
                    {formatArabicDisplay(activeStep.partnerArabic, showHarakat)}
                  </p>
                  {showTranslit && (
                    <p className="text-sm text-slate-600 italic">{activeStep.partnerTranslit}</p>
                  )}
                  <p className="text-sm text-slate-800 pt-1 border-t border-slate-200/70">
                    Arti: “{activeStep.partnerIndonesian}”
                  </p>
                </div>

                {/* Learner Response Options */}
                <div className="space-y-3">
                  <p className="text-xs font-semibold text-slate-700">
                    Pilih respon yang paling tepat makna dan ragam bahasanya:
                  </p>
                  <div className="space-y-3">
                    {activeStep.options.map((opt) => {
                      const isChosen = selectedOption?.id === opt.id;
                      let stateStyle =
                        'bg-white border-slate-200 hover:border-slate-400 text-slate-900';
                      if (selectedOption) {
                        if (opt.quality === 'optimal') {
                          stateStyle = 'bg-emerald-50/70 border-emerald-500 text-slate-900';
                        } else if (isChosen && opt.quality === 'register_mismatch') {
                          stateStyle = 'bg-amber-50/70 border-amber-500 text-slate-900';
                        } else if (isChosen && opt.quality === 'wrong_meaning') {
                          stateStyle = 'bg-rose-50/70 border-rose-500 text-slate-900';
                        } else {
                          stateStyle = 'bg-slate-50/60 border-slate-200 opacity-65';
                        }
                      }

                      return (
                        <button
                          key={opt.id}
                          type="button"
                          disabled={Boolean(selectedOption)}
                          onClick={() => handleChooseRoleplayOption(opt)}
                          className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer disabled:cursor-default space-y-1.5 ${stateStyle}`}
                        >
                          <div className="flex items-start justify-between gap-4">
                            <p className="text-sm text-slate-700 font-medium">
                              “{opt.indonesian}”
                            </p>
                            {selectedOption && (
                              <span
                                className={`text-xs font-semibold shrink-0 ${
                                  opt.register === 'fusha' ? 'text-blue-700' : 'text-emerald-700'
                                }`}
                              >
                                {opt.register === 'fusha' ? 'Fushah' : 'Ammiyah'}
                              </span>
                            )}
                          </div>
                          <p className="font-arabic text-xl text-slate-900 text-right">
                            {formatArabicDisplay(opt.arabic, showHarakat)}
                          </p>
                          {showTranslit && (
                            <p className="text-xs text-slate-600 italic">{opt.transliteration}</p>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Roleplay Feedback Box */}
                {selectedOption && (
                  <div
                    className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                      selectedOption.quality === 'optimal'
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                        : selectedOption.quality === 'register_mismatch'
                          ? 'bg-amber-50 border-amber-200 text-amber-950'
                          : 'bg-rose-50 border-rose-200 text-rose-950'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {selectedOption.quality === 'optimal' ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                      ) : selectedOption.quality === 'register_mismatch' ? (
                        <AlertTriangle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" />
                      )}
                      <div className="space-y-1">
                        <p className="text-xs font-semibold">
                          {selectedOption.quality === 'optimal'
                            ? 'Tepat & Natural'
                            : selectedOption.quality === 'register_mismatch'
                              ? 'Arti Benar, Ragam Kurang Tepat'
                              : 'Makna Kurang Sesuai'}
                        </p>
                        <p className="text-sm">{selectedOption.feedback}</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleNextRoleplayStep}
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[38px]"
                    >
                      <span>
                        {stepIdx + 1 < activeMission.steps.length ? 'Lanjut' : 'Lihat Hasil'}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="py-6 text-center space-y-4">
                <CheckCircle2 className="w-10 h-10 text-emerald-700 mx-auto" />
                <div className="space-y-1">
                  <h3 className="font-display text-2xl font-semibold text-slate-900">
                    Simulasi Selesai
                  </h3>
                  <p className="text-sm text-slate-600 font-mono-nums">
                    Anda memilih respon optimal pada <strong>{rpOptimalCount}</strong> dari{' '}
                    <strong>{activeMission.steps.length}</strong> giliran percakapan.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleSelectMission(activeMission.id)}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer min-h-[40px]"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Ulangi Simulasi</span>
                </button>
              </div>
            )}
          </div>
        </section>
      )}

      {/* MODE 2: SENTENCE BUILDER */}
      {activeTab === 'builder' && (
        <section className="bg-white border border-slate-200 rounded-xl p-6 lg:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div className="space-y-1">
              <p className="text-xs text-slate-500 font-mono-nums">
                Kalimat {(builderIdx % filteredBuilders.length) + 1} dari{' '}
                {filteredBuilders.length}
              </p>
              <h2 className="font-display text-xl font-semibold text-slate-900">
                Susun Kalimat Arab dari Potongan Kata
              </h2>
            </div>

            <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {(
                [
                  { id: 'all', label: 'Semua Ragam' },
                  { id: 'fusha', label: 'Fushah' },
                  { id: 'ammiyah', label: 'Ammiyah' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => {
                    setBuilderFilter(f.id);
                    setBuilderIdx(0);
                    setSelectedTileIndices([]);
                    setShowBuilderHint(false);
                    setBuilderChecked('idle');
                  }}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    builderFilter === f.id
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Target Prompt */}
          <div className="space-y-2">
            <span
              className={`text-xs font-semibold ${
                currentBuilder.register === 'fusha' ? 'text-blue-700' : 'text-emerald-700'
              }`}
            >
              Susun dalam {currentBuilder.register === 'fusha' ? 'Fushah (Baku)' : 'Ammiyah (Arab Saudi)'}
            </span>
            <p className="text-xl font-semibold text-slate-900">
              “{currentBuilder.indonesian}”
            </p>
          </div>

          {/* RTL Answer Drop Tray */}
          <div className="space-y-2">
            <p className="text-xs text-slate-500">
              Susunan Anda (dibaca dari kanan ke kiri, klik kata untuk menghapus):
            </p>
            <div
              dir="rtl"
              className="min-h-[84px] p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center gap-2.5"
            >
              {selectedTileIndices.length === 0 ? (
                <span dir="ltr" className="text-sm text-slate-400">
                  Klik potongan kata di bawah untuk menyusun kalimat...
                </span>
              ) : (
                selectedTileIndices.map((sIdx, pos) => (
                  <button
                    key={`${sIdx}-${pos}`}
                    type="button"
                    onClick={() => handleRemoveTile(pos)}
                    className="px-4 py-2 rounded-lg bg-white border border-slate-300 text-slate-900 font-arabic text-xl hover:border-rose-400 transition-colors cursor-pointer"
                  >
                    {formatArabicDisplay(scrambledTiles[sIdx].word, showHarakat)}
                  </button>
                ))
              )}
            </div>
          </div>

          {/* Scrambled Word Bank */}
          <div className="space-y-2">
            <p className="text-xs text-slate-500">Pilihan kata:</p>
            <div dir="rtl" className="flex flex-wrap items-center gap-2.5">
              {scrambledTiles.map((item, sIdx) => {
                const used = selectedTileIndices.includes(sIdx);
                return (
                  <button
                    key={sIdx}
                    type="button"
                    disabled={used}
                    onClick={() => handlePickTile(sIdx)}
                    className={`px-4 py-2 rounded-lg border font-arabic text-xl transition-all ${
                      used
                        ? 'bg-slate-100 border-slate-200 text-slate-300 cursor-default'
                        : 'bg-white border-slate-200 text-slate-900 hover:border-slate-900 cursor-pointer'
                    }`}
                  >
                    {formatArabicDisplay(item.word, showHarakat)}
                  </button>
                );
              })}
            </div>
          </div>

          {showBuilderHint && (
            <p className="text-xs sm:text-sm text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-4 py-3">
              <strong>Petunjuk:</strong> {currentBuilder.hint}
            </p>
          )}

          {/* Builder Feedback */}
          {builderChecked !== 'idle' && (
            <div
              className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                builderChecked === 'correct'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                  : 'bg-rose-50 border-rose-200 text-rose-950'
              }`}
            >
              <div className="space-y-1">
                <p className="text-sm font-semibold">
                  {builderChecked === 'correct'
                    ? 'Susunan Kalimat Benar!'
                    : 'Urutan belum tepat, coba periksa kembali posisi kata tanya/negasinya.'}
                </p>
                {builderChecked === 'correct' && showTranslit && (
                  <p className="text-xs italic">{currentBuilder.transliteration}</p>
                )}
              </div>
              {builderChecked === 'correct' && (
                <AudioButton
                  text={currentBuilder.tokens.join(' ')}
                  register={currentBuilder.register}
                  rate={speechRate}
                  label="Putar Kalimat"
                />
              )}
            </div>
          )}

          {/* Action Controls */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setShowBuilderHint((v) => !v)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer min-h-[38px]"
              >
                <Lightbulb className="w-3.5 h-3.5" />
                <span>{showBuilderHint ? 'Tutup Petunjuk' : 'Petunjuk'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedTileIndices([]);
                  setBuilderChecked('idle');
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer min-h-[38px]"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={selectedTileIndices.length !== currentBuilder.tokens.length}
                onClick={handleCheckBuilder}
                className="px-4 py-2 text-xs sm:text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors cursor-pointer min-h-[38px]"
              >
                Periksa Jawaban
              </button>

              <button
                type="button"
                onClick={handleNextBuilder}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium text-slate-900 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer min-h-[38px]"
              >
                <span>Berikutnya</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>
      )}

      {/* MODE 3: REGISTER QUIZ & SPEAKING PRACTICE */}
      {activeTab === 'quiz' && (
        <section className="bg-white border border-slate-200 rounded-xl p-6 lg:p-8 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div className="text-xs text-slate-500 font-mono-nums">
              Pertanyaan {(quizIdx % REGISTER_QUIZZES.length) + 1} dari{' '}
              {REGISTER_QUIZZES.length} · Benar:{' '}
              <strong className="text-slate-900">{quizCorrectCount}</strong>
            </div>

            <span
              className={`text-xs font-semibold ${
                currentQuiz.promptRegister === 'fusha' ? 'text-blue-700' : 'text-emerald-700'
              }`}
            >
              Sumber: {currentQuiz.promptRegister === 'fusha' ? 'Fushah (Baku)' : 'Ammiyah (Arab Saudi)'}
            </span>
          </div>

          {/* Prompt Card */}
          <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-medium text-slate-700">{currentQuiz.questionText}</p>
              <AudioButton
                text={currentQuiz.promptArabic}
                register={currentQuiz.promptRegister}
                rate={speechRate}
                label="Dengarkan Soal"
              />
            </div>
            <p className="font-arabic text-2xl sm:text-3xl text-slate-900 font-medium text-right">
              {formatArabicDisplay(currentQuiz.promptArabic, showHarakat)}
            </p>
            {showTranslit && (
              <p className="text-sm text-slate-600 italic">{currentQuiz.promptTranslit}</p>
            )}
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 gap-3">
            {currentQuiz.options.map((opt) => {
              const isChosen = quizChoiceId === opt.id;
              let style = 'bg-white border-slate-200 hover:border-slate-400';
              if (quizChoiceId) {
                if (opt.isCorrect) {
                  style = 'bg-emerald-50 border-emerald-500';
                } else if (isChosen && !opt.isCorrect) {
                  style = 'bg-rose-50 border-rose-500';
                } else {
                  style = 'bg-slate-50 border-slate-200 opacity-60';
                }
              }

              return (
                <button
                  key={opt.id}
                  type="button"
                  disabled={Boolean(quizChoiceId)}
                  onClick={() => handleSelectQuizOption(opt.id)}
                  className={`text-left p-4 rounded-xl border transition-all cursor-pointer disabled:cursor-default flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${style}`}
                >
                  <span className="text-sm font-medium text-slate-900">{opt.labelText}</span>
                  {opt.labelArabic && (
                    <span className="font-arabic text-xl text-slate-900">
                      {formatArabicDisplay(opt.labelArabic, showHarakat)}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Quiz Explanation & Speaking Drill */}
          {quizChoiceId && (
            <div className="space-y-4">
              <div
                className={`p-4 rounded-xl border ${
                  chosenQuizOption?.isCorrect
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                    : 'bg-rose-50 border-rose-200 text-rose-950'
                }`}
              >
                <p className="text-sm font-semibold mb-1">
                  {chosenQuizOption?.isCorrect ? 'Jawaban Tepat!' : 'Belum Tepat'}
                </p>
                <p className="text-sm">{currentQuiz.explanation}</p>
              </div>

              {/* Optional Speaking Check */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <p className="text-xs font-semibold text-slate-900">
                    Latihan Pelafalan Lisan
                  </p>
                  <p className="text-xs text-slate-600">
                    {micStatus ||
                      'Uji pelafalan Anda langsung lewat mikrofon atau dengarkan lalu tirukan secara mandiri.'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      handleSpeechPractice(currentQuiz.promptArabic, currentQuiz.promptRegister)
                    }
                    disabled={isListeningMic}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer min-h-[38px]"
                  >
                    <Mic className="w-3.5 h-3.5" />
                    <span>{isListeningMic ? 'Mendengarkan...' : 'Uji Ucap via Mikrofon'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleNextQuiz}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer min-h-[38px]"
                  >
                    <span>Soal Berikutnya</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </section>
      )}
    </div>
  );
};
