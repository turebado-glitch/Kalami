import React, { useMemo, useState } from 'react';
import { CheckCircle2, RotateCw, Search, ArrowLeft, ArrowRight } from 'lucide-react';
import { VOCABULARY_DECK, type VocabItem } from '../data/arabicCurriculum';
import { formatArabicDisplay, stripHarakat } from '../utils/arabicSpeech';
import { AudioButton } from './SharedUI';

type VocabCategory = 'Semua' | VocabItem['category'];

interface VocabularyStudioProps {
  showHarakat: boolean;
  onToggleHarakat: () => void;
  showTranslit: boolean;
  onToggleTranslit: () => void;
  speechRate: number;
  masteredVocabIds: string[];
  onToggleMasteredVocab: (id: string) => void;
}

const CATEGORIES: VocabCategory[] = [
  'Semua',
  'Sapaan',
  'Kata Kerja',
  'Tanya & Sambung',
  'Belanja & Makan',
  'Arah & Waktu',
];

export const VocabularyStudio: React.FC<VocabularyStudioProps> = ({
  showHarakat,
  onToggleHarakat,
  showTranslit,
  onToggleTranslit,
  speechRate,
  masteredVocabIds,
  onToggleMasteredVocab,
}) => {
  const [viewMode, setViewMode] = useState<'flashcards' | 'list'>('flashcards');
  const [selectedCategory, setSelectedCategory] = useState<VocabCategory>('Semua');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [cardIndex, setCardIndex] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return VOCABULARY_DECK.filter((item) => {
      const catMatch = selectedCategory === 'Semua' || item.category === selectedCategory;
      if (!catMatch) return false;
      if (!q) return true;
      return (
        item.indonesian.toLowerCase().includes(q) ||
        item.fushaTranslit.toLowerCase().includes(q) ||
        item.ammiyahTranslit.toLowerCase().includes(q) ||
        stripHarakat(item.fusha).includes(q) ||
        stripHarakat(item.ammiyah).includes(q)
      );
    });
  }, [selectedCategory, searchQuery]);

  const safeIdx = filteredItems.length > 0 ? cardIndex % filteredItems.length : 0;
  const currentCard = filteredItems[safeIdx];

  const handleCategoryChange = (cat: VocabCategory) => {
    setSelectedCategory(cat);
    setCardIndex(0);
    setIsFlipped(false);
  };

  const handlePrevCard = () => {
    if (filteredItems.length === 0) return;
    setCardIndex((i) => (i - 1 + filteredItems.length) % filteredItems.length);
    setIsFlipped(false);
  };

  const handleNextCard = () => {
    if (filteredItems.length === 0) return;
    setCardIndex((i) => (i + 1) % filteredItems.length);
    setIsFlipped(false);
  };

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-6 border-b border-slate-200">
        <div className="space-y-2 max-w-2xl">
          <p className="text-xs font-medium text-slate-500 tracking-wide">
            Bank Kosakata Inti ·{' '}
            <span className="font-mono-nums text-slate-800">
              {masteredVocabIds.length}/{VOCABULARY_DECK.length} Hafal
            </span>
          </p>
          <h1 className="font-display text-3xl font-semibold tracking-tight text-slate-900 [text-wrap:balance]">
            Kosakata &amp; Kartu Hafalan Dwiragam
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Hafalkan kosakata percakapan berfrekuensi tinggi lengkap dengan padanan Fushah,
            Ammiyah Arab Saudi, serta audio pelafalan untuk keduanya.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onToggleHarakat}
            aria-pressed={showHarakat}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
              showHarakat
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Harakat: {showHarakat ? 'Aktif' : 'Gundul'}
          </button>
          <button
            type="button"
            onClick={onToggleTranslit}
            aria-pressed={showTranslit}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[36px] ${
              showTranslit
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            Transliterasi: {showTranslit ? 'Aktif' : 'Sembunyi'}
          </button>
        </div>
      </section>

      {/* Filter & View Switcher Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg w-fit max-w-full overflow-x-auto">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => handleCategoryChange(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCardIndex(0);
                setIsFlipped(false);
              }}
              placeholder="Cari kata atau arti..."
              aria-label="Cari kosakata"
              className="pl-9 pr-3 py-2 text-xs sm:text-sm bg-white border border-slate-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-slate-900 min-w-[210px]"
            />
          </div>

          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setViewMode('flashcards')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                viewMode === 'flashcards'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Kartu Hafalan
            </button>
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Daftar Tabel
            </button>
          </div>
        </div>
      </div>

      {/* Empty State */}
      {filteredItems.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-2">
          <p className="text-base font-medium text-slate-900">Kosakata tidak ditemukan</p>
          <p className="text-sm text-slate-600">
            Ubah kata kunci pencarian atau pilih kategori “Semua”.
          </p>
        </div>
      ) : viewMode === 'flashcards' && currentCard ? (
        /* FLASHCARD DECK MODE */
        <section className="max-w-3xl mx-auto space-y-5">
          <div className="flex items-center justify-between text-xs text-slate-500 font-mono-nums">
            <span>
              Kartu {safeIdx + 1} dari {filteredItems.length} · {currentCard.category}
            </span>
            <span>
              {masteredVocabIds.includes(currentCard.id)
                ? 'Status: Sudah Hafal'
                : 'Status: Sedang Dipelajari'}
            </span>
          </div>

          {/* Interactive Card */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
            <div className="text-center space-y-2 pb-4 border-b border-slate-100">
              <p className="text-xs font-medium text-slate-500">Makna Bahasa Indonesia</p>
              <h2 className="font-display text-2xl sm:text-3xl font-semibold text-slate-900">
                {currentCard.indonesian}
              </h2>
            </div>

            {!isFlipped ? (
              <div className="py-8 text-center space-y-4">
                <p className="text-sm text-slate-600">
                  Coba ingat bentuk Fushah dan Ammiyahnya terlebih dahulu sebelum membuka kartu.
                </p>
                <button
                  type="button"
                  onClick={() => setIsFlipped(true)}
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer min-h-[42px]"
                >
                  <RotateCw className="w-4 h-4" />
                  <span>Buka Jawaban Arab</span>
                </button>
              </div>
            ) : (
              <div className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-5 rounded-xl bg-blue-50/40 border border-blue-200 space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-blue-800">Fushah (Baku)</span>
                      <AudioButton
                        text={currentCard.fusha}
                        register="fusha"
                        rate={speechRate}
                        compact
                      />
                    </div>
                    <p className="font-arabic text-2xl text-slate-900 text-right">
                      {formatArabicDisplay(currentCard.fusha, showHarakat)}
                    </p>
                    {showTranslit && (
                      <p className="text-sm text-blue-950/80 italic">
                        {currentCard.fushaTranslit}
                      </p>
                    )}
                  </div>

                  <div className="p-5 rounded-xl bg-emerald-50/40 border border-emerald-200 space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-emerald-800">
                        Ammiyah (Arab Saudi)
                      </span>
                      <AudioButton
                        text={currentCard.ammiyah}
                        register="ammiyah"
                        rate={speechRate}
                        compact
                      />
                    </div>
                    <p className="font-arabic text-2xl text-slate-900 text-right">
                      {formatArabicDisplay(currentCard.ammiyah, showHarakat)}
                    </p>
                    {showTranslit && (
                      <p className="text-sm text-emerald-950/80 italic">
                        {currentCard.ammiyahTranslit}
                      </p>
                    )}
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-4 py-3">
                  <strong>Catatan Penggunaan:</strong> {currentCard.exampleNote}
                </p>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsFlipped(false)}
                    className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
                  >
                    Tutup Kartu
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onToggleMasteredVocab(currentCard.id);
                    }}
                    className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium rounded-lg border transition-colors cursor-pointer min-h-[38px] ${
                      masteredVocabIds.includes(currentCard.id)
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                        : 'bg-slate-900 text-white border-slate-900 hover:bg-slate-800'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {masteredVocabIds.includes(currentCard.id)
                        ? 'Sudah Hafal (Klik untuk Ulang)'
                        : 'Tandai Sudah Hafal'}
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Deck Navigation */}
          <div className="flex items-center justify-between gap-4">
            <button
              type="button"
              onClick={handlePrevCard}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer min-h-[40px]"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Sebelumnya</span>
            </button>

            <button
              type="button"
              onClick={handleNextCard}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors cursor-pointer min-h-[40px]"
            >
              <span>Berikutnya</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </section>
      ) : (
        /* LIST TABLE MODE */
        <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                  <th className="py-3.5 px-6 font-semibold">Arti &amp; Kategori</th>
                  <th className="py-3.5 px-6 font-semibold text-blue-800">Fushah</th>
                  <th className="py-3.5 px-6 font-semibold text-emerald-800">Ammiyah</th>
                  <th className="py-3.5 px-6 font-semibold text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {filteredItems.map((item) => {
                  const mastered = masteredVocabIds.includes(item.id);
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-4 px-6 align-top">
                        <p className="font-semibold text-slate-900">{item.indonesian}</p>
                        <p className="text-xs text-slate-500 mt-0.5">{item.category}</p>
                      </td>

                      <td className="py-4 px-6 align-top">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="font-arabic text-xl text-slate-900">
                              {formatArabicDisplay(item.fusha, showHarakat)}
                            </p>
                            {showTranslit && (
                              <p className="text-xs text-blue-900/75 italic">
                                {item.fushaTranslit}
                              </p>
                            )}
                          </div>
                          <AudioButton
                            text={item.fusha}
                            register="fusha"
                            rate={speechRate}
                            label="Suara"
                            compact
                          />
                        </div>
                      </td>

                      <td className="py-4 px-6 align-top">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="font-arabic text-xl text-slate-900">
                              {formatArabicDisplay(item.ammiyah, showHarakat)}
                            </p>
                            {showTranslit && (
                              <p className="text-xs text-emerald-900/75 italic">
                                {item.ammiyahTranslit}
                              </p>
                            )}
                          </div>
                          <AudioButton
                            text={item.ammiyah}
                            register="ammiyah"
                            rate={speechRate}
                            label="Suara"
                            compact
                          />
                        </div>
                      </td>

                      <td className="py-4 px-6 align-top text-right">
                        <button
                          type="button"
                          onClick={() => onToggleMasteredVocab(item.id)}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[34px] ${
                            mastered
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                              : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                          }`}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{mastered ? 'Hafal' : 'Tandai Hafal'}</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
};
