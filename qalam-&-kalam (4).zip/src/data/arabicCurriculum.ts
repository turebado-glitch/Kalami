import type { ArabicRegister } from '../utils/arabicSpeech';

export interface WordBreakdown {
  fusha: string;
  fushaTranslit: string;
  ammiyah: string;
  ammiyahTranslit: string;
  meaning: string;
}

export interface DialoguePhrase {
  arabic: string;
  transliteration: string;
  dialectNote?: string;
}

export interface DialogueTurn {
  id: string;
  speaker: string;
  role: string;
  isLearner: boolean;
  fusha: DialoguePhrase;
  ammiyah: DialoguePhrase;
  indonesian: string;
  grammarSpotlight: string;
  tokens: WordBreakdown[];
}

export interface ScenarioModule {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  level: 'Dasar' | 'Menengah';
  recommendedRegister: 'Fushah & Ammiyah' | 'Dominan Ammiyah' | 'Dominan Fushah';
  estimatedMinutes: number;
  imagePath: string;
  culturalNote: string;
  turns: DialogueTurn[];
}

export const SCENARIOS: ScenarioModule[] = [
  {
    id: 'greetings',
    number: '01',
    title: 'Perkenalan & Sapaan Hangat',
    subtitle: 'Membedakan sapaan resmi di forum dengan sapaan akrab di Arab Saudi.',
    level: 'Dasar',
    recommendedRegister: 'Fushah & Ammiyah',
    estimatedMinutes: 6,
    imagePath: '/src/assets/images/scene_formal_forum_1795242472597.jpg',
    culturalNote:
      'Dalam situasi formal di Arab Saudi (kampus, rapat, khutbah, media) digunakan Fushah. Dalam obrolan santai sehari-hari di Riyadh, Jeddah, Makkah, atau Madinah, masyarakat Saudi memakai sapaan khas seperti "Kef halak?", "Shakhbarak?", dan "Hayyak Allah".',
    turns: [
      {
        id: 'g-1',
        speaker: 'Thariq',
        role: 'Rekan Baru',
        isLearner: false,
        fusha: {
          arabic: 'السَّلَامُ عَلَيْكُمْ، أَهْلًا وَسَهْلًا بِكَ. كَيْفَ حَالُكَ؟',
          transliteration: 'As-salamu ‘alaykum, ahlan wa sahlan bika. Kayfa haluka?',
        },
        ammiyah: {
          arabic: 'السَّلَامُ عَلَيْكُمْ، حَيَّاكْ اللَّه. كِيفْ حَالَكْ وَشَخْبَارَكْ؟',
          transliteration: 'As-salamu ‘alaykum, hayyak Allah. Kef halak wa shakhbarak?',
          dialectNote: '"Hayyak Allah" adalah sambutan hangat paling khas di Arab Saudi.',
        },
        indonesian: 'Assalamualaikum, selamat datang. Bagaimana kabarmu?',
        grammarSpotlight:
          'Kata tanya "Kayfa" (Fushah) diucapkan lebih singkat menjadi "Kef" di Ammiyah Saudi. "Shakhbarak" berasal dari "Esh akhbarak?" (apa kabarmu?).',
        tokens: [
          {
            fusha: 'كَيْفَ حَالُكَ',
            fushaTranslit: 'kayfa haluka',
            ammiyah: 'كِيفْ حَالَكْ',
            ammiyahTranslit: 'kef halak',
            meaning: 'apa kabarmu (lk)',
          },
          {
            fusha: 'أَهْلًا وَسَهْلًا بِكَ',
            fushaTranslit: 'ahlan wa sahlan bika',
            ammiyah: 'حَيَّاكْ اللَّه',
            ammiyahTranslit: 'hayyak Allah',
            meaning: 'selamat datang / senang bertemu',
          },
        ],
      },
      {
        id: 'g-2',
        speaker: 'Anda',
        role: 'Pembelajar',
        isLearner: true,
        fusha: {
          arabic: 'وَعَلَيْكُمُ السَّلَامُ، أَنَا بِخَيْرٍ وَالْحَمْدُ لِلَّهِ. وَأَنْتَ؟',
          transliteration: 'Wa ‘alaykumus-salam, ana bikhayrin wal-hamdulillah. Wa anta?',
        },
        ammiyah: {
          arabic: 'وَعَلَيْكُمُ السَّلَامُ، طَيِّبْ الْحَمْدُ لِلَّه. وَأَنْتَ كِيفَكْ؟',
          transliteration: 'Wa ‘alaykumus-salam, tayyib alhamdulillah. Wanta kefak?',
        },
        indonesian: 'Waalaikumsalam, saya baik alhamdulillah. Bagaimana denganmu?',
        grammarSpotlight:
          'Di Arab Saudi, jawaban "Tayyib, alhamdulillah" atau "Bikhayr ni‘mah" jauh lebih sering dipakai daripada sekadar terjemahan harfiah buku teks.',
        tokens: [
          {
            fusha: 'بِخَيْرٍ',
            fushaTranslit: 'bikhayr',
            ammiyah: 'طَيِّبْ / بِخَيْرْ',
            ammiyahTranslit: 'tayyib / bikhayr',
            meaning: 'baik / sehat',
          },
          {
            fusha: 'وَأَنْتَ',
            fushaTranslit: 'wa anta',
            ammiyah: 'وَأَنْتَ كِيفَكْ',
            ammiyahTranslit: 'wanta kefak',
            meaning: 'dan bagaimana kabarmu',
          },
        ],
      },
      {
        id: 'g-3',
        speaker: 'Thariq',
        role: 'Rekan Baru',
        isLearner: false,
        fusha: {
          arabic: 'أَنَا بِخَيْرٍ أَيْضًا. مَا اسْمُكَ وَمِنْ أَيْنَ أَنْتَ؟',
          transliteration: 'Ana bikhayrin aydan. Mas-muka wa min ayna anta?',
        },
        ammiyah: {
          arabic: 'الْحَمْدُ لِلَّه طَيِّبْ. إِيشْ اسْمَكْ وَمِنْ وِينْ أَنْتَ؟',
          transliteration: 'Alhamdulillah tayyib. Esh ismak wa min wen anta?',
        },
        indonesian: 'Saya juga baik. Siapa namamu dan dari mana asalmu?',
        grammarSpotlight:
          'Dalam Ammiyah Saudi, kata tanya "Ma" bergeser menjadi "Esh" (di Hijaz/umum Saudi) atau "Shinu" (di wilayah Timur), dan "Ayna" selalu menjadi "Wen".',
        tokens: [
          {
            fusha: 'مَا اسْمُكَ',
            fushaTranslit: 'mas-muka',
            ammiyah: 'إِيشْ اسْمَكْ',
            ammiyahTranslit: 'esh ismak',
            meaning: 'siapa namamu',
          },
          {
            fusha: 'مِنْ أَيْنَ',
            fushaTranslit: 'min ayna',
            ammiyah: 'مِنْ وِينْ',
            ammiyahTranslit: 'min wen',
            meaning: 'dari mana',
          },
        ],
      },
      {
        id: 'g-4',
        speaker: 'Anda',
        role: 'Pembelajar',
        isLearner: true,
        fusha: {
          arabic: 'اِسْمِي رِضْوَان، وَأَنَا مِنْ إِنْدُونِيسِيَا. تَشَرَّفْنَا بِمَعْرِفَتِكَ.',
          transliteration: 'Ismi Ridwan, wa ana min Indunisiya. Tasharrafna bima‘rifatika.',
        },
        ammiyah: {
          arabic: 'اِسْمِي رِضْوَان، أَنَا مِنْ إِنْدُونِيسِيَا. تَشَرَّفْنَا يَا طَيِّبْ.',
          transliteration: 'Ismi Ridwan, ana min Indunisiya. Tasharrafna ya tayyib.',
          dialectNote: '"Ya tayyib" atau "Ya ghali" adalah sapaan ramah yang sering dipakai di Saudi.',
        },
        indonesian: 'Nama saya Ridwan, saya dari Indonesia. Senang berkenalan denganmu.',
        grammarSpotlight:
          'Sapaan penghormatan di Arab Saudi sering memanggil lawan bicara dengan "Ya tayyib" (orang baik) atau "Ya akhi" (saudaraku).',
        tokens: [
          {
            fusha: 'تَشَرَّفْنَا بِمَعْرِفَتِكَ',
            fushaTranslit: 'tasharrafna bima‘rifatika',
            ammiyah: 'تَشَرَّفْنَا يَا طَيِّبْ',
            ammiyahTranslit: 'tasharrafna ya tayyib',
            meaning: 'senang berkenalan',
          },
        ],
      },
      {
        id: 'g-5',
        speaker: 'Thariq',
        role: 'Rekan Baru',
        isLearner: false,
        fusha: {
          arabic: 'أَهْلًا بِأَهْلِ إِنْدُونِيسِيَا! هَلْ تَتَحَدَّثُ الْعَرَبِيَّةَ جَيِّدًا؟',
          transliteration: 'Ahlan bi-ahli Indunisiya! Hal tatahad-dathul-‘arabiyyata jayyidan?',
        },
        ammiyah: {
          arabic: 'وَالنِّعْمْ بِأَهْلْ إِنْدُونِيسِيَا! تِتْكَلَّمْ عَرَبِي زِينْ؟',
          transliteration: 'Wan-ni‘m bi-ahl Indunisiya! Titkallam ‘arabi zen?',
          dialectNote: '"Wan-ni‘m" adalah ungkapan pujian hormat khas Saudi terhadap asal/keluarga seseorang.',
        },
        indonesian: 'Salam hormat untuk orang Indonesia! Apakah kamu berbicara bahasa Arab dengan baik?',
        grammarSpotlight:
          'Ammiyah Saudi tidak memakai partikel "Hal" di awal pertanyaan, dan tidak memakai awalan "bi-" (seperti Mesir/Syam) pada kata kerja biasa: cukup "Titkallam".',
        tokens: [
          {
            fusha: 'هَلْ تَتَحَدَّثُ',
            fushaTranslit: 'hal tatahad-dathu',
            ammiyah: 'تِتْكَلَّمْ',
            ammiyahTranslit: 'titkallam',
            meaning: 'apakah kamu berbicara',
          },
          {
            fusha: 'جَيِّدًا',
            fushaTranslit: 'jayyidan',
            ammiyah: 'زِينْ / كْوَيِّسْ',
            ammiyahTranslit: 'zen / kwayyis',
            meaning: 'dengan baik / bagus',
          },
        ],
      },
    ],
  },
  {
    id: 'cafe',
    number: '02',
    title: 'Memesan di Kafe & Restoran',
    subtitle: 'Memesan teh mint dan kopi Saudi (qahwah), mengatur gula, dan meminta tagihan.',
    level: 'Dasar',
    recommendedRegister: 'Dominan Ammiyah',
    estimatedMinutes: 7,
    imagePath: '/src/assets/images/scene_cafe_cairo_1795242472731.jpg',
    culturalNote:
      'Di kafe atau restoran Arab Saudi, kata "Abgha" (saya mau) dan "Abshir" (siap/baik) sangat sering terdengar. Jika memesan di Riyadh atau Jeddah, menyebut "Law samaht" sudah cukup sopan dan natural.',
    turns: [
      {
        id: 'c-1',
        speaker: 'Pelayan',
        role: 'Barista Kafe',
        isLearner: false,
        fusha: {
          arabic: 'أَهْلًا بِكُمْ، مَاذَا تُرِيدُونَ أَنْ تَشْرَبُوا الْيَوْمَ؟',
          transliteration: 'Ahlan bikum, maza turiduna an tashrabul-yawm?',
        },
        ammiyah: {
          arabic: 'حَيَّاكُمُ اللَّه، إِيشْ تِبْغَوْنَ تِشْرَبُونْ الْيَوْم؟',
          transliteration: 'Hayyakumullah, esh tibghon tishrabun al-yom?',
        },
        indonesian: 'Selamat datang, kalian ingin minum apa hari ini?',
        grammarSpotlight:
          'Kata kerja "Turiduna" (Fushah) berubah menjadi "Tibghon" (dari akar "bagha" = menginginkan) dalam Ammiyah Arab Saudi.',
        tokens: [
          {
            fusha: 'مَاذَا تُرِيدُونَ',
            fushaTranslit: 'maza turiduna',
            ammiyah: 'إِيشْ تِبْغَوْنَ',
            ammiyahTranslit: 'esh tibghon',
            meaning: 'kalian ingin apa',
          },
          {
            fusha: 'الْيَوْمَ',
            fushaTranslit: 'al-yawm',
            ammiyah: 'الْيَوْم',
            ammiyahTranslit: 'al-yom',
            meaning: 'hari ini',
          },
        ],
      },
      {
        id: 'c-2',
        speaker: 'Anda',
        role: 'Pengunjung',
        isLearner: true,
        fusha: {
          arabic: 'مِنْ فَضْلِكَ، أُرِيدُ شَايًا بِالنَّعْنَاعِ وَفِنْجَانَ قَهْوَةٍ.',
          transliteration: 'Min fadlika, uridu shayan bin-na‘na‘i wa finjana qahwah.',
        },
        ammiyah: {
          arabic: 'لَوْ سَمَحْتْ، أَبْغَى شَايْ بِالنَّعْنَاعْ وَفِنْجَانْ قَهْوَة.',
          transliteration: 'Law samaht, abgha shay bin-na‘na‘ wa finjan gahwah.',
          dialectNote: 'Di wilayah Najd/Riyadh, huruf Qaf pada "qahwah" sering terdengar "gahwah".',
        },
        indonesian: 'Permisi, saya mau teh mint dan secangkir kopi.',
        grammarSpotlight:
          '"Uridu" (saya mau) di Arab Saudi paling umum menggunakan "Abgha" (atau "Abi" di Riyadh). Bentuknya sama untuk pria maupun wanita.',
        tokens: [
          {
            fusha: 'مِنْ فَضْلِكَ',
            fushaTranslit: 'min fadlika',
            ammiyah: 'لَوْ سَمَحْتْ',
            ammiyahTranslit: 'law samaht',
            meaning: 'permisi / tolong',
          },
          {
            fusha: 'أُرِيدُ',
            fushaTranslit: 'uridu',
            ammiyah: 'أَبْغَى / أَبِي',
            ammiyahTranslit: 'abgha / abi',
            meaning: 'saya mau',
          },
        ],
      },
      {
        id: 'c-3',
        speaker: 'Pelayan',
        role: 'Barista Kafe',
        isLearner: false,
        fusha: {
          arabic: 'حَاضِرٌ. كَيْفَ تُفَضِّلُ السُّكَّرَ فِي الشَّايِ؟',
          transliteration: 'Hadirun. Kayfa tufaddilus-sukkara fish-shay?',
        },
        ammiyah: {
          arabic: 'أَبْشِرْ. كِيفْ تِبْغَى السُّكَّرْ؟ وَسَطْ وَلَّا زِيَادَة؟',
          transliteration: 'Abshir. Kef tibgha is-sukkar? Wasat walla ziyadah?',
        },
        indonesian: 'Siap. Bagaimana takaran gula di tehnya? Sedang atau ekstra manis?',
        grammarSpotlight:
          '"Abshir!" (secara harfiah: bergembiralah) adalah jawaban khas Saudi yang berarti "Siap, beres, dengan senang hati!".',
        tokens: [
          {
            fusha: 'حَاضِرٌ',
            fushaTranslit: 'hadirun',
            ammiyah: 'أَبْشِرْ',
            ammiyahTranslit: 'abshir',
            meaning: 'siap / baik (dengan senang hati)',
          },
          {
            fusha: 'أَمْ',
            fushaTranslit: 'am',
            ammiyah: 'وَلَّا',
            ammiyahTranslit: 'walla',
            meaning: 'atau (dalam pilihan)',
          },
        ],
      },
      {
        id: 'c-4',
        speaker: 'Anda',
        role: 'Pengunjung',
        isLearner: true,
        fusha: {
          arabic: 'أُرِيدُهُ بِسُكَّرٍ قَلِيلٍ، وَلَا أُرِيدُ ثَلْجًا.',
          transliteration: 'Uriduhu bisukkarin qalilin, wa la uridu thaljan.',
        },
        ammiyah: {
          arabic: 'أَبْغَاهْ سُكَّرْ خَفِيفْ، وَمَا أَبْغَى ثَلْجْ أَبَدًا.',
          transliteration: 'Abghah sukkar khafif, wa ma abgha thalj abadan.',
        },
        indonesian: 'Saya mau gulanya sedikit saja, dan tidak mau es sama sekali.',
        grammarSpotlight:
          'Untuk menegasikan kata kerja di Ammiyah Saudi, cukup letakkan "Ma" di depan kata kerja tanpa akhiran "-sh": "Ma abgha" (saya tidak mau).',
        tokens: [
          {
            fusha: 'لَا أُرِيدُ',
            fushaTranslit: 'la uridu',
            ammiyah: 'مَا أَبْغَى',
            ammiyahTranslit: 'ma abgha',
            meaning: 'saya tidak mau',
          },
          {
            fusha: 'قَلِيلٍ',
            fushaTranslit: 'qalil',
            ammiyah: 'خَفِيفْ / شْوَيّ',
            ammiyahTranslit: 'khafif / shwayy',
            meaning: 'ringan / sedikit',
          },
        ],
      },
      {
        id: 'c-5',
        speaker: 'Anda',
        role: 'Pengunjung',
        isLearner: true,
        fusha: {
          arabic: 'عَفْوًا، هَلْ يُمْكِنُنِي الْحُصُولُ عَلَى الْفَاتُورَةِ؟',
          transliteration: '‘Afwan, hal yumkinunil-husulu ‘alal-faturah?',
        },
        ammiyah: {
          arabic: 'لَوْ سَمَحْتْ، مُمْكِنْ الْحِسَابْ أَوِ الْفَاتُورَة؟',
          transliteration: 'Law samaht, mumkin al-hisab awil-faturah?',
        },
        indonesian: 'Permisi, boleh saya minta tagihannya (struk)?',
        grammarSpotlight:
          'Di Arab Saudi, baik "Al-hisab" maupun "Al-faturah" sama-sama umum dipakai untuk meminta tagihan di kafe atau restoran.',
        tokens: [
          {
            fusha: 'الْفَاتُورَةِ',
            fushaTranslit: 'al-faturah',
            ammiyah: 'الْحِسَابْ / الْفَاتُورَة',
            ammiyahTranslit: 'al-hisab / al-faturah',
            meaning: 'tagihan / bill',
          },
        ],
      },
    ],
  },
  {
    id: 'market',
    number: '03',
    title: 'Belanja & Menawar di Pasar Saudi',
    subtitle: 'Menanyakan harga dalam Riyal, menilai kualitas, dan menawar dengan sopan.',
    level: 'Menengah',
    recommendedRegister: 'Dominan Ammiyah',
    estimatedMinutes: 8,
    imagePath: '/src/assets/images/scene_market_souq_1795242473149.jpg',
    culturalNote:
      'Di pasar tradisional Makkah, Madinah, atau Riyadh (seperti Souq Al-Zal), pedagang sangat menghargai pembeli yang ramah. Kata "Marrah" (sangat) dan "Riyal" adalah bagian wajib percakapan belanja di Saudi.',
    turns: [
      {
        id: 'm-1',
        speaker: 'Anda',
        role: 'Pembeli',
        isLearner: true,
        fusha: {
          arabic: 'لَوْ سَمَحْتَ، بِكَمْ هَذِهِ الْحَقِيبَةُ الْجِلْدِيَّةُ؟',
          transliteration: 'Law samahta, bikam hazihil-haqibatul-jildiyyah?',
        },
        ammiyah: {
          arabic: 'لَوْ سَمَحْتْ، بِكَمْ هَذِي الشَّنْطَة الْجِلْدْ؟',
          transliteration: 'Law samaht, bikam hazi ish-shantah il-jild?',
          dialectNote: 'Di Saudi huruf Jim (ج) tetap dilafalkan lembut ("jild", bukan "gild").',
        },
        indonesian: 'Permisi, berapa harga tas kulit ini?',
        grammarSpotlight:
          'Berbeda dengan Mesir yang menaruh kata tunjuk di belakang, Ammiyah Saudi tetap meletakkan "Hadha / Hazi" di depan kata benda, mirip dengan Fushah.',
        tokens: [
          {
            fusha: 'هَذِهِ الْحَقِيبَةُ',
            fushaTranslit: 'hazihil-haqibah',
            ammiyah: 'هَذِي الشَّنْطَة',
            ammiyahTranslit: 'hazi ish-shantah',
            meaning: 'tas ini',
          },
          {
            fusha: 'بِكَمْ',
            fushaTranslit: 'bikam',
            ammiyah: 'بِكَمْ',
            ammiyahTranslit: 'bikam',
            meaning: 'berapa harganya',
          },
        ],
      },
      {
        id: 'm-2',
        speaker: 'Pedagang',
        role: 'Pemilik Toko',
        isLearner: false,
        fusha: {
          arabic: 'سِعْرُهَا مِائَتَا رِيَالٍ. جَوْدَتُهَا مُمْتَازَةٌ جِدًّا.',
          transliteration: 'Si‘ruha mi’ata riyalin. Jawdatuha mumtazatun jiddan.',
        },
        ammiyah: {
          arabic: 'هَذِي بِمِئَتَيْنْ رِيَالْ. جَوْدَتْهَا مَرَّة مُمْتَازَة.',
          transliteration: 'Hazi bimitayn riyal. Jawdatha marrah mumtazah.',
        },
        indonesian: 'Harganya dua ratus riyal. Kualitasnya sangat bagus.',
        grammarSpotlight:
          'Kata "Marrah" (secara harfiah: satu kali) dalam Ammiyah Saudi berfungsi sebagai penguat yang berarti "sangat / sekali", menggantikan "Jiddan".',
        tokens: [
          {
            fusha: 'مِائَتَا رِيَالٍ',
            fushaTranslit: 'mi’ata riyalin',
            ammiyah: 'مِئَتَيْنْ رِيَالْ',
            ammiyahTranslit: 'mitayn riyal',
            meaning: 'dua ratus riyal',
          },
          {
            fusha: 'جِدًّا',
            fushaTranslit: 'jiddan',
            ammiyah: 'مَرَّة',
            ammiyahTranslit: 'marrah',
            meaning: 'sangat / sekali',
          },
        ],
      },
      {
        id: 'm-3',
        speaker: 'Anda',
        role: 'Pembeli',
        isLearner: true,
        fusha: {
          arabic: 'هَذَا غَالٍ قَلِيلًا. هَلْ يُمْكِنُكَ تَخْفِيضُ السِّعْرِ؟',
          transliteration: 'Haza ghalin qalilan. Hal yumkinuka takhfidus-si‘r?',
        },
        ammiyah: {
          arabic: 'غَالِيَة شْوَيّ، مُمْكِنْ تِنَقِّصْ فِي السِّعْرْ؟',
          transliteration: 'Ghaliyah shwayy, mumkin tinaqqis fis-si‘r?',
          dialectNote: 'Ungkapan tawar sopan lain di Saudi: "Tira‘ina fis-si‘r?" (Bisa bantu beri harga khusus?).',
        },
        indonesian: 'Agak mahal ya. Bisakah Anda menurunkan harganya?',
        grammarSpotlight:
          '"Qalilan" (sedikit) menjadi "Shwayy", dan kata kerja menawar "Takhfid" lebih umum diucapkan "Tinaqqis" (mengurangi).',
        tokens: [
          {
            fusha: 'قَلِيلًا',
            fushaTranslit: 'qalilan',
            ammiyah: 'شْوَيّ',
            ammiyahTranslit: 'shwayy',
            meaning: 'sedikit / agak',
          },
          {
            fusha: 'تَخْفِيضُ السِّعْرِ',
            fushaTranslit: 'takhfidus-si‘r',
            ammiyah: 'تِنَقِّصْ فِي السِّعْرْ',
            ammiyahTranslit: 'tinaqqis fis-si‘r',
            meaning: 'mengurangi harga',
          },
        ],
      },
      {
        id: 'm-4',
        speaker: 'Pedagang',
        role: 'Pemilik Toko',
        isLearner: false,
        fusha: {
          arabic: 'مِنْ أَجْلِكَ فَقَطْ، سَأَجْعَلُهَا بِمِائَةٍ وَسَبْعِينَ رِيَالًا.',
          transliteration: 'Min ajlika faqat, sa-aj‘aluha bimi’atin wa sab‘ina riyalan.',
        },
        ammiyah: {
          arabic: 'عَلَشَانَكْ أَنْتَ بَسْ، خُذْهَا بِمِيَّة وَسَبْعِينْ رِيَالْ.',
          transliteration: '‘Alashanak anta bas, khudha bimiyyah wa sab‘in riyal.',
        },
        indonesian: 'Khusus untukmu saja, ambillah dengan harga seratus tujuh puluh riyal.',
        grammarSpotlight:
          '"Min ajlika" (demi kamu) menjadi "‘Alashanak" atau "‘Ashanak", dan "Faqat" (saja) menjadi "Bas".',
        tokens: [
          {
            fusha: 'مِنْ أَجْلِكَ',
            fushaTranslit: 'min ajlika',
            ammiyah: 'عَلَشَانَكْ',
            ammiyahTranslit: '‘alashanak',
            meaning: 'untukmu / demi kamu',
          },
          {
            fusha: 'فَقَطْ',
            fushaTranslit: 'faqat',
            ammiyah: 'بَسْ',
            ammiyahTranslit: 'bas',
            meaning: 'saja / cukup',
          },
        ],
      },
    ],
  },
  {
    id: 'directions',
    number: '04',
    title: 'Menanyakan Arah & Transportasi',
    subtitle: 'Navigasi kota di Riyadh atau Jeddah, mencari stasiun metro, dan arah belokan.',
    level: 'Dasar',
    recommendedRegister: 'Fushah & Ammiyah',
    estimatedMinutes: 6,
    imagePath: '/src/assets/images/hero_arabic_study_1795242471897.jpg',
    culturalNote:
      'Rambu jalan raya di Arab Saudi ditulis dalam Fushah, sementara sopir taksi atau petugas keamanan memberikan petunjuk lisan dalam Ammiyah Saudi seperti "‘Ala tul" atau "Sidah" (lurus terus) dan "Dawwar" (bundaran).',
    turns: [
      {
        id: 'd-1',
        speaker: 'Anda',
        role: 'Wisatawan',
        isLearner: true,
        fusha: {
          arabic: 'عَفْوًا، أَيْنَ تَقَعُ مَحَطَّةُ الْمِتْرُو الْقَرِيبَةُ مِنْ هُنَا؟',
          transliteration: '‘Afwan, ayna taqa‘u mahattatul-mitrul-qaribatu min huna?',
        },
        ammiyah: {
          arabic: 'لَوْ سَمَحْتْ، وِينْ أَقْرَبْ مَحَطَّة مِتْرُو مِنْ هِنَا؟',
          transliteration: 'Law samaht, wen aqrab mahattat mitru min hina?',
        },
        indonesian: 'Permisi, di mana stasiun metro terdekat dari sini?',
        grammarSpotlight:
          '"Ayna" (di mana) dalam Fushah menjadi "Wen" di seluruh wilayah Arab Saudi.',
        tokens: [
          {
            fusha: 'أَيْنَ',
            fushaTranslit: 'ayna',
            ammiyah: 'وِينْ',
            ammiyahTranslit: 'wen',
            meaning: 'di mana',
          },
          {
            fusha: 'هُنَا',
            fushaTranslit: 'huna',
            ammiyah: 'هِنَا',
            ammiyahTranslit: 'hina',
            meaning: 'di sini',
          },
        ],
      },
      {
        id: 'd-2',
        speaker: 'Warga Lokal',
        role: 'Pejalan Kaki',
        isLearner: false,
        fusha: {
          arabic: 'اِمْشِ مُبَاشَرَةً إِلَى الْأَمَامِ، ثُمَّ انْعَطِفْ يَمِينًا عِنْدَ الدَّوَّارِ.',
          transliteration: 'Imshi mubasharatan ilal-amam, thumma in‘atif yaminan ‘indad-dawwar.',
        },
        ammiyah: {
          arabic: 'رُوحْ عَلَى طُولْ، وَبَعْدِينْ لِفْ يَمِينْ عِنْدْ الدَّوَّارْ.',
          transliteration: 'Ruh ‘ala tul, wa ba‘den liff yamin ‘ind id-dawwar.',
          dialectNote: 'Kata "Sidah" (سِيدَة) juga sangat umum dipakai di Saudi untuk "lurus terus".',
        },
        indonesian: 'Jalan lurus terus ke depan, lalu belok kanan di bundaran.',
        grammarSpotlight:
          '"‘Ala tul" atau "Sidah" berarti lurus terus, sedangkan "In‘atif" (Fushah) disederhanakan menjadi "Liff" (beloklah).',
        tokens: [
          {
            fusha: 'مُبَاشَرَةً',
            fushaTranslit: 'mubasharatan',
            ammiyah: 'عَلَى طُولْ / سِيدَة',
            ammiyahTranslit: '‘ala tul / sidah',
            meaning: 'lurus terus',
          },
          {
            fusha: 'اِنْعَطِفْ',
            fushaTranslit: 'in‘atif',
            ammiyah: 'لِفْ',
            ammiyahTranslit: 'liff',
            meaning: 'beloklah',
          },
        ],
      },
      {
        id: 'd-3',
        speaker: 'Anda',
        role: 'Wisatawan',
        isLearner: true,
        fusha: {
          arabic: 'هَلْ هِيَ بَعِيدَةٌ؟ كَمْ دَقِيقَةً تَسْتَغْرِقُ مَشْيًا؟',
          transliteration: 'Hal hiya ba‘idah? Kam daqiqatan tastaghriqu mashyan?',
        },
        ammiyah: {
          arabic: 'هِيَ بَعِيدَة؟ كَمْ تَاخُذْ دَقِيقَة مَشْيْ؟',
          transliteration: 'Hiya ba‘idah? Kam takhud daqiqah mashy?',
        },
        indonesian: 'Apakah jauh? Kira-kira butuh berapa menit berjalan kaki?',
        grammarSpotlight:
          'Untuk menyatakan durasi, Fushah memakai "Tastaghriqu", sedangkan Ammiyah Saudi memakai "Takhud" (memakan waktu).',
        tokens: [
          {
            fusha: 'تَسْتَغْرِقُ',
            fushaTranslit: 'tastaghriqu',
            ammiyah: 'تَاخُذْ',
            ammiyahTranslit: 'takhud',
            meaning: 'memakan waktu',
          },
        ],
      },
      {
        id: 'd-4',
        speaker: 'Warga Lokal',
        role: 'Pejalan Kaki',
        isLearner: false,
        fusha: {
          arabic: 'لَا، إِنَّهَا قَرِيبَةٌ جِدًّا، خَمْسُ دَقَائِقَ فَقَطْ.',
          transliteration: 'La, innaha qaribatun jiddan, khamsu daqa’iqa faqat.',
        },
        ammiyah: {
          arabic: 'لَا، قَرِيبَة مَرَّة، خَمْسْ دَقَايِقْ بَسْ.',
          transliteration: 'La, qaribah marrah, khams daqayiq bas.',
        },
        indonesian: 'Tidak, dekat sekali kok, cuma lima menit.',
        grammarSpotlight:
          'Perhatikan "Qaribatun jiddan" (Fushah) diringkas menjadi "Qaribah marrah" (dekat banget) dengan vokal akhiran disukunkan.',
        tokens: [
          {
            fusha: 'قَرِيبَةٌ جِدًّا',
            fushaTranslit: 'qaribatun jiddan',
            ammiyah: 'قَرِيبَة مَرَّة',
            ammiyahTranslit: 'qaribah marrah',
            meaning: 'dekat sekali',
          },
        ],
      },
    ],
  },
  {
    id: 'work_plans',
    number: '05',
    title: 'Pekerjaan, Studi & Rencana Akhir Pekan',
    subtitle: 'Membicarakan aktivitas rutin, profesi, dan janji mengobrol santai dengan rekan.',
    level: 'Menengah',
    recommendedRegister: 'Fushah & Ammiyah',
    estimatedMinutes: 8,
    imagePath: '/src/assets/images/scene_formal_forum_1795242472597.jpg',
    culturalNote:
      'Dalam lingkungan kerja atau universitas di Arab Saudi (seperti KSU Riyadh atau Universitas Islam Madinah), Fushah dipakai saat rapat/kuliah, sementara Ammiyah Saudiyah dipakai saat mengobrol santai ("nisulif") dengan teman.',
    turns: [
      {
        id: 'w-1',
        speaker: 'Salman',
        role: 'Rekan Diskusi',
        isLearner: false,
        fusha: {
          arabic: 'مَاذَا تَعْمَلُ حَالِيًّا؟ هَلْ تَدْرُسُ أَمْ تَعْمَلُ؟',
          transliteration: 'Maza ta‘malu haliyyan? Hal tadrusu am ta‘mal?',
        },
        ammiyah: {
          arabic: 'إِيشْ تِشْتَغِلْ الْحِينْ؟ تِدْرُسْ وَلَّا تِشْتَغِلْ؟',
          transliteration: 'Esh tishtaghal al-hin? Tidrus walla tishtaghal?',
        },
        indonesian: 'Apa kesibukanmu sekarang? Sedang kuliah atau bekerja?',
        grammarSpotlight:
          '"Al-an / Haliyyan" (sekarang) di Arab Saudi hampir selalu menggunakan kata "Al-hin" (gabungan dari hadha al-hin = saat ini).',
        tokens: [
          {
            fusha: 'تَعْمَلُ',
            fushaTranslit: 'ta‘malu',
            ammiyah: 'تِشْتَغِلْ',
            ammiyahTranslit: 'tishtaghal',
            meaning: 'kamu bekerja',
          },
          {
            fusha: 'حَالِيًّا / الْآنَ',
            fushaTranslit: 'haliyyan / al-an',
            ammiyah: 'الْحِينْ',
            ammiyahTranslit: 'al-hin',
            meaning: 'sekarang / saat ini',
          },
        ],
      },
      {
        id: 'w-2',
        speaker: 'Anda',
        role: 'Pembelajar',
        isLearner: true,
        fusha: {
          arabic: 'أَعْمَلُ مُهَنْدِسَ بَرْمَجِيَّاتٍ، وَأَتَعَلَّمُ اللُّغَةَ الْعَرَبِيَّةَ فِي وَقْتِ فَرَاغِي.',
          transliteration: 'A‘malu muhandisa barmajiyyat, wa ata‘allamul-lughatal-‘arabiyyata fi waqti faraghi.',
        },
        ammiyah: {
          arabic: 'أَشْتَغِلْ مُهَنْدِسْ بَرْمَجَة، وَأَتَعَلَّمْ عَرَبِي فِي وَقْتْ فَرَاغِي.',
          transliteration: 'Ashtaghal muhandis barmajah, wa ata‘allam ‘arabi fi waqt faraghi.',
        },
        indonesian: 'Saya bekerja sebagai insinyur perangkat lunak, dan belajar bahasa Arab di waktu luang.',
        grammarSpotlight:
          'Keunggulan belajar Ammiyah Saudi: awalan kata kerja mudhori’ untuk "saya" tetap memakai "a-" ("ata‘allam", "ashtaghal"), sangat dekat dengan struktur Fushah!',
        tokens: [
          {
            fusha: 'أَعْمَلُ',
            fushaTranslit: 'a‘malu',
            ammiyah: 'أَشْتَغِلْ',
            ammiyahTranslit: 'ashtaghal',
            meaning: 'saya bekerja',
          },
        ],
      },
      {
        id: 'w-3',
        speaker: 'Salman',
        role: 'Rekan Diskusi',
        isLearner: false,
        fusha: {
          arabic: 'مُمْتَازٌ! مَا رَأْيُكَ أَنْ نَلْتَقِيَ غَدًا لِنَتَبَادَلَ الْأَحَادِيثَ؟',
          transliteration: 'Mumtaz! Ma ra’yuka an naltaqiya ghadan linatabadalal-ahadith?',
        },
        ammiyah: {
          arabic: 'مُمْتَازْ مَرَّة! إِيشْ رَأْيَكْ نِتْقَابَلْ بُكْرَة عَشَانْ نِسُولِفْ سَوَا؟',
          transliteration: 'Mumtaz marrah! Esh ra’yak nitqabal bukrah ‘ashan nisulif sawa?',
          dialectNote: '"Nisulif" (dari "salifah") berarti ngobrol santai atau bertukar cerita.',
        },
        indonesian: 'Keren sekali! Bagaimana pendapatmu kalau kita bertemu besok untuk mengobrol bersama?',
        grammarSpotlight:
          '"Ghadan" (besok) menjadi "Bukrah", dan "Natabadalal-ahadith" (bertukar pembicaraan) menjadi ungkapan akrab "Nisulif sawa".',
        tokens: [
          {
            fusha: 'غَدًا',
            fushaTranslit: 'ghadan',
            ammiyah: 'بُكْرَة',
            ammiyahTranslit: 'bukrah',
            meaning: 'besok',
          },
          {
            fusha: 'مَعًا',
            fushaTranslit: 'ma‘an',
            ammiyah: 'سَوَا',
            ammiyahTranslit: 'sawa',
            meaning: 'bersama-sama',
          },
        ],
      },
      {
        id: 'w-4',
        speaker: 'Anda',
        role: 'Pembelajar',
        isLearner: true,
        fusha: {
          arabic: 'فِكْرَةٌ رَائِعَةٌ، سَأَكُونُ مَسْرُورًا بِذَلِكَ إِنْ شَاءَ اللَّهُ.',
          transliteration: 'Fikratun ra’i‘ah, sa-akunu masruran bizalika in sha’a Allah.',
        },
        ammiyah: {
          arabic: 'فِكْرَة حِلْوَة، بِإِذْنِ اللَّه بَكُونْ مَبْسُوطْ جِدًّا.',
          transliteration: 'Fikrah hilwah, bi-iznillah bakun mabsut jiddan.',
        },
        indonesian: 'Ide bagus, insyaallah saya akan senang sekali dengan rencana itu.',
        grammarSpotlight:
          'Penanda masa depan Fushah "Sa-" ("sa-akunu") di Ammiyah Saudi sering menggunakan awalan "ba-" ("bakun") atau kata "rah" ("rah akun").',
        tokens: [
          {
            fusha: 'سَأَكُونُ',
            fushaTranslit: 'sa-akunu',
            ammiyah: 'بَكُونْ',
            ammiyahTranslit: 'bakun',
            meaning: 'saya akan ada/menjadi',
          },
          {
            fusha: 'مَسْرُورًا',
            fushaTranslit: 'masruran',
            ammiyah: 'مَبْسُوطْ',
            ammiyahTranslit: 'mabsut',
            meaning: 'senang / gembira',
          },
        ],
      },
    ],
  },
  {
    id: 'health',
    number: '06',
    title: 'Di Apotek & Keadaan Darurat',
    subtitle: 'Menjelaskan keluhan ringan, meminta obat di apotek Saudi, dan mendoakan kesembuhan.',
    level: 'Menengah',
    recommendedRegister: 'Fushah & Ammiyah',
    estimatedMinutes: 7,
    imagePath: '/src/assets/images/scene_cafe_cairo_1795242472731.jpg',
    culturalNote:
      'Di apotek Arab Saudi (seperti Nahdi atau Al-Dawaa), menguasai ungkapan keluhan seperti "Rasi yi‘awwirni" (kepala saya sakit) serta ungkapan empati Saudi "Salamtak" / "Ma tishuf sharr" sangat membantu komunikasi cepat.',
    turns: [
      {
        id: 'h-1',
        speaker: 'Anda',
        role: 'Pasien',
        isLearner: true,
        fusha: {
          arabic: 'لَوْ سَمَحْتَ يَا دُكْتُور، أَشْعُرُ بِصُدَاعٍ شَدِيدٍ مُنْذُ الصَّبَاحِ.',
          transliteration: 'Law samahta ya duktur, ash‘uru bisuda‘in shadidin munzus-sabah.',
        },
        ammiyah: {
          arabic: 'لَوْ سَمَحْتْ يَا دُكْتُورْ، رَاسِي يِعَوِّرْنِي مَرَّة مِنْ الصُّبْحْ.',
          transliteration: 'Law samaht ya duktur, rasi yi‘awwirni marrah min is-subh.',
        },
        indonesian: 'Permisi Dok, kepala saya terasa sakit sekali sejak pagi.',
        grammarSpotlight:
          'Untuk menyatakan bagian tubuh terasa sakit dalam Ammiyah Saudi, kata kerja khas yang dipakai adalah "Yi‘awwirni" (menyakitiku).',
        tokens: [
          {
            fusha: 'أَشْعُرُ بِصُدَاعٍ',
            fushaTranslit: 'ash‘uru bisuda‘',
            ammiyah: 'رَاسِي يِعَوِّرْنِي',
            ammiyahTranslit: 'rasi yi‘awwirni',
            meaning: 'kepala saya sakit',
          },
          {
            fusha: 'مُنْذُ الصَّبَاحِ',
            fushaTranslit: 'munzus-sabah',
            ammiyah: 'مِنْ الصُّبْحْ',
            ammiyahTranslit: 'min is-subh',
            meaning: 'sejak pagi',
          },
        ],
      },
      {
        id: 'h-2',
        speaker: 'Apoteker',
        role: 'Tenaga Medis',
        isLearner: false,
        fusha: {
          arabic: 'أَلْفُ سَلَامَةٍ عَلَيْكَ. هَلْ تُعَانِي مِنْ حُمَّى أَوْ سُعَالٍ؟',
          transliteration: 'Alfu salamatin ‘alayka. Hal tu‘ani min humma aw su‘al?',
        },
        ammiyah: {
          arabic: 'سَلَامْتَكْ مَا تِشُوفْ شَرّ. عِنْدَكْ حَرَارَة أَوْ كَحَّة؟',
          transliteration: 'Salamtak, ma tishuf sharr. ‘Indak hararah aw kahhah?',
        },
        indonesian: 'Semoga lekas sembuh. Apakah Anda mengalami demam atau batuk?',
        grammarSpotlight:
          '"Salamtak, ma tishuf sharr" (semoga selamat, semoga tidak menimpa keburukan) adalah doa kesembuhan yang paling umum di Arab Saudi.',
        tokens: [
          {
            fusha: 'حُمَّى',
            fushaTranslit: 'humma',
            ammiyah: 'حَرَارَة / سُخُونَة',
            ammiyahTranslit: 'hararah / sukhunah',
            meaning: 'demam / panas badan',
          },
          {
            fusha: 'سُعَالٌ',
            fushaTranslit: 'su‘al',
            ammiyah: 'كَحَّة',
            ammiyahTranslit: 'kahhah',
            meaning: 'batuk',
          },
        ],
      },
      {
        id: 'h-3',
        speaker: 'Anda',
        role: 'Pasien',
        isLearner: true,
        fusha: {
          arabic: 'لَا، لَيْسَ عِنْدِي حُمَّى. أَحْتَاجُ إِلَى دَوَاءٍ مُسَكِّنٍ فَقَطْ.',
          transliteration: 'La, laysa ‘indi humma. Ahtaju ila dawa’in musakkinin faqat.',
        },
        ammiyah: {
          arabic: 'لَا، مَا عِنْدِي حَرَارَة. أَبْغَى مُسَكِّنْ بَسْ.',
          transliteration: 'La, ma ‘indi hararah. Abgha musakkin bas.',
        },
        indonesian: 'Tidak, saya tidak demam. Saya hanya butuh obat pereda nyeri.',
        grammarSpotlight:
          'Kepemilikan negatif "Laysa ‘indi" (saya tidak punya) di Ammiyah Saudi cukup menggunakan "Ma ‘indi" (tanpa akhiran -sh).',
        tokens: [
          {
            fusha: 'لَيْسَ عِنْدِي',
            fushaTranslit: 'laysa ‘indi',
            ammiyah: 'مَا عِنْدِي',
            ammiyahTranslit: 'ma ‘indi',
            meaning: 'saya tidak punya',
          },
          {
            fusha: 'أَحْتَاجُ إِلَى',
            fushaTranslit: 'ahtaju ila',
            ammiyah: 'أَبْغَى / مِحْتَاجْ',
            ammiyahTranslit: 'abgha / mihtaj',
            meaning: 'saya butuh / mau',
          },
        ],
      },
      {
        id: 'h-4',
        speaker: 'Apoteker',
        role: 'Tenaga Medis',
        isLearner: false,
        fusha: {
          arabic: 'تَفَضَّلْ، خُذْ قُرْصًا وَاحِدًا بَعْدَ الطَّعَامِ وَأَكْثِرْ مِنْ شُرْبِ الْمَاءِ.',
          transliteration: 'Tafaddal, khuz qursan wahidan ba‘dat-ta‘ami wa akthir min shurbil-ma’.',
        },
        ammiyah: {
          arabic: 'أَبْشِرْ، خُذْ حَبَّة وَحْدَة بَعْدِ الْأَكْلْ وِاشْرَبْ مَوْيَة كِثِيرْ.',
          transliteration: 'Abshir, khud habbah wahdah ba‘d il-akl wishrab moyah kithir.',
        },
        indonesian: 'Silakan, minum satu tablet setelah makan dan perbanyak minum air putih.',
        grammarSpotlight:
          'Air minum dalam Ammiyah Arab Saudi diucapkan "Moyah" (مَوْيَة), sedangkan di Fushah adalah "Al-ma’".',
        tokens: [
          {
            fusha: 'الطَّعَامِ',
            fushaTranslit: 'at-ta‘am',
            ammiyah: 'الْأَكْلْ',
            ammiyahTranslit: 'il-akl',
            meaning: 'makanan / makan',
          },
          {
            fusha: 'الْمَاءِ',
            fushaTranslit: 'al-ma’',
            ammiyah: 'مَوْيَة',
            ammiyahTranslit: 'moyah',
            meaning: 'air minum',
          },
        ],
      },
    ],
  },
];

export interface ComparisonEntry {
  id: string;
  meaning: string;
  fusha: string;
  fushaTranslit: string;
  ammiyah: string;
  ammiyahTranslit: string;
  regionalNote?: string;
  ruleTip: string;
}

export interface ComparisonCategory {
  id: string;
  title: string;
  description: string;
  entries: ComparisonEntry[];
}

export const COMPARISON_GROUPS: ComparisonCategory[] = [
  {
    id: 'interrogatives',
    title: 'Kata Tanya (Adawatul Istifham)',
    description:
      'Kata tanya Ammiyah Saudi sangat ringkas dan mudah dipelajari karena tetap bisa diletakkan di awal kalimat seperti Fushah maupun di akhir kalimat.',
    entries: [
      {
        id: 'q1',
        meaning: 'Apa?',
        fusha: 'مَا / مَاذَا؟',
        fushaTranslit: 'Ma / Maza?',
        ammiyah: 'إِيشْ؟',
        ammiyahTranslit: 'Esh?',
        regionalNote: 'Wilayah Timur/Teluk: Shinu?',
        ruleTip: 'Contoh: "Maza turid?" (Fushah) -> "Esh tibgha?" (Ammiyah Saudi).',
      },
      {
        id: 'q2',
        meaning: 'Di mana?',
        fusha: 'أَيْنَ؟',
        fushaTranslit: 'Ayna?',
        ammiyah: 'وِينْ؟',
        ammiyahTranslit: 'Wen?',
        regionalNote: 'Seragam di seluruh Arab Saudi.',
        ruleTip: 'Contoh: "Ayna al-bayt?" -> "Wen al-bet?".',
      },
      {
        id: 'q3',
        meaning: 'Bagaimana?',
        fusha: 'كَيْفَ؟',
        fushaTranslit: 'Kayfa?',
        ammiyah: 'كِيفْ؟',
        ammiyahTranslit: 'Kef?',
        regionalNote: 'Dari Fushah "Kayfa" yang dipendekkan.',
        ruleTip: 'Contoh: "Kayfa haluka?" -> "Kef halak?".',
      },
      {
        id: 'q4',
        meaning: 'Kenapa / Mengapa?',
        fusha: 'لِمَاذَا؟',
        fushaTranslit: 'Limaza?',
        ammiyah: 'لِيشْ؟',
        ammiyahTranslit: 'Lesh?',
        regionalNote: 'Pemendekan dari "li-ayyi shay’in".',
        ruleTip: 'Contoh: "Limaza ta’akhkharta?" -> "Lesh ta’akhkhart?".',
      },
      {
        id: 'q5',
        meaning: 'Kapan?',
        fusha: 'مَتَى؟',
        fushaTranslit: 'Mata?',
        ammiyah: 'مِتَى؟',
        ammiyahTranslit: 'Mita?',
        ruleTip: 'Sama posisi dan bunyinya, hanya vokal pertama sedikit bergeser ke "i".',
      },
      {
        id: 'q6',
        meaning: 'Siapa?',
        fusha: 'مَنْ؟',
        fushaTranslit: 'Man?',
        ammiyah: 'مِينْ؟',
        ammiyahTranslit: 'Min?',
        ruleTip: 'Hati-hati membedakan "Min" (siapa) dan huruf jar "min" (dari).',
      },
    ],
  },
  {
    id: 'negation',
    title: 'Negasi & Penolakan',
    description:
      'Ammiyah Arab Saudi sangat bersih dan dekat dengan Fushah dalam negasi: memakai "Ma" untuk kata kerja dan "Mu" atau "Mub" untuk kata sifat/benda (tanpa akhiran -sh).',
    entries: [
      {
        id: 'n1',
        meaning: 'Bukan / Tidak (kata sifat / nominal)',
        fusha: 'لَيْسَ / غَيْرُ',
        fushaTranslit: 'Laysa / Ghayru',
        ammiyah: 'مُو / مُوبْ',
        ammiyahTranslit: 'Mu / Mub',
        regionalNote: 'Hijaz: Mu · Najd: Mub',
        ruleTip: 'Contoh: "Laysa jamil" -> "Mu hilw".',
      },
      {
        id: 'n2',
        meaning: 'Saya tidak tahu',
        fusha: 'لَا أَعْرِفُ',
        fushaTranslit: 'La a‘rifu',
        ammiyah: 'مَا أَعْرِفْ / مَا أَدْرِي',
        ammiyahTranslit: 'Ma a‘rif / Ma adri',
        ruleTip: '"Ma adri" sangat populer di Saudi untuk mengatakan "saya kurang tahu".',
      },
      {
        id: 'n3',
        meaning: 'Saya tidak pergi (lampau)',
        fusha: 'لَمْ أَذْهَبْ',
        fushaTranslit: 'Lam azhab',
        ammiyah: 'مَا رُحْتْ',
        ammiyahTranslit: 'Ma ruht',
        ruleTip: 'Fushah pakai "lam + mudhori’", Saudi pakai "ma + kata kerja lampau".',
      },
      {
        id: 'n4',
        meaning: 'Tidak ada / kosong',
        fusha: 'لَا يُوجَدُ',
        fushaTranslit: 'La yujadu',
        ammiyah: 'مَا فِي',
        ammiyahTranslit: 'Ma fi',
        ruleTip: 'Lawan katanya: "Fi" (ada), contoh: "Fi moyah?" (Ada air?).',
      },
    ],
  },
  {
    id: 'verbs',
    title: 'Kata Kerja Sehari-hari',
    description:
      'Kata kerja Ammiyah Saudi tetap menjaga awalan subjek seperti Fushah (tanpa awalan "bi-" khas Mesir/Syam) sehingga lebih mudah dikuasai pemula.',
    entries: [
      {
        id: 'v1',
        meaning: 'Ingin / Mau',
        fusha: 'يُرِيدُ',
        fushaTranslit: 'Yuridu',
        ammiyah: 'يِبْغَى / يَبِي',
        ammiyahTranslit: 'Yibgha / Yabi',
        regionalNote: 'Hijaz/Umum: Abgha · Riyadh/Najd: Abi',
        ruleTip: 'Saya mau = "Abgha", kamu mau = "Tibgha".',
      },
      {
        id: 'v2',
        meaning: 'Pergi',
        fusha: 'يَذْهَبُ',
        fushaTranslit: 'Yazhabu',
        ammiyah: 'يِرُوحْ',
        ammiyahTranslit: 'Yiruh',
        ruleTip: 'Saya pergi = "Aruh", ayo pergi = "Yalla niruh".',
      },
      {
        id: 'v3',
        meaning: 'Melihat',
        fusha: 'يَرَى / يَنْظُرُ',
        fushaTranslit: 'Yara / Yanzuru',
        ammiyah: 'يِشُوفْ',
        ammiyahTranslit: 'Yishuf',
        ruleTip: 'Contoh: "Shuf!" (Lihat ini!), "Ashufak bukrah" (Sampai jumpa besok).',
      },
      {
        id: 'v4',
        meaning: 'Berbicara / Mengobrol',
        fusha: 'يَتَحَدَّثُ / يَتَكَلَّمُ',
        fushaTranslit: 'Yatahaddathu / Yatakallamu',
        ammiyah: 'يِتْكَلَّمْ / يِسُولِفْ',
        ammiyahTranslit: 'Yitkallam / Yisulif',
        ruleTip: '"Yitkallam" untuk berbicara umum; "Yisulif" untuk ngobrol santai.',
      },
      {
        id: 'v5',
        meaning: 'Membuat / Melakukan',
        fusha: 'يَفْعَلُ',
        fushaTranslit: 'Yaf‘alu',
        ammiyah: 'يِسَوِّي',
        ammiyahTranslit: 'Yisawwi',
        regionalNote: 'Sangat khas Arab Saudi & Teluk!',
        ruleTip: 'Contoh: "Esh tisawwi?" = Kamu lagi ngapain / bikin apa?',
      },
    ],
  },
  {
    id: 'polite',
    title: 'Ungkapan Sopan & Respon Khas Saudi',
    description:
      'Frasa keramahan yang membuat percakapan di Makkah, Madinah, Riyadh, atau Jeddah terdengar sangat akrab dan beradab.',
    entries: [
      {
        id: 'p1',
        meaning: 'Permisi / Tolong',
        fusha: 'مِنْ فَضْلِكَ',
        fushaTranslit: 'Min fadlika',
        ammiyah: 'لَوْ سَمَحْتْ',
        ammiyahTranslit: 'Law samaht',
        ruleTip: 'Untuk perempuan: "Law samahti".',
      },
      {
        id: 'p2',
        meaning: 'Maaf (tidak apa-apa)',
        fusha: 'عَفْوًا / آسِفٌ',
        fushaTranslit: '‘Afwan / Asif',
        ammiyah: 'مَعْلِيشْ / السُّمُوحَة',
        ammiyahTranslit: 'Ma‘lesh / As-sumuhah',
        ruleTip: '"As-sumuhah" adalah cara meminta maaf yang sangat halus khas Saudi.',
      },
      {
        id: 'p3',
        meaning: 'Siap / Baik / Dengan senang hati',
        fusha: 'حَاضِرٌ / حَسَنًا',
        fushaTranslit: 'Hadirun / Hasanan',
        ammiyah: 'أَبْشِرْ / تَمَامْ / طَيِّبْ',
        ammiyahTranslit: 'Abshir / Tamam / Tayyib',
        ruleTip: '"Abshir!" sering dijawab balik dengan "Tabshir bil-khayr!".',
      },
      {
        id: 'p4',
        meaning: 'Terima kasih banyak',
        fusha: 'شُكْرًا جَزِيلًا',
        fushaTranslit: 'Shukran jazilan',
        ammiyah: 'يَعْطِيكَ الْعَافِيَة / مَشْكُورْ',
        ammiyahTranslit: 'Ya‘tikil-‘afiyah / Mashkur',
        ruleTip: '"Ya‘tikil-‘afiyah" (semoga Allah memberimu kesehatan) adalah ungkapan terima kasih utama di Saudi.',
      },
    ],
  },
  {
    id: 'time_connectors',
    title: 'Waktu, Tempat & Kata Sambung',
    description:
      'Penanda waktu harian di Arab Saudi yang wajib dikuasai untuk membuat janji dan bertanya jadwal.',
    entries: [
      {
        id: 't1',
        meaning: 'Sekarang',
        fusha: 'الْآنَ',
        fushaTranslit: 'Al-an',
        ammiyah: 'الْحِينْ',
        ammiyahTranslit: 'Al-hin',
        regionalNote: 'Di Jeddah/Hijaz kadang juga terdengar "Dahin".',
        ruleTip: 'Dari gabungan "hadha al-hin" (saat ini).',
      },
      {
        id: 't2',
        meaning: 'Besok',
        fusha: 'غَدًا',
        fushaTranslit: 'Ghadan',
        ammiyah: 'بُكْرَة',
        ammiyahTranslit: 'Bukrah',
        ruleTip: 'Lusa: "Ba‘d bukrah".',
      },
      {
        id: 't3',
        meaning: 'Kemarin',
        fusha: 'أَمْسِ',
        fushaTranslit: 'Amsi',
        ammiyah: 'أَمْسْ / الْبَارِحْ',
        ammiyahTranslit: 'Ams / Al-barih',
        ruleTip: '"Ams" untuk kemarin siang; "Al-barih" untuk tadi malam.',
      },
      {
        id: 't4',
        meaning: 'Karena / Supaya',
        fusha: 'لِأَنَّ / لِكَيْ',
        fushaTranslit: 'Li’anna / Likay',
        ammiyah: 'عَشَانْ / عَلَشَانْ',
        ammiyahTranslit: '‘Ashan / ‘Alashan',
        ruleTip: 'Dipakai untuk menyatakan tujuan maupun alasan.',
      },
    ],
  },
];

export interface MorphSlot {
  roleLabel: string;
  fushaWord: string;
  fushaTranslit: string;
  ammiyahWord: string;
  ammiyahTranslit: string;
  note: string;
}

export interface SentenceMorphExample {
  id: string;
  indonesian: string;
  context: string;
  fushaFull: string;
  fushaTranslit: string;
  ammiyahFull: string;
  ammiyahTranslit: string;
  slots: MorphSlot[];
}

export const SENTENCE_MORPHS: SentenceMorphExample[] = [
  {
    id: 'morph-1',
    indonesian: 'Saya tidak mau pergi ke pasar sekarang.',
    context: 'Menolak ajakan santai dengan kalimat lengkap',
    fushaFull: 'لَا أُرِيدُ أَنْ أَذْهَبَ إِلَى السُّوقِ الْآنَ',
    fushaTranslit: 'La uridu an azhaba ilas-suqil-an',
    ammiyahFull: 'مَا أَبْغَى أَرُوحْ السُّوقْ الْحِينْ',
    ammiyahTranslit: 'Ma abgha aruh is-suq al-hin',
    slots: [
      {
        roleLabel: 'Negasi + Ingin',
        fushaWord: 'لَا أُرِيدُ',
        fushaTranslit: 'la uridu',
        ammiyahWord: 'مَا أَبْغَى',
        ammiyahTranslit: 'ma abgha',
        note: 'Negasi cukup memakai "ma" + kata kerja "abgha".',
      },
      {
        roleLabel: 'Kata Kerja (Pergi)',
        fushaWord: 'أَنْ أَذْهَبَ',
        fushaTranslit: 'an azhaba',
        ammiyahWord: 'أَرُوحْ',
        ammiyahTranslit: 'aruh',
        note: 'Partikel penghubung "an" dihapus langsung di Ammiyah.',
      },
      {
        roleLabel: 'Tujuan',
        fushaWord: 'إِلَى السُّوقِ',
        fushaTranslit: 'ilas-suqi',
        ammiyahWord: 'السُّوقْ',
        ammiyahTranslit: 'is-suq',
        note: 'Preposisi "ila" sering dihilangkan setelah kata kerja pergi ("ruh").',
      },
      {
        roleLabel: 'Keterangan Waktu',
        fushaWord: 'الْآنَ',
        fushaTranslit: 'al-an',
        ammiyahWord: 'الْحِينْ',
        ammiyahTranslit: 'al-hin',
        note: 'Penanda waktu "sekarang" khas Arab Saudi.',
      },
    ],
  },
  {
    id: 'morph-2',
    indonesian: 'Kamu sedang belajar apa hari ini?',
    context: 'Bertanya aktivitas kepada teman di Arab Saudi',
    fushaFull: 'مَاذَا تَتَعَلَّمُ الْيَوْمَ؟',
    fushaTranslit: 'Maza tata‘allamul-yawm?',
    ammiyahFull: 'إِيشْ تِتْعَلَّمْ الْيَوْم؟',
    ammiyahTranslit: 'Esh tit‘allam al-yom?',
    slots: [
      {
        roleLabel: 'Kata Tanya',
        fushaWord: 'مَاذَا',
        fushaTranslit: 'maza',
        ammiyahWord: 'إِيشْ',
        ammiyahTranslit: 'esh',
        note: 'Kata tanya "apa" bergeser dari "Maza" menjadi "Esh" di awal kalimat.',
      },
      {
        roleLabel: 'Kata Kerja',
        fushaWord: 'تَتَعَلَّمُ',
        fushaTranslit: 'tata‘allamu',
        ammiyahWord: 'تِتْعَلَّمْ',
        ammiyahTranslit: 'tit‘allam',
        note: 'Bentuk dasarnya sangat dekat, hanya akhiran dummah disukunkan.',
      },
      {
        roleLabel: 'Waktu',
        fushaWord: 'الْيَوْمَ',
        fushaTranslit: 'al-yawm',
        ammiyahWord: 'الْيَوْم',
        ammiyahTranslit: 'al-yom',
        note: 'Diftong "aw" diucapkan lebih lembut menjadi "o".',
      },
    ],
  },
  {
    id: 'morph-3',
    indonesian: 'Besok saya akan minum kopi bersamamu.',
    context: 'Membuat janji santai',
    fushaFull: 'سَأَشْرَبُ الْقَهْوَةَ مَعَكَ غَدًا',
    fushaTranslit: 'Sa-ashrabul-qahwata ma‘aka ghadan',
    ammiyahFull: 'بَشْرَبْ قَهْوَة مَعَاكْ بُكْرَة',
    ammiyahTranslit: 'Bashrab gahwah ma‘ak bukrah',
    slots: [
      {
        roleLabel: 'Masa Depan + Kerja',
        fushaWord: 'سَأَشْرَبُ',
        fushaTranslit: 'sa-ashrabu',
        ammiyahWord: 'بَشْرَبْ',
        ammiyahTranslit: 'bashrab',
        note: 'Awalan "sa-" berubah menjadi "ba-" untuk rencana masa depan di Saudi.',
      },
      {
        roleLabel: 'Objek',
        fushaWord: 'الْقَهْوَةَ',
        fushaTranslit: 'al-qahwata',
        ammiyahWord: 'قَهْوَة',
        ammiyahTranslit: 'gahwah',
        note: 'Harakat i‘rab akhir tidak lagi dilafalkan.',
      },
      {
        roleLabel: 'Pendamping',
        fushaWord: 'مَعَكَ',
        fushaTranslit: 'ma‘aka',
        ammiyahWord: 'مَعَاكْ',
        ammiyahTranslit: 'ma‘ak',
        note: 'Vokal dipanjangkan sebelum huruf kaf sukun.',
      },
      {
        roleLabel: 'Besok',
        fushaWord: 'غَدًا',
        fushaTranslit: 'ghadan',
        ammiyahWord: 'بُكْرَة',
        ammiyahTranslit: 'bukrah',
        note: 'Kosakata harian untuk hari esok.',
      },
    ],
  },
];

export interface RoleplayOption {
  id: string;
  arabic: string;
  transliteration: string;
  indonesian: string;
  register: ArabicRegister;
  quality: 'optimal' | 'register_mismatch' | 'wrong_meaning';
  feedback: string;
}

export interface RoleplayStep {
  id: string;
  partnerName: string;
  partnerArabic: string;
  partnerTranslit: string;
  partnerIndonesian: string;
  options: RoleplayOption[];
}

export interface RoleplayMission {
  id: string;
  title: string;
  targetRegister: ArabicRegister;
  situation: string;
  steps: RoleplayStep[];
}

export const ROLEPLAY_MISSIONS: RoleplayMission[] = [
  {
    id: 'rp-cafe',
    title: 'Ngopi Santai di Riyadh',
    targetRegister: 'ammiyah',
    situation:
      'Anda duduk di sebuah kafe di Riyadh. Gunakan Ammiyah Arab Saudi yang ramah dan natural agar obrolan terasa pas.',
    steps: [
      {
        id: 'rp-c1',
        partnerName: 'Pelayan Kafe',
        partnerArabic: 'حَيَّاكْ اللَّه! إِيشْ تِبْغَى تِشْرَبْ الْيَوْم؟',
        partnerTranslit: 'Hayyak Allah! Esh tibgha tishrab al-yom?',
        partnerIndonesian: 'Selamat datang! Mau minum apa hari ini?',
        options: [
          {
            id: 'opt-1',
            arabic: 'لَوْ سَمَحْتْ، أَبْغَى شَايْ بِالنَّعْنَاعْ.',
            transliteration: 'Law samaht, abgha shay bin-na‘na‘.',
            indonesian: 'Permisi, saya mau teh mint.',
            register: 'ammiyah',
            quality: 'optimal',
            feedback:
              'Tepat sekali! "Law samaht" dan "Abgha" adalah ungkapan Ammiyah Saudi paling natural saat memesan.',
          },
          {
            id: 'opt-2',
            arabic: 'أُرِيدُ أَنْ أَشْرَبَ الشَّايَ بِالنَّعْنَاعِ مِنْ فَضْلِكَ.',
            transliteration: 'Uridu an ashrabash-shaya bin-na‘na‘i min fadlika.',
            indonesian: 'Saya ingin meminum teh mint, tolong.',
            register: 'fusha',
            quality: 'register_mismatch',
            feedback:
              'Artinya benar dan tetap dimengerti, tetapi terlalu kaku (Fushah buku teks) untuk suasana kafe santai. Coba gunakan "Law samaht, abgha...".',
          },
          {
            id: 'opt-3',
            arabic: 'بِكَمْ هَذِي الشَّنْطَة لَوْ سَمَحْتْ؟',
            transliteration: 'Bikam hazi ish-shantah law samaht?',
            indonesian: 'Berapa harga tas ini ya?',
            register: 'ammiyah',
            quality: 'wrong_meaning',
            feedback:
              'Ups, pelayan menanyakan minuman, bukan harga tas ("ish-shantah").',
          },
        ],
      },
      {
        id: 'rp-c2',
        partnerName: 'Pelayan Kafe',
        partnerArabic: 'أَبْشِرْ. كِيفْ تِبْغَى السُّكَّرْ؟ وَسَطْ وَلَّا خَفِيفْ؟',
        partnerTranslit: 'Abshir. Kef tibgha is-sukkar? Wasat walla khafif?',
        partnerIndonesian: 'Siap. Gulanya mau sedang atau sedikit?',
        options: [
          {
            id: 'opt-1',
            arabic: 'مَا أَبْغَى سُكَّرْ أَبَدًا، سَادَة لَوْ سَمَحْتْ.',
            transliteration: 'Ma abgha sukkar abadan, sada law samaht.',
            indonesian: 'Saya tidak mau gula sama sekali, tawar saja ya.',
            register: 'ammiyah',
            quality: 'optimal',
            feedback:
              'Luar biasa! Penggunaan "ma abgha" dan istilah "sada" (tanpa gula) sangat fasih di Saudi.',
          },
          {
            id: 'opt-2',
            arabic: 'بُكْرَة بِإِذْنِ اللَّه نِتْقَابَلْ.',
            transliteration: 'Bukrah bi-iznillah nitqabal.',
            indonesian: 'Besok insyaallah kita bertemu.',
            register: 'ammiyah',
            quality: 'wrong_meaning',
            feedback:
              'Kalimat ini tentang janji bertemu besok, tidak menjawab pertanyaan soal gula.',
          },
          {
            id: 'opt-3',
            arabic: 'لَا أُرِيدُ السُّكَّرَ نِهَائِيًّا.',
            transliteration: 'La uridus-sukkara niha’iyyan.',
            indonesian: 'Saya sama sekali tidak menginginkan gula.',
            register: 'fusha',
            quality: 'register_mismatch',
            feedback:
              'Ini ragam Fushah resmi yang terasa kaku untuk memesan teh. Gunakan "Ma abgha sukkar".',
          },
        ],
      },
      {
        id: 'rp-c3',
        partnerName: 'Pelayan Kafe',
        partnerArabic: 'تَفَضَّلْ الشَّايْ. تِبْغَى شَيْ ثَانِي؟',
        partnerTranslit: 'Tafaddal ish-shay. Tibgha shay thani?',
        partnerIndonesian: 'Silakan tehnya. Ada tambahan lain?',
        options: [
          {
            id: 'opt-1',
            arabic: 'يَعْطِيكَ الْعَافِيَة، مُمْكِنْ الْحِسَابْ بَسْ؟',
            transliteration: 'Ya‘tikil-‘afiyah, mumkin al-hisab bas?',
            indonesian: 'Terima kasih banyak, boleh minta tagihannya saja?',
            register: 'ammiyah',
            quality: 'optimal',
            feedback:
              'Sempurna! "Ya‘tikil-‘afiyah" terdengar sangat autentik seperti penutur asli Arab Saudi.',
          },
          {
            id: 'opt-2',
            arabic: 'رَاسِي يِعَوِّرْنِي مَرَّة.',
            transliteration: 'Rasi yi‘awwirni marrah.',
            indonesian: 'Kepala saya sakit sekali.',
            register: 'ammiyah',
            quality: 'wrong_meaning',
            feedback:
              'Kalimat ini digunakan untuk keluhan sakit di apotek/klinik.',
          },
        ],
      },
    ],
  },
  {
    id: 'rp-seminar',
    title: 'Perkenalan di Forum Akademik',
    targetRegister: 'fusha',
    situation:
      'Anda menghadiri konferensi ilmiah internasional di Madinah. Gunakan Fushah yang rapi, sopan, dan baku.',
    steps: [
      {
        id: 'rp-s1',
        partnerName: 'Dr. Hisham',
        partnerArabic: 'أَهْلًا وَسَهْلًا بِكَ فِي الْمُؤْتَمَرِ. مِنْ أَيْنَ حَضَرْتَ؟',
        partnerTranslit: 'Ahlan wa sahlan bika fil-mu’tamar. Min ayna hadarta?',
        partnerIndonesian: 'Selamat datang di konferensi ini. Dari mana Anda berasal?',
        options: [
          {
            id: 'opt-1',
            arabic: 'أَهْلًا بِكَ يَا دُكْتُور، أَنَا مِنْ إِنْدُونِيسِيَا وَأَعْمَلُ بَاحِثًا.',
            transliteration: 'Ahlan bika ya duktur, ana min Indunisiya wa a‘malu bahithan.',
            indonesian: 'Salam hangat Doktor, saya dari Indonesia dan bekerja sebagai peneliti.',
            register: 'fusha',
            quality: 'optimal',
            feedback:
              'Sangat tepat! Tata bahasa dan pilihan kosakata Fushah-nya sesuai dengan etika forum resmi.',
          },
          {
            id: 'opt-2',
            arabic: 'أَنَا مِنْ إِنْدُونِيسِيَا وَأَشْتَغِلْ هِنَاكْ يَا طَيِّبْ.',
            transliteration: 'Ana min Indunisiya wa ashtaghal hinak ya tayyib.',
            indonesian: 'Saya dari Indonesia dan kerja di sana, Mas.',
            register: 'ammiyah',
            quality: 'register_mismatch',
            feedback:
              'Sapaan "ya tayyib" dan "ashtaghal" terlalu santai untuk berbicara dengan profesor di konferensi resmi.',
          },
          {
            id: 'opt-3',
            arabic: 'عَفْوًا، أَيْنَ مَحَطَّةُ الْمِتْرُو؟',
            transliteration: '‘Afwan, ayna mahattatul-mitru?',
            indonesian: 'Permisi, di mana stasiun metro?',
            register: 'fusha',
            quality: 'wrong_meaning',
            feedback:
              'Pertanyaannya menanyakan asal negara Anda, bukan arah stasiun.',
          },
        ],
      },
      {
        id: 'rp-s2',
        partnerName: 'Dr. Hisham',
        partnerArabic: 'تَشَرَّفْنَا! هَلْ تَتَحَدَّثُ الْعَرَبِيَّةَ مُنْذُ زَمَنٍ طَوِيلٍ؟',
        partnerTranslit: 'Tasharrafna! Hal tatahad-dathul-‘arabiyyata munzu zamanin tawil?',
        partnerIndonesian: 'Senang berkenalan! Apakah Anda sudah lama berbahasa Arab?',
        options: [
          {
            id: 'opt-1',
            arabic: 'أَتَعَلَّمُهَا حَالِيًّا، وَأَطْمَحُ إِلَى إِتْقَانِ الْفُصْحَى وَالْعَامِّيَّةِ.',
            transliteration: 'Ata‘allamuha haliyyan, wa atmahu ila itqanil-fusha wal-‘ammiyyah.',
            indonesian: 'Saya sedang mempelajarinya saat ini, dan bertekad menguasai Fushah serta Ammiyah.',
            register: 'fusha',
            quality: 'optimal',
            feedback:
              'Kalimat Fushah yang elegan dan ekspresif!',
          },
          {
            id: 'opt-2',
            arabic: 'أَتَعَلَّمْ عَرَبِي الْحِينْ عَشَانْ أَسَافِرْ.',
            transliteration: 'Ata‘allam ‘arabi al-hin ‘ashan asafir.',
            indonesian: 'Saya lagi belajar Arab sekarang buat traveling.',
            register: 'ammiyah',
            quality: 'register_mismatch',
            feedback:
              'Maknanya bagus, namun gunakan bentuk Fushah ("Ata‘allamuha haliyyan") untuk menjaga keselarasan forum.',
          },
        ],
      },
    ],
  },
];

export interface SentenceBuilderItem {
  id: string;
  register: ArabicRegister;
  indonesian: string;
  hint: string;
  tokens: string[];
  transliteration: string;
}

export const SENTENCE_BUILDERS: SentenceBuilderItem[] = [
  {
    id: 'sb-1',
    register: 'fusha',
    indonesian: 'Bagaimana kabarmu hari ini?',
    hint: 'Dalam Fushah, kata tanya selalu di awal kalimat.',
    tokens: ['كَيْفَ', 'حَالُكَ', 'الْيَوْمَ؟'],
    transliteration: 'Kayfa halukal-yawm?',
  },
  {
    id: 'sb-2',
    register: 'ammiyah',
    indonesian: 'Saya mau teh mint, permisi.',
    hint: 'Mulai dengan ungkapan sopan "Law samaht" lalu "Abgha".',
    tokens: ['لَوْ', 'سَمَحْتْ،', 'أَبْغَى', 'شَايْ', 'بِالنَّعْنَاعْ.'],
    transliteration: 'Law samaht, abgha shay bin-na‘na‘.',
  },
  {
    id: 'sb-3',
    register: 'fusha',
    indonesian: 'Saya tidak mau pergi ke pasar.',
    hint: 'Negasi Fushah: La uridu + an + kata kerja.',
    tokens: ['لَا', 'أُرِيدُ', 'أَنْ', 'أَذْهَبَ', 'إِلَى', 'السُّوقِ.'],
    transliteration: 'La uridu an azhaba ilas-suq.',
  },
  {
    id: 'sb-4',
    register: 'ammiyah',
    indonesian: 'Saya tidak mau pergi sekarang.',
    hint: 'Ammiyah Saudi memakai "Ma abgha" + kata kerja + "Al-hin".',
    tokens: ['مَا', 'أَبْغَى', 'أَرُوحْ', 'الْحِينْ.'],
    transliteration: 'Ma abgha aruh al-hin.',
  },
  {
    id: 'sb-5',
    register: 'ammiyah',
    indonesian: 'Berapa harga tas ini?',
    hint: 'Mulai dengan "Bikam" lalu "hazi ish-shantah".',
    tokens: ['بِكَمْ', 'هَذِي', 'الشَّنْطَة؟'],
    transliteration: 'Bikam hazi ish-shantah?',
  },
  {
    id: 'sb-6',
    register: 'fusha',
    indonesian: 'Di mana stasiun metro?',
    hint: '"Ayna" berada di posisi pertama.',
    tokens: ['أَيْنَ', 'مَحَطَّةُ', 'الْمِتْرُو؟'],
    transliteration: 'Ayna mahattatul-mitru?',
  },
  {
    id: 'sb-7',
    register: 'ammiyah',
    indonesian: 'Jalan lurus terus, lalu belok kanan.',
    hint: 'Gunakan kata "Ruh" dan ungkapan "‘ala tul" untuk lurus terus.',
    tokens: ['رُوحْ', 'عَلَى', 'طُولْ،', 'وَبَعْدِينْ', 'لِفْ', 'يَمِينْ.'],
    transliteration: 'Ruh ‘ala tul, wa ba‘den liff yamin.',
  },
  {
    id: 'sb-8',
    register: 'fusha',
    indonesian: 'Saya bekerja sebagai insinyur di Indonesia.',
    hint: 'Mulai dengan kata kerja "A‘malu".',
    tokens: ['أَعْمَلُ', 'مُهَنْدِسًا', 'فِي', 'إِنْدُونِيسِيَا.'],
    transliteration: 'A‘malu muhandisan fi Indunisiya.',
  },
];

export interface QuizQuestion {
  id: string;
  mode: 'fusha_to_ammiyah' | 'ammiyah_to_fusha' | 'audio_meaning';
  promptRegister: ArabicRegister;
  promptArabic: string;
  promptTranslit: string;
  questionText: string;
  options: {
    id: string;
    labelArabic?: string;
    labelText: string;
    isCorrect: boolean;
  }[];
  explanation: string;
}

export const REGISTER_QUIZZES: QuizQuestion[] = [
  {
    id: 'qz-1',
    mode: 'fusha_to_ammiyah',
    promptRegister: 'fusha',
    promptArabic: 'مَاذَا تُرِيدُ؟',
    promptTranslit: 'Maza turid?',
    questionText: 'Padanan Ammiyah Arab Saudi yang paling alami untuk ungkapan Fushah di atas adalah:',
    options: [
      { id: 'a', labelArabic: 'إِيشْ تِبْغَى؟', labelText: 'Esh tibgha?', isCorrect: true },
      { id: 'b', labelArabic: 'مِنْ وِينْ أَنْتَ؟', labelText: 'Min wen anta?', isCorrect: false },
      { id: 'c', labelArabic: 'مَا فِي شَيْ', labelText: 'Ma fi shay', isCorrect: false },
    ],
    explanation: '"Maza" -> "Esh", dan "turidu" -> "tibgha" dalam percakapan sehari-hari Saudi.',
  },
  {
    id: 'qz-2',
    mode: 'ammiyah_to_fusha',
    promptRegister: 'ammiyah',
    promptArabic: 'كِيفْ حَالَكْ وَشَخْبَارَكْ؟',
    promptTranslit: 'Kef halak wa shakhbarak?',
    questionText: 'Jika diubah ke bahasa Arab Fushah resmi, kalimat ini menjadi:',
    options: [
      { id: 'a', labelArabic: 'أَيْنَ تَذْهَبُ؟', labelText: 'Ayna tazhab?', isCorrect: false },
      { id: 'b', labelArabic: 'كَيْفَ حَالُكَ وَمَا أَخْبَارُكَ؟', labelText: 'Kayfa haluka wa ma akhbaruk?', isCorrect: true },
      { id: 'c', labelArabic: 'بِكَمْ هَذَا؟', labelText: 'Bikam haza?', isCorrect: false },
    ],
    explanation: '"Kef halak wa shakhbarak" adalah sapaan menanyakan kabar, sejajar dengan "Kayfa haluka wa ma akhbaruk".',
  },
  {
    id: 'qz-3',
    mode: 'fusha_to_ammiyah',
    promptRegister: 'fusha',
    promptArabic: 'لَا أَعْرِفُ',
    promptTranslit: 'La a‘rifu',
    questionText: 'Bagaimana orang Arab Saudi mengucapkan kalimat ini dalam percakapan sehari-hari?',
    options: [
      { id: 'a', labelArabic: 'مَا أَعْرِفْ / مَا أَدْرِي', labelText: 'Ma a‘rif / Ma adri', isCorrect: true },
      { id: 'b', labelArabic: 'أَبْشِرْ', labelText: 'Abshir', isCorrect: false },
      { id: 'c', labelArabic: 'حَيَّاكْ اللَّه', labelText: 'Hayyak Allah', isCorrect: false },
    ],
    explanation: 'Ammiyah Saudi menegasikan kata kerja dengan "ma" di depan tanpa akhiran -sh: "Ma a‘rif" atau "Ma adri".',
  },
  {
    id: 'qz-4',
    mode: 'audio_meaning',
    promptRegister: 'ammiyah',
    promptArabic: 'لَوْ سَمَحْتْ، مُمْكِنْ الْحِسَابْ؟',
    promptTranslit: 'Law samaht, mumkin al-hisab?',
    questionText: 'Dengarkan audio atau baca kalimatnya. Apa maksud dari ungkapan Ammiyah Saudi ini?',
    options: [
      { id: 'a', labelText: 'Permisi, di mana pintu keluar?', isCorrect: false },
      { id: 'b', labelText: 'Permisi, boleh saya minta tagihannya (bon)?', isCorrect: true },
      { id: 'c', labelText: 'Maaf, harga ini terlalu mahal.', isCorrect: false },
    ],
    explanation: '"Al-hisab" dalam konteks restoran/kafe berarti tagihan atau bon pembayaran.',
  },
  {
    id: 'qz-5',
    mode: 'ammiyah_to_fusha',
    promptRegister: 'ammiyah',
    promptArabic: 'بَشْرَبْ مَوْيَة بُكْرَة',
    promptTranslit: 'Bashrab moyah bukrah',
    questionText: 'Pilih bentuk Fushah yang tepat untuk kalimat Ammiyah Saudi di atas:',
    options: [
      { id: 'a', labelArabic: 'سَأَشْرَبُ الْمَاءَ غَدًا', labelText: 'Sa-ashrabul-ma’a ghadan', isCorrect: true },
      { id: 'b', labelArabic: 'شَرِبْتُ الْمَاءَ أَمْسِ', labelText: 'Sharibtul-ma’a amsi', isCorrect: false },
      { id: 'c', labelArabic: 'لَا أَشْرَبُ الْقَهْوَةَ', labelText: 'La ashrabul-qahwah', isCorrect: false },
    ],
    explanation: 'Awalan "ba-" (akan) sejajar dengan "sa-", "moyah" = "al-ma’", dan "bukrah" = "ghadan" (besok).',
  },
  {
    id: 'qz-6',
    mode: 'audio_meaning',
    promptRegister: 'fusha',
    promptArabic: 'اِنْعَطِفْ يَمِينًا عِنْدَ الدَّوَّارِ',
    promptTranslit: 'In‘atif yaminan ‘indad-dawwar',
    questionText: 'Apa arti dari instruksi arah dalam ragam Fushah ini?',
    options: [
      { id: 'a', labelText: 'Jalan lurus sampai akhir jalan.', isCorrect: false },
      { id: 'b', labelText: 'Berhenti di depan stasiun.', isCorrect: false },
      { id: 'c', labelText: 'Belok kanan di bundaran.', isCorrect: true },
    ],
    explanation: '"In‘atif" = beloklah, "yaminan" = ke kanan, "ad-dawwar" = bundaran jalan.',
  },
];

export interface VocabItem {
  id: string;
  category: 'Sapaan' | 'Kata Kerja' | 'Tanya & Sambung' | 'Belanja & Makan' | 'Arah & Waktu';
  indonesian: string;
  fusha: string;
  fushaTranslit: string;
  ammiyah: string;
  ammiyahTranslit: string;
  exampleNote: string;
}

export const VOCABULARY_DECK: VocabItem[] = [
  {
    id: 'vc-1',
    category: 'Sapaan',
    indonesian: 'Apa kabar?',
    fusha: 'كَيْفَ حَالُكَ؟',
    fushaTranslit: 'Kayfa haluka?',
    ammiyah: 'كِيفْ حَالَكْ / شَخْبَارَكْ؟',
    ammiyahTranslit: 'Kef halak / Shakhbarak?',
    exampleNote: 'Untuk perempuan: Kef halik / Shakhbarik.',
  },
  {
    id: 'vc-2',
    category: 'Sapaan',
    indonesian: 'Baik / Sehat',
    fusha: 'بِخَيْرٍ',
    fushaTranslit: 'Bikhayrin',
    ammiyah: 'طَيِّبْ / زِينْ',
    ammiyahTranslit: 'Tayyib / Zen',
    exampleNote: 'Untuk perempuan: Tayyibah / Zenah.',
  },
  {
    id: 'vc-3',
    category: 'Sapaan',
    indonesian: 'Permisi / Tolong',
    fusha: 'مِنْ فَضْلِكَ',
    fushaTranslit: 'Min fadlika',
    ammiyah: 'لَوْ سَمَحْتْ',
    ammiyahTranslit: 'Law samaht',
    exampleNote: 'Selalu dipakai untuk membuka permintaan dengan sopan.',
  },
  {
    id: 'vc-4',
    category: 'Sapaan',
    indonesian: 'Siap / Dengan senang hati',
    fusha: 'حَاضِرٌ',
    fushaTranslit: 'Hadirun',
    ammiyah: 'أَبْشِرْ',
    ammiyahTranslit: 'Abshir',
    exampleNote: 'Ungkapan keramahan paling khas di Arab Saudi saat menyanggupi bantuan.',
  },
  {
    id: 'vc-5',
    category: 'Kata Kerja',
    indonesian: 'Saya mau / ingin',
    fusha: 'أُرِيدُ',
    fushaTranslit: 'Uridu',
    ammiyah: 'أَبْغَى / أَبِي',
    ammiyahTranslit: 'Abgha / Abi',
    exampleNote: '"Abgha" umum di Makkah/Madinah/Jeddah; "Abi" populer di Riyadh.',
  },
  {
    id: 'vc-6',
    category: 'Kata Kerja',
    indonesian: 'Saya pergi',
    fusha: 'أَذْهَبُ',
    fushaTranslit: 'Azhabu',
    ammiyah: 'أَرُوحْ',
    ammiyahTranslit: 'Aruh',
    exampleNote: 'Kalimat ajakan: "Yalla niruh" (Ayo kita pergi).',
  },
  {
    id: 'vc-7',
    category: 'Kata Kerja',
    indonesian: 'Saya melihat',
    fusha: 'أَرَى',
    fushaTranslit: 'Ara',
    ammiyah: 'أَشُوفْ',
    ammiyahTranslit: 'Ashuf',
    exampleNote: 'Bentuk lampau: "Shuft" (saya sudah lihat).',
  },
  {
    id: 'vc-8',
    category: 'Kata Kerja',
    indonesian: 'Saya berbicara / ngobrol',
    fusha: 'أَتَحَدَّثُ',
    fushaTranslit: 'Atahaddathu',
    ammiyah: 'أَتْكَلَّمْ / أَسُولِفْ',
    ammiyahTranslit: 'Atkallam / Asulif',
    exampleNote: '"Asulif" khusus untuk mengobrol santai bersama teman.',
  },
  {
    id: 'vc-9',
    category: 'Kata Kerja',
    indonesian: 'Saya bekerja',
    fusha: 'أَعْمَلُ',
    fushaTranslit: 'A‘malu',
    ammiyah: 'أَشْتَغِلْ',
    ammiyahTranslit: 'Ashtaghal',
    exampleNote: 'Kata benda pekerjaan: "‘Amal" (Fushah) / "Shughl" (Ammiyah).',
  },
  {
    id: 'vc-10',
    category: 'Kata Kerja',
    indonesian: 'Saya membuat / melakukan',
    fusha: 'أَفْعَلُ',
    fushaTranslit: 'Af‘alu',
    ammiyah: 'أَسَوِّي',
    ammiyahTranslit: 'Asawwi',
    exampleNote: '"Esh tisawwi?" = Apa yang sedang kamu kerjakan?',
  },
  {
    id: 'vc-11',
    category: 'Tanya & Sambung',
    indonesian: 'Apa?',
    fusha: 'مَاذَا؟',
    fushaTranslit: 'Maza?',
    ammiyah: 'إِيشْ؟',
    ammiyahTranslit: 'Esh?',
    exampleNote: 'Di sebagian wilayah Timur Saudi juga dipakai "Shinu?".',
  },
  {
    id: 'vc-12',
    category: 'Tanya & Sambung',
    indonesian: 'Di mana?',
    fusha: 'أَيْنَ؟',
    fushaTranslit: 'Ayna?',
    ammiyah: 'وِينْ؟',
    ammiyahTranslit: 'Wen?',
    exampleNote: 'Untuk bertanya asal: "Min ayna" -> "Min wen".',
  },
  {
    id: 'vc-13',
    category: 'Tanya & Sambung',
    indonesian: 'Kenapa?',
    fusha: 'لِمَاذَا؟',
    fushaTranslit: 'Limaza?',
    ammiyah: 'لِيشْ؟',
    ammiyahTranslit: 'Lesh?',
    exampleNote: 'Jawabannya memakai "Li’anna" (Fushah) / "‘Ashan" (Ammiyah).',
  },
  {
    id: 'vc-14',
    category: 'Tanya & Sambung',
    indonesian: 'Tidak ada',
    fusha: 'لَا يُوجَدُ',
    fushaTranslit: 'La yujadu',
    ammiyah: 'مَا فِي',
    ammiyahTranslit: 'Ma fi',
    exampleNote: 'Lawan katanya: "Yujad" (Fushah) / "Fi" (Ammiyah).',
  },
  {
    id: 'vc-15',
    category: 'Tanya & Sambung',
    indonesian: 'Sangat / Sekali',
    fusha: 'جِدًّا',
    fushaTranslit: 'Jiddan',
    ammiyah: 'مَرَّة',
    ammiyahTranslit: 'Marrah',
    exampleNote: 'Contoh: "Kwayyis marrah" (Bagus sekali).',
  },
  {
    id: 'vc-16',
    category: 'Belanja & Makan',
    indonesian: 'Berapa harganya?',
    fusha: 'بِكَمْ هَذَا؟',
    fushaTranslit: 'Bikam haza?',
    ammiyah: 'بِكَمْ هَذَا؟',
    ammiyahTranslit: 'Bikam haza?',
    exampleNote: 'Untuk benda muannats pakai "Bikam hazi?".',
  },
  {
    id: 'vc-17',
    category: 'Belanja & Makan',
    indonesian: 'Tagihan / Bon',
    fusha: 'الْفَاتُورَةُ',
    fushaTranslit: 'Al-faturah',
    ammiyah: 'الْحِسَابْ / الْفَاتُورَة',
    ammiyahTranslit: 'Al-hisab / Al-faturah',
    exampleNote: '"Mumkin al-hisab?" adalah kalimat wajib di restoran.',
  },
  {
    id: 'vc-18',
    category: 'Belanja & Makan',
    indonesian: 'Air minum',
    fusha: 'الْمَاءُ',
    fushaTranslit: 'Al-ma’u',
    ammiyah: 'مَوْيَة',
    ammiyahTranslit: 'Moyah',
    exampleNote: 'Air dingin: "Moyah baridah" (Ammiyah) / "Ma’ barid" (Fushah).',
  },
  {
    id: 'vc-19',
    category: 'Belanja & Makan',
    indonesian: 'Terima kasih (semoga sehat)',
    fusha: 'شُكْرًا جَزِيلًا',
    fushaTranslit: 'Shukran jazilan',
    ammiyah: 'يَعْطِيكَ الْعَافِيَة',
    ammiyahTranslit: 'Ya‘tikil-‘afiyah',
    exampleNote: 'Jawaban umumnya: "Allah yi‘afik" (Semoga Allah menyehatkanmu juga).',
  },
  {
    id: 'vc-20',
    category: 'Arah & Waktu',
    indonesian: 'Sekarang',
    fusha: 'الْآنَ',
    fushaTranslit: 'Al-an',
    ammiyah: 'الْحِينْ',
    ammiyahTranslit: 'Al-hin',
    exampleNote: 'Di Makkah/Jeddah kadang juga diucapkan "Dahin".',
  },
  {
    id: 'vc-21',
    category: 'Arah & Waktu',
    indonesian: 'Besok',
    fusha: 'غَدًا',
    fushaTranslit: 'Ghadan',
    ammiyah: 'بُكْرَة',
    ammiyahTranslit: 'Bukrah',
    exampleNote: 'Lusa: "Ba‘d bukrah".',
  },
  {
    id: 'vc-22',
    category: 'Arah & Waktu',
    indonesian: 'Lurus terus',
    fusha: 'مُبَاشَرَةً',
    fushaTranslit: 'Mubasharatan',
    ammiyah: 'عَلَى طُولْ / سِيدَة',
    ammiyahTranslit: '‘Ala tul / Sidah',
    exampleNote: 'Dua kata yang paling sering terdengar saat bertanya arah di Saudi.',
  },
  {
    id: 'vc-23',
    category: 'Arah & Waktu',
    indonesian: 'Sedikit / Sebentar',
    fusha: 'قَلِيلًا',
    fushaTranslit: 'Qalilan',
    ammiyah: 'شْوَيّ',
    ammiyahTranslit: 'Shwayy',
    exampleNote: 'Contoh: "Intazir shwayy" (tunggu sebentar).',
  },
  {
    id: 'vc-24',
    category: 'Arah & Waktu',
    indonesian: 'Kemarin',
    fusha: 'أَمْسِ',
    fushaTranslit: 'Amsi',
    ammiyah: 'أَمْسْ',
    ammiyahTranslit: 'Ams',
    exampleNote: 'Untuk tadi malam: "Al-barih".',
  },
];
