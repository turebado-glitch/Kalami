import { useEffect, useState } from 'react';
import { TopNav, type AppSection } from './components/TopNav';
import { GuidedLiveStudio } from './components/GuidedLiveStudio';
import { DialogueStudio } from './components/DialogueStudio';
import { ComparisonLab } from './components/ComparisonLab';
import { PracticeArena } from './components/PracticeArena';
import { VocabularyStudio } from './components/VocabularyStudio';
import { PWAInstallButton } from './components/PWAInstallButton';
import { VOCABULARY_DECK } from './data/arabicCurriculum';
import { stopArabicSpeech } from './utils/arabicSpeech';
import { stopWavPlayback } from './utils/wavPlayer';

interface LearningProgress {
  completedScenarios: string[];
  masteredVocabIds: string[];
  completedExercises: number;
  showHarakat: boolean;
  showTranslit: boolean;
  speechRate: number;
}

const STORAGE_KEY = 'qalam_kalam_progress_v1';

const DEFAULT_PROGRESS: LearningProgress = {
  completedScenarios: [],
  masteredVocabIds: [],
  completedExercises: 0,
  showHarakat: true,
  showTranslit: true,
  speechRate: 0.95,
};

function loadProgress(): LearningProgress {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PROGRESS;
    const parsed = JSON.parse(raw) as Partial<LearningProgress>;
    return {
      completedScenarios: Array.isArray(parsed.completedScenarios)
        ? parsed.completedScenarios
        : [],
      masteredVocabIds: Array.isArray(parsed.masteredVocabIds)
        ? parsed.masteredVocabIds
        : [],
      completedExercises:
        typeof parsed.completedExercises === 'number' ? parsed.completedExercises : 0,
      showHarakat: typeof parsed.showHarakat === 'boolean' ? parsed.showHarakat : true,
      showTranslit: typeof parsed.showTranslit === 'boolean' ? parsed.showTranslit : true,
      speechRate: typeof parsed.speechRate === 'number' ? parsed.speechRate : 0.95,
    };
  } catch {
    return DEFAULT_PROGRESS;
  }
}

export default function App() {
  const [activeSection, setActiveSection] = useState<AppSection>('live');
  const [progress, setProgress] = useState<LearningProgress>(loadProgress);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch {
      // Ignore storage quota errors gracefully
    }
  }, [progress]);

  const handleSelectSection = (section: AppSection) => {
    stopWavPlayback();
    stopArabicSpeech();
    setActiveSection(section);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleCompleteScenario = (id: string) => {
    setProgress((prev) => {
      const exists = prev.completedScenarios.includes(id);
      return {
        ...prev,
        completedScenarios: exists
          ? prev.completedScenarios.filter((item) => item !== id)
          : [...prev.completedScenarios, id],
      };
    });
  };

  const toggleMasteredVocab = (id: string) => {
    setProgress((prev) => {
      const exists = prev.masteredVocabIds.includes(id);
      return {
        ...prev,
        masteredVocabIds: exists
          ? prev.masteredVocabIds.filter((item) => item !== id)
          : [...prev.masteredVocabIds, id],
      };
    });
  };

  const incrementExerciseScore = () => {
    setProgress((prev) => ({
      ...prev,
      completedExercises: prev.completedExercises + 1,
    }));
  };

  const toggleHarakat = () => {
    setProgress((prev) => ({ ...prev, showHarakat: !prev.showHarakat }));
  };

  const toggleTranslit = () => {
    setProgress((prev) => ({ ...prev, showTranslit: !prev.showTranslit }));
  };

  const changeSpeechRate = (rate: number) => {
    setProgress((prev) => ({ ...prev, speechRate: rate }));
  };

  const resetProgress = () => {
    setProgress(DEFAULT_PROGRESS);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-900">
      <TopNav
        activeSection={activeSection}
        onSelectSection={handleSelectSection}
        onPrimaryAction={() => handleSelectSection('live')}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-6 lg:px-10 py-8 lg:py-10">
        {activeSection === 'live' && (
          <GuidedLiveStudio
            showHarakat={progress.showHarakat}
            onToggleHarakat={toggleHarakat}
            showTranslit={progress.showTranslit}
            onToggleTranslit={toggleTranslit}
            speechRate={progress.speechRate}
            onChangeSpeechRate={changeSpeechRate}
            onNavigateOffline={() => handleSelectSection('dialog')}
          />
        )}

        {activeSection === 'dialog' && (
          <DialogueStudio
            completedScenarios={progress.completedScenarios}
            onToggleCompleteScenario={toggleCompleteScenario}
            masteredVocabCount={progress.masteredVocabIds.length}
            totalVocabCount={VOCABULARY_DECK.length}
            showHarakat={progress.showHarakat}
            onToggleHarakat={toggleHarakat}
            showTranslit={progress.showTranslit}
            onToggleTranslit={toggleTranslit}
            speechRate={progress.speechRate}
            onChangeSpeechRate={changeSpeechRate}
            onNavigatePractice={() => handleSelectSection('practice')}
            onNavigateCompare={() => handleSelectSection('compare')}
          />
        )}

        {activeSection === 'compare' && (
          <ComparisonLab
            showHarakat={progress.showHarakat}
            onToggleHarakat={toggleHarakat}
            showTranslit={progress.showTranslit}
            onToggleTranslit={toggleTranslit}
            speechRate={progress.speechRate}
          />
        )}

        {activeSection === 'practice' && (
          <PracticeArena
            showHarakat={progress.showHarakat}
            onToggleHarakat={toggleHarakat}
            showTranslit={progress.showTranslit}
            onToggleTranslit={toggleTranslit}
            speechRate={progress.speechRate}
            completedExercises={progress.completedExercises}
            onIncrementExerciseScore={incrementExerciseScore}
          />
        )}

        {activeSection === 'vocabulary' && (
          <VocabularyStudio
            showHarakat={progress.showHarakat}
            onToggleHarakat={toggleHarakat}
            showTranslit={progress.showTranslit}
            onToggleTranslit={toggleTranslit}
            speechRate={progress.speechRate}
            masteredVocabIds={progress.masteredVocabIds}
            onToggleMasteredVocab={toggleMasteredVocab}
          />
        )}
      </main>

      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="max-w-7xl mx-auto px-6 lg:px-10 py-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            Kalami · Studio Belajar Percakapan Bahasa Arab Fushah &amp; Ammiyah Arab Saudi
          </p>
          <div className="flex flex-wrap items-center gap-4">
            <PWAInstallButton />
            <button
              type="button"
              onClick={resetProgress}
              className="text-slate-600 hover:text-slate-900 underline underline-offset-4 cursor-pointer"
            >
              Atur Ulang Progres Belajar
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
