import 'dotenv/config';
import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

type ArabicRegister = 'fusha' | 'ammiyah';

interface HistoryItem {
  role: 'user' | 'partner';
  arabicWithHarakat: string;
  transliteration: string;
  indonesian: string;
}

interface ChoiceInput {
  arabicWithHarakat: string;
  transliteration?: string;
  indonesian: string;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT) || 3000;

const ttsCache = new Map<string, string>();
const MAX_TTS_CACHE = 120;

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    const error = new Error(
      'GEMINI_API_KEY belum tersedia di server. Periksa panel Settings > Secrets.'
    ) as Error & { statusCode?: number };
    error.statusCode = 500;
    throw error;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function extractApiError(err: unknown): { status: number; message: string } {
  const rawMessage =
    err instanceof Error
      ? err.message
      : typeof err === 'string'
        ? err
        : 'Terjadi kesalahan pada layanan AI.';

  const statusFromObj =
    typeof err === 'object' && err !== null
      ? ((err as { statusCode?: number; status?: number }).statusCode ??
        (err as { statusCode?: number; status?: number }).status)
      : undefined;

  let status = typeof statusFromObj === 'number' && statusFromObj >= 400 ? statusFromObj : 500;
  if (rawMessage.includes('PERMISSION_DENIED') || rawMessage.includes('403')) {
    status = 403;
  } else if (rawMessage.includes('API_KEY_INVALID') || rawMessage.includes('400')) {
    status = 400;
  } else if (rawMessage.includes('RESOURCE_EXHAUSTED') || rawMessage.includes('429')) {
    status = 429;
  } else if (rawMessage.includes('NOT_FOUND') || rawMessage.includes('404')) {
    status = 404;
  }

  let message = rawMessage;
  if (status === 403 || rawMessage.includes('API_KEY_INVALID')) {
    message =
      'Kunci API Gemini belum aktif atau tidak valid. Silakan periksa pengaturan GEMINI_API_KEY di panel Settings > Secrets.';
  } else if (status === 429) {
    message = 'Batas permintaan sementara tercapai (429). Tunggu beberapa detik lalu coba lagi.';
  }

  return { status, message };
}

async function withRetry<T>(fn: () => Promise<T>, maxRetries = 1): Promise<T> {
  let lastErr: unknown;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      const msg = err instanceof Error ? err.message : '';
      const isTransient =
        msg.includes('503') ||
        msg.includes('UNAVAILABLE') ||
        msg.includes('fetch failed') ||
        msg.includes('ECONNRESET');
      if (!isTransient || attempt === maxRetries) {
        throw err;
      }
      await new Promise((resolve) => setTimeout(resolve, 400 * (attempt + 1)));
    }
  }
  throw lastErr;
}

function registerRules(register: ArabicRegister): string {
  if (register === 'fusha') {
    return [
      'Ragam bahasa WAJIB: Bahasa Arab Fushah (Al-Arabiyyah Al-Fusha / Modern Standard Arabic) yang alami dan sopan untuk percakapan nyata.',
      'Gunakan kosakata baku seperti: أُرِيدُ، بِكَمْ، مِنْ فَضْلِكَ، هَلْ يُوجَدُ، كَيْفَ حَالُكَ، مَاذَا تَنْصَحُنِي، شُكْرًا جَزِيلًا.',
      'JANGAN mencampur kosakata dialek Ammiyah.',
    ].join(' ');
  }
  return [
    'Ragam bahasa WAJIB: Bahasa Arab Ammiyah Arab Saudi (Ammiyah Saudiyah / Najdi-Hijazi sehari-hari yang umum dipakai orang Saudi di pasar, kafe, hotel, dan jalan).',
    'Gunakan ungkapan Saudi yang lumrah seperti: السَّلَامُ عَلَيْكُمْ، كِيفْ حَالَكْ، إِيشْ، وِينْ، أَبْغَى / أَبِي، بِكَمْ، لَوْ سَمَحْت، عِنْدَكُمْ، مَرَّة زَيْن، طَيِّبْ، أَبْشِرْ، يَعْطِيكَ الْعَافِيَة، الْحِينْ، كَمْ حِسَابِي.',
    'JANGAN gunakan dialek Mesir seperti إزيك، عايز، فين، كده، بكام ده.',
  ].join(' ');
}

function formatHistoryText(history: HistoryItem[]): string {
  if (!Array.isArray(history) || history.length === 0) {
    return '(Percakapan baru dimulai)';
  }
  return history
    .slice(-8)
    .map((item, idx) => {
      const speaker = item.role === 'user' ? 'Pengguna' : 'Lawan Bicara';
      return `${idx + 1}. ${speaker}: ${item.arabicWithHarakat} | "${item.indonesian}"`;
    })
    .join('\n');
}

async function generateArabicSpeechWav(
  text: string,
  register: ArabicRegister,
  voiceName = 'Kore'
): Promise<string> {
  const cacheKey = `${register}:${voiceName}:${text.trim()}`;
  const cached = ttsCache.get(cacheKey);
  if (cached) {
    return cached;
  }

  const ai = getGeminiClient();
  const styleDesc =
    register === 'fusha'
      ? 'Warm, clear, articulate native Arabic speaker using natural Modern Standard Arabic (Fushah) pacing suitable for learners.'
      : 'Friendly, natural, everyday Saudi Arabian native speaker speaking warm conversational Saudi Ammiyah at a clear learning pace.';

  const response = await withRetry(() =>
    ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text,
              speechMetadata: {
                style: styleDesc,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName,
            },
          },
        },
      },
    })
  );

  const parts = response.candidates?.[0]?.content?.parts ?? [];
  const audioPart = parts.find((part) => part.inlineData?.data);
  const base64Audio = audioPart?.inlineData?.data;

  if (!base64Audio) {
    throw new Error('Model suara tidak mengembalikan data audio.');
  }

  if (ttsCache.size >= MAX_TTS_CACHE) {
    const firstKey = ttsCache.keys().next().value;
    if (firstKey) ttsCache.delete(firstKey);
  }
  ttsCache.set(cacheKey, base64Audio);

  return base64Audio;
}

async function transcribeUserArabicSpeech(
  audioBase64: string,
  mimeType: string
): Promise<string | null> {
  const ai = getGeminiClient();
  const cleanMime = mimeType.split(';')[0].trim() || 'audio/webm';
  const response = await ai.models.generateContent({
    model: 'gemini-3.5-transcribe',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: cleanMime,
            data: audioBase64,
          },
        },
        {
          text: 'Transkripsikan ucapan bahasa Arab pada audio ini persis seperti yang terdengar dalam huruf Arab. Jika hening atau tidak terdengar suara ucapan, jawab PERSIS: [HENNING]',
        },
      ],
    },
  });

  const text = (response.text ?? '').trim();
  if (!text || text === '[HENNING]') {
    return null;
  }
  return text;
}

function stripHarakatServer(text: string): string {
  return text.replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, '');
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '8mb' }));

  app.use((req: Request, res: Response, next: NextFunction) => {
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
    } else {
      res.setHeader('Access-Control-Allow-Origin', '*');
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      ok: true,
      hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    });
  });

  app.post('/api/dialogue/turn', async (req: Request, res: Response) => {
    const tStart = Date.now();
    try {
      const body = req.body as {
        theme?: string;
        register?: ArabicRegister;
        stepIndex?: number;
        history?: HistoryItem[];
      };

      const theme = typeof body.theme === 'string' ? body.theme.trim().slice(0, 200) : '';
      const register: ArabicRegister = body.register === 'ammiyah' ? 'ammiyah' : 'fusha';
      const stepIndex =
        typeof body.stepIndex === 'number' && body.stepIndex >= 0 ? body.stepIndex : 0;
      const history = Array.isArray(body.history) ? body.history : [];

      if (!theme) {
        res.status(400).json({ error: 'Tema percakapan wajib diisi terlebih dahulu.' });
        return;
      }

      const ai = getGeminiClient();

      const prompt = [
        `Pengajar bahasa Arab untuk penutur Indonesia. Tema: "${theme}".`,
        registerRules(register),
        `Langkah ke-${stepIndex + 1}. Riwayat:\n${formatHistoryText(history)}`,
        stepIndex === 0
          ? `Buat 3 pilihan kalimat pembuka bahasa Arab yang paling lumrah diucapkan orang Arab untuk situasi "${theme}".`
          : `Buat 3 pilihan kalimat lanjutan bahasa Arab yang alami dan bervariasi setelah balasan lawan bicara terakhir.`,
        `Setiap pilihan ringkas (1 kalimat pendek): arabicWithHarakat (berharakat lengkap), transliteration (Latin Indonesia), indonesian (arti singkat), nuance (2-3 kata).`,
      ].join('\n\n');

      const response = await withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: prompt,
          config: {
            systemInstruction:
              'Hasilkan JSON valid sesuai skema. Ringkas, cepat, alami, teks Arab berharakat lengkap, arti dalam bahasa Indonesia.',
            thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                sceneTitle: { type: Type.STRING },
                partnerRole: { type: Type.STRING },
                stagePrompt: { type: Type.STRING },
                choices: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      arabicWithHarakat: { type: Type.STRING },
                      transliteration: { type: Type.STRING },
                      indonesian: { type: Type.STRING },
                      nuance: { type: Type.STRING },
                    },
                    required: [
                      'id',
                      'arabicWithHarakat',
                      'transliteration',
                      'indonesian',
                      'nuance',
                    ],
                  },
                },
              },
              required: ['sceneTitle', 'partnerRole', 'stagePrompt', 'choices'],
            },
          },
        })
      );

      const jsonText = (response.text ?? '').trim();
      if (!jsonText) {
        throw new Error('Model tidak mengembalikan daftar pilihan kalimat.');
      }

      const parsed = JSON.parse(jsonText) as {
        sceneTitle: string;
        partnerRole: string;
        stagePrompt: string;
        choices: Array<{
          id: string;
          arabicWithHarakat: string;
          transliteration: string;
          indonesian: string;
          nuance: string;
        }>;
      };

      const enriched = {
        ...parsed,
        choices: (parsed.choices || []).map((c, idx) => ({
          ...c,
          id: c.id || `c${idx + 1}`,
          arabicPlain: stripHarakatServer(c.arabicWithHarakat || ''),
        })),
      };

      console.log(`[API] /api/dialogue/turn (${register}) completed in ${Date.now() - tStart}ms`);
      res.json(enriched);
    } catch (err) {
      console.error(`[API] /api/dialogue/turn error (${Date.now() - tStart}ms):`, err);
      const { status, message } = extractApiError(err);
      res.status(status).json({ error: message });
    }
  });

  app.post('/api/dialogue/respond', async (req: Request, res: Response) => {
    const tStart = Date.now();
    try {
      const body = req.body as {
        theme?: string;
        register?: ArabicRegister;
        selectedChoice?: ChoiceInput;
        history?: HistoryItem[];
        voiceName?: string;
        userAudioBase64?: string;
        userAudioMimeType?: string;
      };

      const theme = typeof body.theme === 'string' ? body.theme.trim().slice(0, 200) : '';
      const register: ArabicRegister = body.register === 'ammiyah' ? 'ammiyah' : 'fusha';
      const selectedChoice = body.selectedChoice;
      const history = Array.isArray(body.history) ? body.history : [];
      const voiceName =
        typeof body.voiceName === 'string' && body.voiceName ? body.voiceName : 'Kore';

      if (!theme || !selectedChoice?.arabicWithHarakat) {
        res.status(400).json({ error: 'Pilihan kalimat atau tema percakapan tidak lengkap.' });
        return;
      }

      const ai = getGeminiClient();

      const prompt = [
        `Perankan lawan bicara dalam latihan percakapan bahasa Arab. Tema: "${theme}".`,
        registerRules(register),
        `Riwayat:\n${formatHistoryText(history)}`,
        `Pengguna mengucapkan: ${selectedChoice.arabicWithHarakat} ("${selectedChoice.indonesian}")`,
        `Berikan 1 balasan ringkas (1-2 kalimat singkat) dengan harakat lengkap, transliterasi, arti Indonesia, peran lawan bicara, dan 1 kalimat catatan budaya singkat.`,
      ].join('\n\n');

      const replyPromise = withRetry(() =>
        ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: prompt,
          config: {
            systemInstruction:
              'Hasilkan JSON valid sesuai skema. Balasan Arab alami, ringkas (1-2 kalimat), berharakat lengkap.',
            thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                partnerRole: { type: Type.STRING },
                arabicWithHarakat: { type: Type.STRING },
                transliteration: { type: Type.STRING },
                indonesian: { type: Type.STRING },
                culturalNote: { type: Type.STRING },
              },
              required: [
                'partnerRole',
                'arabicWithHarakat',
                'transliteration',
                'indonesian',
                'culturalNote',
              ],
            },
          },
        })
      );

      const transcribePromise =
        typeof body.userAudioBase64 === 'string' && body.userAudioBase64.length > 0
          ? transcribeUserArabicSpeech(
              body.userAudioBase64,
              body.userAudioMimeType || 'audio/webm'
            ).catch(() => null)
          : Promise.resolve(null);

      const [replyResponse, spokenTranscript] = await Promise.all([
        replyPromise,
        transcribePromise,
      ]);

      const jsonText = (replyResponse.text ?? '').trim();
      if (!jsonText) {
        throw new Error('Model tidak mengembalikan balasan percakapan.');
      }

      const parsedReply = JSON.parse(jsonText) as {
        partnerRole: string;
        arabicWithHarakat: string;
        transliteration: string;
        indonesian: string;
        culturalNote: string;
      };

      const reply = {
        ...parsedReply,
        arabicPlain: stripHarakatServer(parsedReply.arabicWithHarakat || ''),
      };

      let audioBase64: string | null = null;
      let ttsError: string | null = null;
      try {
        audioBase64 = await generateArabicSpeechWav(reply.arabicWithHarakat, register, voiceName);
      } catch (speechErr) {
        ttsError = extractApiError(speechErr).message;
      }

      console.log(
        `[API] /api/dialogue/respond (${register}) completed in ${Date.now() - tStart}ms`
      );

      res.json({
        reply,
        audioBase64,
        mimeType: 'audio/wav',
        ttsError,
        spokenTranscript,
      });
    } catch (err) {
      console.error(`[API] /api/dialogue/respond error (${Date.now() - tStart}ms):`, err);
      const { status, message } = extractApiError(err);
      res.status(status).json({ error: message });
    }
  });

  app.post('/api/dialogue/tts', async (req: Request, res: Response) => {
    const tStart = Date.now();
    try {
      const body = req.body as {
        text?: string;
        register?: ArabicRegister;
        voiceName?: string;
      };
      const text = typeof body.text === 'string' ? body.text.trim().slice(0, 600) : '';
      const register: ArabicRegister = body.register === 'ammiyah' ? 'ammiyah' : 'fusha';
      const voiceName =
        typeof body.voiceName === 'string' && body.voiceName ? body.voiceName : 'Kore';

      if (!text) {
        res.status(400).json({ error: 'Teks Arab untuk dibacakan tidak boleh kosong.' });
        return;
      }

      const audioBase64 = await generateArabicSpeechWav(text, register, voiceName);
      console.log(`[API] /api/dialogue/tts completed in ${Date.now() - tStart}ms`);
      res.json({
        audioBase64,
        mimeType: 'audio/wav',
      });
    } catch (err) {
      console.error(`[API] /api/dialogue/tts error (${Date.now() - tStart}ms):`, err);
      const { status, message } = extractApiError(err);
      res.status(status).json({ error: message });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (req: Request, res: Response, next: NextFunction) => {
      if (req.path.startsWith('/api/')) {
        next();
        return;
      }
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build frontend belum tersedia.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Kalami server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
