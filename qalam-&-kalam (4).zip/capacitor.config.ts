import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.kalami.arabic',
  appName: 'Kalami',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
  },
};

export default config;
