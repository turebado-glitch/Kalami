package com.kalami.arabic;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
import java.util.Locale;

public class MainActivity extends BridgeActivity {
    private static final int REQ_RECORD_AUDIO = 1001;
    private static final String GOOGLE_TTS_ENGINE = "com.google.android.tts";

    private TextToSpeech tts;
    private volatile boolean ttsEngineReady = false;
    private volatile String arabicStatus = "no_engine";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[] {Manifest.permission.RECORD_AUDIO},
                    REQ_RECORD_AUDIO);
        }

        initTextToSpeech(null);

        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().addJavascriptInterface(new TtsBridge(), "AndroidTTS");
        }
    }

    private void initTextToSpeech(String preferredEngine) {
        if (tts != null) {
            try {
                tts.shutdown();
            } catch (Exception ignored) {
                // Ignore shutdown failure
            }
            tts = null;
        }
        ttsEngineReady = false;

        TextToSpeech.OnInitListener listener = status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsEngineReady = true;
                configureUtteranceListener();
                refreshArabicStatus();
            } else if (preferredEngine == null) {
                // Retry explicitly with Google TTS on Android One / stock Android devices
                initTextToSpeech(GOOGLE_TTS_ENGINE);
            } else {
                ttsEngineReady = false;
                arabicStatus = "no_engine";
            }
        };

        try {
            if (preferredEngine != null) {
                tts = new TextToSpeech(this, listener, preferredEngine);
            } else {
                tts = new TextToSpeech(this, listener);
            }
        } catch (Exception e) {
            if (preferredEngine == null) {
                initTextToSpeech(GOOGLE_TTS_ENGINE);
            } else {
                ttsEngineReady = false;
                arabicStatus = "no_engine";
            }
        }
    }

    private void configureUtteranceListener() {
        if (tts == null) return;
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
                notifyWebTts("start", utteranceId);
            }

            @Override
            public void onDone(String utteranceId) {
                notifyWebTts("done", utteranceId);
            }

            @Override
            @Deprecated
            public void onError(String utteranceId) {
                notifyWebTts("error", utteranceId);
            }

            @Override
            public void onError(String utteranceId, int errorCode) {
                notifyWebTts("error", utteranceId);
            }
        });
    }

    private void notifyWebTts(String event, String utteranceId) {
        if (getBridge() == null) return;
        WebView webView = getBridge().getWebView();
        if (webView == null) return;
        String safeId = utteranceId == null ? "" : utteranceId.replace("'", "");
        webView.post(() -> webView.evaluateJavascript(
                "window.__kalamiAndroidTtsEvent && window.__kalamiAndroidTtsEvent('"
                        + event
                        + "', '"
                        + safeId
                        + "');",
                null));
    }

    private Locale[] candidateArabicLocales(String requestedLang) {
        if (requestedLang != null && !requestedLang.isEmpty()) {
            return new Locale[] {
                Locale.forLanguageTag(requestedLang),
                Locale.forLanguageTag("ar-SA"),
                Locale.forLanguageTag("ar-XA"),
                Locale.forLanguageTag("ar-AE"),
                new Locale("ar"),
                Locale.forLanguageTag("ar-EG"),
            };
        }
        return new Locale[] {
            Locale.forLanguageTag("ar-SA"),
            Locale.forLanguageTag("ar-XA"),
            Locale.forLanguageTag("ar-AE"),
            new Locale("ar"),
            Locale.forLanguageTag("ar-EG"),
        };
    }

    private Locale refreshArabicStatus() {
        if (tts == null || !ttsEngineReady) {
            arabicStatus = "no_engine";
            return null;
        }
        Locale bestReady = null;
        boolean sawMissingData = false;
        for (Locale loc : candidateArabicLocales("ar-SA")) {
            try {
                int avail = tts.isLanguageAvailable(loc);
                if (avail >= TextToSpeech.LANG_AVAILABLE) {
                    bestReady = loc;
                    break;
                } else if (avail == TextToSpeech.LANG_MISSING_DATA) {
                    sawMissingData = true;
                }
            } catch (Exception ignored) {
                // Continue checking next locale
            }
        }
        if (bestReady != null) {
            tts.setLanguage(bestReady);
            arabicStatus = "ready";
            return bestReady;
        }
        if (sawMissingData) {
            arabicStatus = "missing_data";
            return new Locale("ar");
        }
        arabicStatus = "not_supported";
        return new Locale("ar");
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    private class TtsBridge {
        @JavascriptInterface
        public String getStatus() {
            if (tts == null || !ttsEngineReady) {
                return "no_engine";
            }
            refreshArabicStatus();
            return arabicStatus;
        }

        @JavascriptInterface
        public boolean isAvailable() {
            if (tts == null || !ttsEngineReady) {
                return false;
            }
            refreshArabicStatus();
            return "ready".equals(arabicStatus);
        }

        @JavascriptInterface
        public String speak(String text, String lang, float rate) {
            if (tts == null || !ttsEngineReady || text == null || text.isEmpty()) {
                return "no_engine";
            }
            String currentStatus = getStatus();
            runOnUiThread(() -> {
                if (tts == null) return;
                Locale chosen = null;
                for (Locale loc : candidateArabicLocales(lang)) {
                    try {
                        int res = tts.isLanguageAvailable(loc);
                        if (res >= TextToSpeech.LANG_AVAILABLE) {
                            chosen = loc;
                            break;
                        }
                    } catch (Exception ignored) {
                        // Continue
                    }
                }
                if (chosen == null) {
                    chosen = Locale.forLanguageTag(lang != null && !lang.isEmpty() ? lang : "ar-SA");
                }
                tts.setLanguage(chosen);
                tts.setSpeechRate(Math.max(0.5f, Math.min(1.5f, rate)));

                Bundle params = new Bundle();
                params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC);
                String utteranceId = "kalami_" + System.currentTimeMillis();
                int result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId);
                if (result == TextToSpeech.ERROR) {
                    notifyWebTts("error", utteranceId);
                }
            });
            return currentStatus;
        }

        @JavascriptInterface
        public void stop() {
            if (tts != null) {
                runOnUiThread(() -> tts.stop());
            }
        }

        @JavascriptInterface
        public void installVoiceData() {
            runOnUiThread(() -> {
                try {
                    Intent installIntent = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                    installIntent.setPackage(GOOGLE_TTS_ENGINE);
                    installIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(installIntent);
                    return;
                } catch (Exception ignored) {
                    // Fall back to generic install action
                }
                try {
                    Intent genericInstall = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                    genericInstall.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(genericInstall);
                    return;
                } catch (Exception ignored) {
                    // Fall back to TTS settings
                }
                openTtsSettings();
            });
        }

        @JavascriptInterface
        public void openTtsSettings() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent("com.android.settings.TTS_SETTINGS");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } catch (Exception ignored) {
                    // Fallback if device blocks direct TTS settings intent
                }
            });
        }
    }
}
