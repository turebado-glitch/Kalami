# Preserve AndroidTTS JavaScript interface in Release builds
-keepclassmembers class com.kalami.arabic.MainActivity$TtsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*
