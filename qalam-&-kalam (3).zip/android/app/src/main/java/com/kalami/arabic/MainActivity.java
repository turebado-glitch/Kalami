package com.kalami.arabic;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;
import java.util.Locale;

public class MainActivity extends BridgeActivity {
    private static final int REQ_RECORD_AUDIO = 1001;
    private TextToSpeech tts;
    private volatile boolean ttsEngineReady = false;
    private volatile boolean arabicVoiceReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[] {Manifest.permission.RECORD_AUDIO},
                    REQ_RECORD_AUDIO);
        }

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsEngineReady = true;
                int res = tts.setLanguage(Locale.forLanguageTag("ar-SA"));
                if (res == TextToSpeech.LANG_MISSING_DATA
                        || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                    res = tts.setLanguage(Locale.forLanguageTag("ar"));
                }
                arabicVoiceReady = res != TextToSpeech.LANG_MISSING_DATA
                        && res != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });

        if (getBridge() != null && getBridge().getWebView() != null) {
            getBridge().getWebView().addJavascriptInterface(new TtsBridge(), "AndroidTTS");
        }
    }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    private class TtsBridge {
        @JavascriptInterface
        public boolean isAvailable() {
            if (tts == null || !ttsEngineReady) {
                return false;
            }
            int sa = tts.isLanguageAvailable(Locale.forLanguageTag("ar-SA"));
            int ar = tts.isLanguageAvailable(Locale.forLanguageTag("ar"));
            arabicVoiceReady = sa >= TextToSpeech.LANG_AVAILABLE || ar >= TextToSpeech.LANG_AVAILABLE;
            return arabicVoiceReady;
        }

        @JavascriptInterface
        public void speak(String text, String lang, float rate) {
            if (tts == null || !ttsEngineReady || text == null || text.isEmpty()) {
                return;
            }
            runOnUiThread(() -> {
                Locale target = Locale.forLanguageTag(lang != null ? lang : "ar-SA");
                int result = tts.setLanguage(target);
                if (result == TextToSpeech.LANG_MISSING_DATA
                        || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.forLanguageTag("ar"));
                }
                tts.setSpeechRate(Math.max(0.5f, Math.min(1.5f, rate)));
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kalami_tts");
            });
        }

        @JavascriptInterface
        public void stop() {
            if (tts != null) {
                runOnUiThread(() -> tts.stop());
            }
        }

        @JavascriptInterface
        public void openTtsSettings() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent("com.android.settings.TTS_SETTINGS");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } catch (Exception ignored) {
                    // Fallback if device blocks direct TTS settings intent
                }
            });
        }
    }
}
