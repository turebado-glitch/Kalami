import React, { useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Play,
  Square,
  ArrowRight,
} from 'lucide-react';
import { SCENARIOS, type ScenarioModule } from '../data/arabicCurriculum';
import {
  formatArabicDisplay,
  getArabicVoiceAvailability,
  speakArabic,
  stopArabicSpeech,
  type ArabicRegister,
} from '../utils/arabicSpeech';
import {
  fetchAndPlayGeminiTts,
  stopWavPlayback,
  unlockAudioPlayback,
} from '../utils/wavPlayer';
import { AudioButton, ResilientImage } from './SharedUI';

export type RegisterViewMode = 'both' | 'fusha' | 'ammiyah';

interface DialogueStudioProps {
  completedScenarios: string[];
  onToggleCompleteScenario: (id: string) => void;
  masteredVocabCount: number;
  totalVocabCount: number;
  showHarakat: boolean;
  onToggleHarakat: () => void;
  showTranslit: boolean;
  onToggleTranslit: () => void;
  speechRate: number;
  onChangeSpeechRate: (rate: number) => void;
  onNavigatePractice: () => void;
  onNavigateCompare: () => void;
}

export const DialogueStudio: React.FC<DialogueStudioProps> = ({
  completedScenarios,
  onToggleCompleteScenario,
  masteredVocabCount,
  totalVocabCount,
  showHarakat,
  onToggleHarakat,
  showTranslit,
  onToggleTranslit,
  speechRate,
  onChangeSpeechRate,
  onNavigatePractice,
  onNavigateCompare,
}) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(SCENARIOS[0].id);
  const [viewMode, setViewMode] = useState<RegisterViewMode>('both');
  const [expandedTurns, setExpandedTurns] = useState<Record<string, boolean>>({
    'g-1': true,
  });
  const [playingTurnId, setPlayingTurnId] = useState<string | null>(null);
  const [sequenceRegister, setSequenceRegister] = useState<ArabicRegister | null>(null);
  const sequenceAbortRef = useRef<boolean>(false);

  const activeScenario: ScenarioModule =
    SCENARIOS.find((s) => s.id === selectedScenarioId) || SCENARIOS[0];

  useEffect(() => {
    return () => {
      sequenceAbortRef.current = true;
      stopWavPlayback();
      stopArabicSpeech();
    };
  }, []);

  const stopSequence = () => {
    sequenceAbortRef.current = true;
    stopWavPlayback();
    stopArabicSpeech();
    setSequenceRegister(null);
    setPlayingTurnId(null);
  };

  const handleSelectScenario = (id: string) => {
    stopSequence();
    setSelectedScenarioId(id);
  };

  const toggleTurnDetail = (turnId: string) => {
    setExpandedTurns((prev) => ({ ...prev, [turnId]: !prev[turnId] }));
  };

  const playFullDialogue = (register: ArabicRegister) => {
    if (sequenceRegister === register) {
      stopSequence();
      return;
    }
    unlockAudioPlayback();
    stopSequence();
    sequenceAbortRef.current = false;
    setSequenceRegister(register);

    const turns = activeScenario.turns;
    let index = 0;

    const playNext = async () => {
      if (sequenceAbortRef.current || index >= turns.length) {
        setSequenceRegister(null);
        setPlayingTurnId(null);
        return;
      }
      const turn = turns[index];
      const text = register === 'fusha' ? turn.fusha.arabic : turn.ammiyah.arabic;
      setPlayingTurnId(turn.id);
      index += 1;

      const scheduleNext = () => {
        if (!sequenceAbortRef.current) {
          window.setTimeout(() => {
            void playNext();
          }, 350);
        }
      };

      try {
        await fetchAndPlayGeminiTts(text, register, speechRate, undefined, scheduleNext);
      } catch {
        const avail = getArabicVoiceAvailability();
        if (avail.supported && avail.hasArabicVoice) {
          speakArabic(text, register, speechRate, undefined, scheduleNext);
        } else {
          stopSequence();
        }
      }
    };

    void playNext();
  };

  const isCompleted = completedScenarios.includes(activeScenario.id);

  return (
    <div className="space-y-10">
      {/* Editorial Hero Split */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch bg-white border border-slate-200 rounded-xl p-6 lg:p-8">
        <div className="lg:col-span-7 flex flex-col justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-medium text-slate-500 tracking-wide">
              Kurikulum Dwiragam Otodidak · Fushah &amp; Ammiyah
            </p>
            <h1 className="font-display text-3xl sm:text-4xl font-semibold tracking-tight text-slate-900 leading-[1.15] [text-wrap:balance]">
              Belajar Percakapan Arab Baku dan Sehari-hari Secara Bersamaan
            </h1>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed max-w-2xl">
              Pahami kapan menggunakan <span className="font-semibold text-blue-700">Fushah</span>{' '}
              (bahasa baku akademik dan media) serta kapan memakai{' '}
              <span className="font-semibold text-emerald-700">Ammiyah</span> (dialek percakapan
              harian Arab Saudi) lewat dialog kontekstual, audio pelafalan, dan bedah pola kalimat.
            </p>
          </div>

          <div className="space-y-4 pt-2 border-t border-slate-100">
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs sm:text-sm text-slate-600 font-mono-nums">
              <span>
                <strong className="text-slate-900">{completedScenarios.length}</strong>/
                {SCENARIOS.length} Modul Dialog Selesai
              </span>
              <span aria-hidden="true" className="text-slate-300">
                ·
              </span>
              <span>
                <strong className="text-slate-900">{masteredVocabCount}</strong>/{totalVocabCount}{' '}
                Kosakata Dikuasai
              </span>
              <span aria-hidden="true" className="text-slate-300">
                ·
              </span>
              <span>Fokus: Fushah &amp; Ammiyah Arab Saudi</span>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={onNavigatePractice}
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px]"
              >
                <span>Buka Latihan Interaktif</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={onNavigateCompare}
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[40px]"
              >
                <span>Buka Lab Perbandingan</span>
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="h-56 lg:h-full w-full rounded-lg overflow-hidden border border-slate-200 bg-slate-100">
            <ResilientImage
              src="/src/assets/images/hero_arabic_study_1795242471897.jpg"
              alt="Meja belajar bahasa Arab dengan buku catatan kaligrafi dan teh mint"
              title="Kalami"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Scenario Selector Grid */}
      <section aria-labelledby="scenario-list-heading" className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
          <div>
            <h2
              id="scenario-list-heading"
              className="font-display text-xl sm:text-2xl font-semibold text-slate-900"
            >
              Pilih Skenario Percakapan
            </h2>
            <p className="text-sm text-slate-600">
              Enam situasi nyata dari perkenalan resmi hingga tawar-menawar di pasar.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {SCENARIOS.map((scenario) => {
            const active = scenario.id === activeScenario.id;
            const done = completedScenarios.includes(scenario.id);
            return (
              <button
                key={scenario.id}
                type="button"
                onClick={() => handleSelectScenario(scenario.id)}
                className={`text-left p-5 rounded-xl border transition-all duration-150 ease-editorial cursor-pointer flex flex-col justify-between gap-3 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 ${
                  active
                    ? 'bg-white border-slate-900 shadow-sm'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                    <span className="font-mono-nums font-medium text-slate-700">
                      {scenario.number} · {scenario.level}
                    </span>
                    {done && (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Selesai
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-semibold text-slate-900 leading-snug">
                    {scenario.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                    {scenario.subtitle}
                  </p>
                </div>

                <div className="text-xs text-slate-500 pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                  <span>{scenario.recommendedRegister}</span>
                  <span className="font-mono-nums">{scenario.turns.length} dialog</span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Active Scenario Interactive Stage */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {/* Scenario Context Banner */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 p-6 lg:p-8 border-b border-slate-200 bg-slate-50/60 items-stretch">
          <div className="lg:col-span-3">
            <div className="h-44 lg:h-full w-full rounded-lg overflow-hidden border border-slate-200 bg-slate-100">
              <ResilientImage
                src={activeScenario.imagePath}
                alt={activeScenario.title}
                title={activeScenario.title}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          <div className="lg:col-span-9 flex flex-col justify-between gap-4">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <span className="font-mono-nums font-semibold text-slate-800">
                  Modul {activeScenario.number}
                </span>
                <span aria-hidden="true">·</span>
                <span>Tingkat {activeScenario.level}</span>
                <span aria-hidden="true">·</span>
                <span>{activeScenario.estimatedMinutes} menit belajar</span>
                <span aria-hidden="true">·</span>
                <span>{activeScenario.recommendedRegister}</span>
              </div>
              <h2 className="font-display text-2xl font-semibold text-slate-900">
                {activeScenario.title}
              </h2>
              <p className="text-sm text-slate-700 leading-relaxed">
                <strong className="font-semibold text-slate-900">Catatan Konteks:</strong>{' '}
                {activeScenario.culturalNote}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => playFullDialogue('fusha')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[38px] ${
                    sequenceRegister === 'fusha'
                      ? 'bg-blue-700 text-white border-blue-700'
                      : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-50'
                  }`}
                >
                  {sequenceRegister === 'fusha' ? (
                    <Square className="w-3.5 h-3.5" />
                  ) : (
                    <Play className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {sequenceRegister === 'fusha' ? 'Hentikan Fushah' : 'Putar Dialog Fushah'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => playFullDialogue('ammiyah')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[38px] ${
                    sequenceRegister === 'ammiyah'
                      ? 'bg-emerald-700 text-white border-emerald-700'
                      : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
                  }`}
                >
                  {sequenceRegister === 'ammiyah' ? (
                    <Square className="w-3.5 h-3.5" />
                  ) : (
                    <Play className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {sequenceRegister === 'ammiyah'
                      ? 'Hentikan Ammiyah'
                      : 'Putar Dialog Ammiyah'}
                  </span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => onToggleCompleteScenario(activeScenario.id)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[38px] ${
                  isCompleted
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isCompleted ? 'Modul Selesai' : 'Tandai Selesai'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Workspace Controls Toolbar */}
        <div className="px-6 lg:px-8 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4 bg-white">
          {/* Segmented Register Filter */}
          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(
              [
                { id: 'both', label: 'Bandingan Berdampingan' },
                { id: 'fusha', label: 'Fushah Saja' },
                { id: 'ammiyah', label: 'Ammiyah Saja' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setViewMode(opt.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  viewMode === opt.id
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Reading & Audio Aids */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onToggleHarakat}
              aria-pressed={showHarakat}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[34px] ${
                showHarakat
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              Harakat: {showHarakat ? 'Aktif' : 'Gundul'}
            </button>

            <button
              type="button"
              onClick={onToggleTranslit}
              aria-pressed={showTranslit}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[34px] ${
                showTranslit
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              Transliterasi: {showTranslit ? 'Aktif' : 'Sembunyi'}
            </button>

            <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              {[
                { rate: 0.72, label: '0.75x Pelan' },
                { rate: 0.95, label: '1.0x Normal' },
              ].map((spd) => (
                <button
                  key={spd.rate}
                  type="button"
                  onClick={() => onChangeSpeechRate(spd.rate)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer font-mono-nums ${
                    Math.abs(speechRate - spd.rate) < 0.05
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {spd.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Dialogue Turns */}
        <div className="divide-y divide-slate-200">
          {activeScenario.turns.map((turn, idx) => {
            const isExpanded = Boolean(expandedTurns[turn.id]);
            const isPlayingThis = playingTurnId === turn.id;

            return (
              <div
                key={turn.id}
                className={`p-6 lg:p-8 transition-colors ${
                  isPlayingThis ? 'bg-blue-50/40' : 'bg-white'
                }`}
              >
                {/* Turn Header */}
                <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span className="font-mono-nums font-semibold text-slate-800">
                        Giliran {idx + 1}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-medium text-slate-900">{turn.speaker}</span>
                      <span aria-hidden="true">·</span>
                      <span>{turn.role}</span>
                    </div>
                    <p className="text-sm sm:text-base font-medium text-slate-900">
                      “{turn.indonesian}”
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => toggleTurnDetail(turn.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[34px]"
                  >
                    <span>Bedah Kata &amp; Tata Bahasa</span>
                    {isExpanded ? (
                      <ChevronUp className="w-3.5 h-3.5" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Dual-Register Comparison Grid */}
                <div
                  className={`grid gap-4 ${
                    viewMode === 'both' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'
                  }`}
                >
                  {(viewMode === 'both' || viewMode === 'fusha') && (
                    <div className="p-5 rounded-xl bg-blue-50/35 border border-blue-200/80 flex flex-col justify-between gap-4">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-blue-800 tracking-wide">
                          Fushah · Bahasa Baku
                        </span>
                        <AudioButton
                          text={turn.fusha.arabic}
                          register="fusha"
                          rate={speechRate}
                          compact
                        />
                      </div>

                      <div className="space-y-2">
                        <p className="font-arabic text-2xl sm:text-[26px] text-slate-900 font-medium text-right">
                          {formatArabicDisplay(turn.fusha.arabic, showHarakat)}
                        </p>
                        {showTranslit && (
                          <p className="text-sm text-blue-950/80 italic">
                            {turn.fusha.transliteration}
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  {(viewMode === 'both' || viewMode === 'ammiyah') && (
                    <div className="p-5 rounded-xl bg-emerald-50/35 border border-emerald-200/80 flex flex-col justify-between gap-4">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-emerald-800 tracking-wide">
                          Ammiyah · Percakapan Arab Saudi
                        </span>
                        <AudioButton
                          text={turn.ammiyah.arabic}
                          register="ammiyah"
                          rate={speechRate}
                          compact
                        />
                      </div>

                      <div className="space-y-2">
                        <p className="font-arabic text-2xl sm:text-[26px] text-slate-900 font-medium text-right">
                          {formatArabicDisplay(turn.ammiyah.arabic, showHarakat)}
                        </p>
                        {showTranslit && (
                          <p className="text-sm text-emerald-950/80 italic">
                            {turn.ammiyah.transliteration}
                          </p>
                        )}
                        {turn.ammiyah.dialectNote && (
                          <p className="text-xs text-slate-600 pt-1">
                            Catatan dialek: {turn.ammiyah.dialectNote}
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Expandable Word Breakdown & Grammar Spotlight */}
                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-slate-100 space-y-4">
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed bg-slate-50 px-4 py-3 rounded-lg border border-slate-200">
                      <strong className="font-semibold text-slate-900">Pola Penting:</strong>{' '}
                      {turn.grammarSpotlight}
                    </p>

                    {turn.tokens.length > 0 && (
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs sm:text-sm">
                          <thead>
                            <tr className="border-b border-slate-200 text-slate-500 text-xs">
                              <th className="py-2 pr-4 font-medium">Arti</th>
                              <th className="py-2 px-4 font-medium text-blue-800">Fushah</th>
                              <th className="py-2 pl-4 font-medium text-emerald-800">Ammiyah</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {turn.tokens.map((tok, tIdx) => (
                              <tr key={tIdx}>
                                <td className="py-2.5 pr-4 font-medium text-slate-800">
                                  {tok.meaning}
                                </td>
                                <td className="py-2.5 px-4">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span className="font-arabic text-lg text-slate-900">
                                      {formatArabicDisplay(tok.fusha, showHarakat)}
                                    </span>
                                    {showTranslit && (
                                      <span className="text-xs text-slate-500 italic">
                                        ({tok.fushaTranslit})
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td className="py-2.5 pl-4">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <span className="font-arabic text-lg text-slate-900">
                                      {formatArabicDisplay(tok.ammiyah, showHarakat)}
                                    </span>
                                    {showTranslit && (
                                      <span className="text-xs text-slate-500 italic">
                                        ({tok.ammiyahTranslit})
                                      </span>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
