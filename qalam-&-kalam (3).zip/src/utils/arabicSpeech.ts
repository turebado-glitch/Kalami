export type ArabicRegister = 'fusha' | 'ammiyah';

const HARAKAT_REGEX = /[\u064B-\u065F\u0670\u06D6-\u06ED]/g;

export function stripHarakat(text: string): string {
  return text.replace(HARAKAT_REGEX, '');
}

export function formatArabicDisplay(text: string, showHarakat: boolean): string {
  return showHarakat ? text : stripHarakat(text);
}

declare global {
  interface Window {
    AndroidTTS?: {
      speak: (text: string, lang: string, rate: number) => void;
      stop: () => void;
      isAvailable: () => boolean;
      openTtsSettings?: () => void;
    };
  }
}

export interface VoiceAvailability {
  supported: boolean;
  hasArabicVoice: boolean;
  voiceName: string | null;
  isAndroidApp: boolean;
}

export function isAndroidNativeApp(): boolean {
  return typeof window !== 'undefined' && Boolean(window.AndroidTTS);
}

export function openAndroidTtsSettings(): boolean {
  if (typeof window !== 'undefined' && window.AndroidTTS?.openTtsSettings) {
    window.AndroidTTS.openTtsSettings();
    return true;
  }
  return false;
}

export function getArabicVoiceAvailability(): VoiceAvailability {
  if (typeof window !== 'undefined' && window.AndroidTTS) {
    return {
      supported: true,
      hasArabicVoice: window.AndroidTTS.isAvailable(),
      voiceName: 'Android Native TextToSpeech',
      isAndroidApp: true,
    };
  }
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return { supported: false, hasArabicVoice: false, voiceName: null, isAndroidApp: false };
  }
  const voices = window.speechSynthesis.getVoices();
  const arVoice =
    voices.find((v) => v.lang.toLowerCase().startsWith('ar-sa')) ||
    voices.find((v) => v.lang.toLowerCase().startsWith('ar-ae')) ||
    voices.find((v) => v.lang.toLowerCase().startsWith('ar'));

  return {
    supported: true,
    hasArabicVoice: Boolean(arVoice),
    voiceName: arVoice ? `${arVoice.name} (${arVoice.lang})` : null,
    isAndroidApp: false,
  };
}

export function stopArabicSpeech(): void {
  if (typeof window !== 'undefined' && window.AndroidTTS) {
    try {
      window.AndroidTTS.stop();
    } catch {
      // ignore
    }
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function speakArabic(
  text: string,
  register: ArabicRegister,
  rate = 0.92,
  onStart?: () => void,
  onEnd?: () => void
): boolean {
  if (typeof window !== 'undefined' && window.AndroidTTS) {
    try {
      const lang = 'ar-SA';
      onStart?.();
      window.AndroidTTS.speak(text, lang, rate);
      const estimatedMs = Math.max(900, Math.min(4500, text.length * 95));
      window.setTimeout(() => {
        onEnd?.();
      }, estimatedMs);
      return true;
    } catch {
      // fall through to Web Speech API
    }
  }

  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    onEnd?.();
    return false;
  }

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();

    const targetLangs =
      register === 'ammiyah'
        ? ['ar-SA', 'ar-AE', 'ar-KW', 'ar']
        : ['ar-SA', 'ar-AE', 'ar'];

    let chosenVoice: SpeechSynthesisVoice | undefined;
    for (const lang of targetLangs) {
      chosenVoice = voices.find((v) =>
        v.lang.toLowerCase().startsWith(lang.toLowerCase())
      );
      if (chosenVoice) break;
    }

    if (chosenVoice) {
      utterance.voice = chosenVoice;
      utterance.lang = chosenVoice.lang;
    } else {
      utterance.lang = 'ar-SA';
    }

    utterance.rate = rate;
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      onStart?.();
    };
    utterance.onend = () => {
      onEnd?.();
    };
    utterance.onerror = () => {
      onEnd?.();
    };

    window.speechSynthesis.speak(utterance);
    return true;
  } catch {
    onEnd?.();
    return false;
  }
}
